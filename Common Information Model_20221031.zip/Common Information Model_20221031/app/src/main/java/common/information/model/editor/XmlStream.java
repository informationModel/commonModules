package common.information.model.editor;

import org.eclipse.swt.widgets.Link;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider;
import com.thoughtworks.xstream.security.NoTypePermission;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

import common.information.model.editor.cim.GenInfo;
import common.information.model.editor.cim.IDnType;
import common.information.model.editor.cim.IOVariables;
import common.information.model.editor.cim.InOut;
import common.information.model.editor.cim.Input;
import common.information.model.editor.cim.Output;
import common.information.model.editor.cim.Module;

public class XmlStream extends XStream {
	public enum ParseMode {
		all, configuration, info_model
	}

	private static final Class<?>[] INFO_CLASSES = {
		GenInfo.class, IDnType.class, Input.class, Output.class, InOut.class
		, Module.class, IOVariables.class
	};

	public XmlStream() {
		this(ParseMode.all);
	}

	public XmlStream(ParseMode mode) {
		super(new PureJavaReflectionProvider());

		aliasSystemAttribute(null, "class");
		addPermission(NoTypePermission.NONE);
		addPermission(NullPermission.NULL);
		addPermission(PrimitiveTypePermission.PRIMITIVES);
		allowTypesByWildcard(new String[] { 
			Module.class.getPackageName() + ".*" 
		});

		if (mode == ParseMode.info_model) {
			processAnnotations(INFO_CLASSES);
		} else {
			processAnnotations(INFO_CLASSES);
		}
	}
}
