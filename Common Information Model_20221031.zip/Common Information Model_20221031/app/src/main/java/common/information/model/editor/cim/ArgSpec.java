package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("ArgSpec")
public class ArgSpec {

    @XStreamAsAttribute
    @XStreamAlias("Type")
    private String argType = "";

    @XStreamAsAttribute
    @XStreamAlias("Name")
    private String argName = "";

    @XStreamAsAttribute
    @XStreamAlias("IOType")
    private String argIO = "";

    public void setArgType(String argType) {
        this.argType = argType;
    }

    public String getArgType() {
        return argType;
    }

    public void setArgName(String argName) {
        this.argName = argName;
    }

    public String getArgName() {
        return argName;
    }

    public void setArgIO(String argIO) {
        this.argIO = argIO;
    }

    public String getArgIO() {
        return argIO;
    }
}
