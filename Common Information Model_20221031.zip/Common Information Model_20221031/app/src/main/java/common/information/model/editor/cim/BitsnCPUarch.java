package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("bitsnCPUarch")
public class BitsnCPUarch {

    @XStreamAsAttribute
    @XStreamAlias("bits")
    private String mBits;

    @XStreamAsAttribute
    @XStreamAlias("CPUarch")
    private String mCPUarch;

    public BitsnCPUarch() {
    }

    public BitsnCPUarch(String mBits, String mCPUarch) {
        this.mBits = mBits;
        this.mCPUarch = mCPUarch;
    }

    public String getmCPUarch() {
        return mCPUarch;
    }

    public String getmBits() {
        return mBits;
    }

    public void setmBits(String mBits) {
        this.mBits = mBits;
    }

    public void setmCPUarch(String mCPUarch) {
        this.mCPUarch = mCPUarch;
    }
}