package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("CompilerType")
public class CompilerType {

    @XStreamAlias("osName")
    private String mOSName;

    @XStreamAlias("verRangeOS")
    private RangeString mVerRangeOS;

    @XStreamAlias("compilerName")
    private String mCompilerName;

    @XStreamAlias("verRangeCompiler")
    private RangeString mVerRangeCompiler;

    @XStreamAlias("BitsnCPUarch")
    public BitsnCPUarch mBitsnCPUarch;

    public CompilerType() {
        mVerRangeOS = new RangeString();
        mVerRangeCompiler = new RangeString();
        mBitsnCPUarch = new BitsnCPUarch();
    }

    public String getmOSName() {
        return mOSName;
    }

    public BitsnCPUarch getmBitsnCPUarch() {
        return mBitsnCPUarch;
    }

    public void setmBitsnCPUarch(BitsnCPUarch mBitsnCPUarch) {
        this.mBitsnCPUarch = mBitsnCPUarch;
    }

    public RangeString getmVerRangeCompiler() {
        return mVerRangeCompiler;
    }

    public void setmVerRangeCompiler(RangeString mVerRangeCompiler) {
        this.mVerRangeCompiler = mVerRangeCompiler;
    }

    public RangeString getmVerRangeOS() {
        return mVerRangeOS;
    }

    public void setmVerRangeOS(RangeString mVerRangeOS) {
        this.mVerRangeOS = mVerRangeOS;
    }

    public String getmCompilerName() {
        return mCompilerName;
    }

    public void setmCompilerName(String mCompilerName) {
        this.mCompilerName = mCompilerName;
    }

    public void setmOSName(String mOSName) {
        this.mOSName = mOSName;
    }

}
