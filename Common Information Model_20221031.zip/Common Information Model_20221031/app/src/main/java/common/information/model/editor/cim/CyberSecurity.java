package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class CyberSecurity {

    @XStreamAlias("Overall")
    private String mOverallValue;

    @XStreamImplicit
    private List<SecType> secTypes;

    public CyberSecurity() {
        secTypes = new LinkedList<>();
    }

    public void createSecType(){
        this.secTypes = new LinkedList<>();
    }
    
    public void setOverallValue(String overallValue) {
        this.mOverallValue = overallValue;
    }

    public String getOverallValue() {
        return mOverallValue;
    }

    public List<SecType> getSecTypes() {
        return secTypes;
    }
}
