package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Databus")
public class Databus {

    @XStreamAlias("ConnectorType")
    public String connectorType;

    @XStreamAlias("TypePhyMac")
    public String typePhyMac;

    @XStreamAlias("TypeNetTrans")
    public String typeNetTrans;

    @XStreamAlias("TypeApp")
    public String typeApp;

    @XStreamAlias("Speed")
    public Speed speed;

    public Databus() {
        speed = new Speed();
    }
}
