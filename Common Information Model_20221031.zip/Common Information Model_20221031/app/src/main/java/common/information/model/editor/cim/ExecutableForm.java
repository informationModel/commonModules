package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ExecutableForm")
public class ExecutableForm {

    @XStreamAlias("MainURLs")
    public MainURLs main;

    @XStreamAlias("LibURLs")
    public LibURLs lib;

    @XStreamAlias("Shell")
    public Shell shell;

    public void setMainURLs() {
        if (main == null)
            main = new MainURLs();
    }

    public void setLibURLs() {
        if (lib == null)
            lib = new LibURLs();
    }

    public void setShellCmd() {
        if (shell == null)
            shell = new Shell();
    }

}
