package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("ExecutionType")
public class ExecutionType {

    @XStreamAsAttribute
    @XStreamAlias("opType")
    private String mOPType;

    @XStreamAsAttribute
    @XStreamAlias("hardRT")
    private String mHardRT;

    @XStreamAsAttribute
    @XStreamAlias("timeConstraint")
    private String mTimeConstraint;

    @XStreamAsAttribute
    @XStreamAlias("instanceType")
    private String mInstanceType;

    public String getmOPType() {
        return mOPType;
    }

    public String getmInstanceType() {
        return mInstanceType;
    }

    public void setmInstanceType(String mInstanceType) {
        this.mInstanceType = mInstanceType;
    }

    public String getmTimeConstraint() {
        return mTimeConstraint;
    }

    public void setmTimeConstraint(String mTimeConstraint) {
        this.mTimeConstraint = mTimeConstraint;
    }

    public String getmHardRT() {
        return mHardRT;
    }

    public void setmHardRT(String mHardRT) {
        this.mHardRT = mHardRT;
    }

    public void setmOPType(String mOPType) {
        this.mOPType = mOPType;
    }
}
