package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("GenInfo")
public class GenInfo {

	@XStreamAlias("ModuleName")
	public String mModuleName;
	@XStreamAlias("Manufactures")
	private String mManufacturer;
	@XStreamAlias("Description")
	private String mDescription;
	@XStreamAlias("Examples")
	private String mExamples;

	public void setModuleName(String moduleName) {
		this.mModuleName = moduleName;
	}

	public String getModuleName() {
		return mModuleName;
	}

	public void setDescription(String description) {
		this.mDescription = description;
	}

	public String getDescription() {
		return mDescription;
	}

	public void setManufacturer(String manufacturer) {
		this.mManufacturer = manufacturer;
	}

	public String getManufacturer() {
		return mManufacturer;
	}

	public void setExamples(String examples) {
		this.mExamples = examples;
	}

	public String getExamples() {
		return mExamples;
	}
}
