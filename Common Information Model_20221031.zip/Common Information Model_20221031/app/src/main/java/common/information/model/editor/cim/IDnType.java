package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("IDnType")
public class IDnType {

	@XStreamAsAttribute
	@XStreamAlias("type")
	public String mIDtype;

	@XStreamAlias("ID")
	public String moduleID;

	@XStreamAlias("informationModelVersion")
	public String informationModelVersion;

	@XStreamAlias("HWList")
	public HWList mHWList;

	@XStreamAlias("SWList")
	public SWList mSWList;

	public IDnType() {
		this.mHWList = new HWList();
		this.mSWList = new SWList();
	}
}
