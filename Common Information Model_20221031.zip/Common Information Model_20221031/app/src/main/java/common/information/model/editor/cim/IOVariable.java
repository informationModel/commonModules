package common.information.model.editor.cim;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

public abstract class IOVariable {

	@XStreamOmitField
	public boolean isNone, isArray, isClass, isVector, isPointer;

	@XStreamAsAttribute
	@XStreamAlias("name")
	public String name;

	@XStreamAsAttribute
	@XStreamAlias("className")
	public String clsName;

	@XStreamAsAttribute
	@XStreamAlias("complex")
	public String complex;

	@XStreamAsAttribute
	@XStreamAlias("type")
	public String type;

	@XStreamAsAttribute
	@XStreamAlias("value")
	public String value;

	@XStreamAlias("Value")
	public Values values;

	@XStreamAsAttribute
	@XStreamAlias("unit")
	public String unit;

	@XStreamAsAttribute
	@XStreamAlias("description")
	public String description;

	@XStreamAsAttribute
	@XStreamAlias("inDataType")
	public String inDataType;

	public abstract List<IOVariable> getClassType();

	public void createValues() {
		values = new Values();
	}

}