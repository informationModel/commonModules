package common.information.model.editor.cim;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("IOVariables")
public class IOVariables {
	@XStreamAlias("Inputs")
	public List<Input> Inputs;
	@XStreamAlias("Outputs")
	public List<Output> Outputs;
	@XStreamAlias("InOuts")
	public List<InOut> InOuts;
}