package common.information.model.editor.cim;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("InOut")
public class InOut extends IOVariable {
	@XStreamAlias("InOuts")
	@XStreamImplicit
	public List<InOut> inouts = new ArrayList<>();

	@SuppressWarnings("unchecked")
	@Override
	public List<IOVariable> getClassType() {
		List<?> l = inouts;
		return (List<IOVariable>) l;
	}
}
