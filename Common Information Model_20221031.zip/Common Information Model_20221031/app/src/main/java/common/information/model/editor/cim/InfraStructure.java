package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Infra")
public class InfraStructure {

    @XStreamAlias("Powers")
    public Powers powers;

    @XStreamAlias("DataBuses")
    public List<Databus> dataBuses;

    @XStreamAlias("DBType")
    public String dbType;

    @XStreamAlias("IP")
    public String IPcode;

    @XStreamAlias("Middleware")
    public Middleware mMiddleware;

    public InfraStructure() {
        dataBuses = new LinkedList<>();
        powers = new Powers();
        mMiddleware = new Middleware();
    }
}
