package common.information.model.editor.cim;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Input")
public class Input extends IOVariable {
	@XStreamAlias("Inputs")
	@XStreamImplicit
	public List<Input> inputs = new ArrayList<>();

	@SuppressWarnings("unchecked")
	@Override
	public List<IOVariable> getClassType() {
		List<?> l = inputs;
		return (List<IOVariable>) l;
	}
}
