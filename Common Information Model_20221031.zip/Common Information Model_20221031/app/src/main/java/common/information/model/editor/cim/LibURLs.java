package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("LibURLs")
public class LibURLs {
    @XStreamImplicit(itemFieldName = "Item")
    public List<String> urlnPath;

    public LibURLs() {
        urlnPath = new LinkedList<>();
    }
}