package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Library")
public class Library {

    @XStreamAsAttribute
    @XStreamAlias("name")
    private String mName = "";

    @XStreamAsAttribute
    @XStreamAlias("version")
    private String mVersion = "";

    public Library() {

    }

    public Library(String name, String version) {
        this.mName = name;
        this.mVersion = version;
    }

    public String getmName() {
        return mName;
    }

    public String getmVersion() {
        return mVersion;
    }

    public void setmVersion(String mVersion) {
        this.mVersion = mVersion;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

}
