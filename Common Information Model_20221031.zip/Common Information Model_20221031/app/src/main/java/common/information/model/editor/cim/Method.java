package common.information.model.editor.cim;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Method")
public class Method {

    @XStreamAlias("MethodName")
    private String mName;

    @XStreamImplicit
    private List<ArgSpec> mArgSpecs;

    @XStreamAlias("RetType")
    private String retType;

    @XStreamAlias("MOType")
    private MOType mMOType;

    public Method() {
        mMOType = MOType.DEFAULT;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getName() {
        return mName;
    }

    public void setMOType(String moType) {
        if (moType.equals("MANDATORY")) {
            this.mMOType = MOType.MANDATORY;
        } else if (moType.equals("OPTIONAL")) {
            this.mMOType = MOType.OPTIONAL;
        }
    }

    public String getMOType() {
        return mMOType.name();
    }

    public List<ArgSpec> getArgSpecs() {
        return mArgSpecs;
    }

    public void createArgSpecs() {
        if (mArgSpecs == null) 
            mArgSpecs = new ArrayList<>();
    }

    public String getRetType() {
        return retType;
    }

    public void setRetType(String retType) {
        this.retType = retType;
    }

    enum MOType {

        @XStreamAlias("value")
        DEFAULT, MANDATORY, OPTIONAL;
    }
}
