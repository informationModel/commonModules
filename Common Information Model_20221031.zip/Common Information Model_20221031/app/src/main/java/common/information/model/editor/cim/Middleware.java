package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Middleware")
public class Middleware {

    @XStreamAsAttribute
    @XStreamAlias("name")
    public String middlewareName;

    @XStreamAsAttribute
    @XStreamAlias("version")
    public String middlewareVersion;

}