package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("SimulationModel")
public class ModelCase {
    
    @XStreamAlias("Simulator")
    public String simulator = "";

    @XStreamImplicit
    @XStreamAlias("ModelFile")
    public ModelFile[] modelFile = new ModelFile[2];

    public ModelCase() {
        modelFile[0] = new ModelFile();
        modelFile[1] = new ModelFile();
    }
}
