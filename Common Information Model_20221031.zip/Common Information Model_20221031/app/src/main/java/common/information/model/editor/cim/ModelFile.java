package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("ModelFile")
public class ModelFile {

    @XStreamAsAttribute
    @XStreamAlias("type")
    public String type = "";

    @XStreamAlias("Name")
    public String fileName = "";

    @XStreamAlias("Path")
    public String filePath = "";

    public ModelFile() {
    }
}
