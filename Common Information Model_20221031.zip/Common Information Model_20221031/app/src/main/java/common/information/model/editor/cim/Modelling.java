package common.information.model.editor.cim;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Modelling")
public class Modelling {
    
    @XStreamImplicit
    @XStreamAlias("SimulationModel")
    public List<ModelCase> simulationModel;

    public Modelling() {
        simulationModel = new ArrayList<>();
    }
    
}
