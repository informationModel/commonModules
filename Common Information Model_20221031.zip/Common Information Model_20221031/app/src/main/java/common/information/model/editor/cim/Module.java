package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("Module")
public class Module {

	@XStreamOmitField
	public boolean isSafety, isSecurity;
	@XStreamOmitField
	public boolean isHw, isSw;
	@XStreamOmitField
	public boolean isTool;
	@XStreamOmitField
	public String[] unitList;
	@XStreamOmitField
	public String[] typeList;
	@XStreamOmitField
	public String[] complexList;

	@XStreamAlias("GenInfo")
	public GenInfo GenInfo;

	@XStreamAlias("IDnType")
	public IDnType IDnType;

	@XStreamAlias("Properties")
	public Properties Properties;

	@XStreamAlias("IOVariables")
	public IOVariables IOVariables;

	@XStreamAlias("Services")
	public Services Services;

	@XStreamAlias("Infra")
	public InfraStructure Infra;

	@XStreamAlias("SafeSecure")
	public SafeSecure SafeSecure;

	@XStreamAlias("Modelling")
	public Modelling Modelling;

	@XStreamAlias("ExecutableForm")
	public ExecutableForm ExecutableForm;

	public Module() {
		GenInfo = new GenInfo();
		IDnType = new IDnType();
		Properties = new Properties();
		Services = new Services();
		IOVariables = new IOVariables();
		Infra = new InfraStructure();
		SafeSecure = new SafeSecure();
		Modelling = new Modelling();
		ExecutableForm = new ExecutableForm();
		setInfoList();
	}

	public void setInfoList() {
		this.unitList = new String[] { "none", "cm", "millimetre", "meter", "milligram", "gram", "kilogram", "g-cm²",
				"degree",
				"radian", "rpm", "sec", "bps", "Kbps", "ampere", "volt", "watt", "milliwatt", "Celsius" };
		this.typeList = new String[]{"bool", "string", "int", "int8", "int16", "int32", "int64", "uint8", "uint16",
				"uint32", "uint64", "float32", "float64", "any", "enumeration", "void", "class" };
		this.complexList = new String[] { "None", "array", "class", "pointer", "vector" };
	}
}
