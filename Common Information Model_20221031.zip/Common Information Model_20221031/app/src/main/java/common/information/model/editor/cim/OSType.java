package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("OSType")
public class OSType {

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String mType;

    @XStreamAsAttribute
    @XStreamAlias("bits")
    private String mBits;

    @XStreamAsAttribute
    @XStreamAlias("version")
    private String mVersion;

    public void setType(String type) {
        this.mType = type;
    }

    public String getType() {
        return mType;
    }

    public void setVersion(String version) {
        this.mVersion = version;
    }

    public String getVersion() {
        return mVersion;
    }

    public void setBits(String bits) {
        this.mBits = bits;
    }

    public String getBits() {
        return mBits;
    }
}
