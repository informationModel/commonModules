package common.information.model.editor.cim;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Output")
public class Output extends IOVariable {
	@XStreamAlias("Outputs")
	@XStreamImplicit
	public List<Output> outputs = new ArrayList<>();

	@SuppressWarnings("unchecked")
	@Override
	public List<IOVariable> getClassType() {
		List<?> l = outputs;
		return (List<IOVariable>) l;
	}
}
