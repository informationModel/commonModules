package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Overall")
public class Overall {

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String overallType;

    @XStreamAsAttribute
    @XStreamAlias("value")
    private String overallValue;

    public void setOverallType(String overallType) {
        this.overallType = overallType;
    }

    public String getOverallType() {
        return overallType;
    }

    public void setOverallValue(String overallValue) {
        this.overallValue = overallValue;
    }

    public String getOverallValue() {
        return overallValue;
    }
}
