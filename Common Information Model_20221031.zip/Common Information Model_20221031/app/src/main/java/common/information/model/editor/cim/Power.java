package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Powers")
public class Power {

    @XStreamAsAttribute
    @XStreamAlias("value")
    public String powerValue;

    @XStreamAsAttribute
    @XStreamAlias("unit")
    public String powerUnit;

}
