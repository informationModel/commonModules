package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("ElecPower")
public class Powers {

    @XStreamAlias("RatedPower")
    public Power ratedPower;

    @XStreamAlias("MaxPower")
    public Power maxPower;

    public Powers() {
        ratedPower = new Power();
        maxPower = new Power();
    }
}