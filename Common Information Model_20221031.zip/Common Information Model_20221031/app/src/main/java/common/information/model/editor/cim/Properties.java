package common.information.model.editor.cim;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class Properties {

    @XStreamImplicit
    private List<Property> mProperties;

    @XStreamAlias("OStype")
    public OSType mOSType;

    @XStreamAlias("CompilerType")
    public CompilerType mCompilerType;

    @XStreamAlias("ExecutionType")
    public ExecutionType mExecutionType;

    @XStreamAlias("Libraries")
    private Libraries mLibraries;

    public Properties() {
        mOSType = new OSType();
        mCompilerType = new CompilerType();
        mExecutionType = new ExecutionType();
        mLibraries = new Libraries();
    }

    public void setProperties(List<Property> properties) {
        this.mProperties = properties;
    }

    public List<Property> getProperties() {
        return mProperties;
    }

    public Libraries getmLibraries() {
        return mLibraries;
    }

    public void setmLibraries(Libraries mLibraries) {
        this.mLibraries = mLibraries;
    }

    public ExecutionType getmExecutionType() {
        return mExecutionType;
    }

    public void setmExecutionType(ExecutionType mExecutionType) {
        this.mExecutionType = mExecutionType;
    }

    public CompilerType getmCompilerType() {
        return mCompilerType;
    }

    public void setmCompilerType(CompilerType mCompilerType) {
        this.mCompilerType = mCompilerType;
    }

    public OSType getmOSType() {
        return mOSType;
    }

    public void setmOSType(OSType mOSType) {
        this.mOSType = mOSType;
    }

}