package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("Property")
public class Property {

    @XStreamOmitField
    private boolean isClass, isNone, isArray, isVector, isPointer;

    @XStreamAsAttribute
    @XStreamAlias("name")
    private String mName;

    @XStreamAsAttribute
    @XStreamAlias("complex")
    private String mComplex;

    @XStreamAsAttribute
    @XStreamAlias("complexName")
    private String complexName;

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String mType;

    @XStreamAsAttribute
    @XStreamAlias("unit")
    private String mUnit;

    @XStreamAsAttribute
    @XStreamAlias("description")
    private String mDescription;

    @XStreamAsAttribute
    @XStreamAlias("value")
    private String mValue;

    @XStreamAlias("Value")
    private Values values;

    @XStreamAsAttribute
    @XStreamAlias("inDataType")
    private String inDataType;

    @XStreamImplicit
    @XStreamAlias("Property")
    public List<Property> mProperties = new LinkedList<>();

    public String getInDataType() {
        return inDataType;
    }

    public void setInDataType(String inDataType) {
        this.inDataType = inDataType;
    }

    public void createValues() {
        values = new Values();
    }

    public Values getValues() {
        return values;
    }

    public void setValues(Values values) {
        this.values = values;
    }

    public void setName(String name) {
        if (name == "") {
            this.mName = null;
        } else
            this.mName = name;
    }

    public String getName() {
        return mName;
    }

    public String getmComplex() {
        return mComplex;
    }

    public void setmComplex(String mComplex) {
        this.mComplex = mComplex;
    }

    public void setType(String type) {
        this.mType = type;
    }

    public String getType() {
        return mType;
    }

    public void setUnit(String unit) {
        this.mUnit = unit;
    }

    public String getUnit() {
        return mUnit;
    }

    public void setDescription(String description) {
        this.mDescription = description;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setValue(String value) {
        this.mValue = value;
    }

    public String getValue() {
        return mValue;
    }

    public String getComplexName() {
        return complexName;
    }

    public void setComplexName(String complexName) {
        this.complexName = complexName;
    }

    public boolean isPointer() {
        return isPointer;
    }

    public void setPointer(boolean isPointer) {
        this.isPointer = isPointer;
    }

    public boolean isVector() {
        return isVector;
    }

    public void setVector(boolean isVector) {
        this.isVector = isVector;
    }

    public boolean isArray() {
        return isArray;
    }

    public void setArray(boolean isArray) {
        this.isArray = isArray;
    }

    public boolean isNone() {
        return isNone;
    }

    public void setNone(boolean isNone) {
        this.isNone = isNone;
    }

    public boolean isClass() {
        return isClass;
    }

    public void setClass(boolean isClass) {
        this.isClass = isClass;
    }
}