package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class RangeString {
    @XStreamAsAttribute
    @XStreamAlias("min")
    private String min;

    @XStreamAsAttribute
    @XStreamAlias("max")
    private String max;

    public RangeString() {

    }

    public RangeString(String min, String max) {
        this.min = min;
        this.max = max;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }
}
