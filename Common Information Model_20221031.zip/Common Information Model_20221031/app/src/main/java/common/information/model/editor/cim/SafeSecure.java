package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("SafeSecure")
public class SafeSecure {

	@XStreamAlias("Safety")
	public Safety safety;

	@XStreamAlias("Security")
	public Security security;

	public SafeSecure() {

	}

	public void createSafety() {
		this.safety = new Safety();
	}

	public void createSecurity() {
		this.security = new Security();
	}

	public void setSafety(Safety safety) {
		this.safety = safety;
	}

	public Safety getSafety() {
		return safety;
	}

	public void setSecurity(Security security) {
		this.security = security;
		this.security.setCyberSecurity(security.getCyberSecurity());
	}

	public Security getSecurity() {
		return security;
	}
}