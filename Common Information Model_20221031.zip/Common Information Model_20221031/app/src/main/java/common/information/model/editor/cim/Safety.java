package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Safety")
public class Safety {

    @XStreamAlias("Overall")
    private Overall overall;

    @XStreamImplicit
    private List<SafetyType> safetyTypes;

    public Safety() {
        this.overall = new Overall();
        this.safetyTypes = new LinkedList<>();
    }

    public void setSafetyTypes() {
        safetyTypes = new LinkedList<>();
    }

    public void setOverall(Overall overall) {
        this.overall = overall;
    }

    public Overall getOverall() {
        return overall;
    }

    public List<SafetyType> getSafetyTypes() {
        return safetyTypes;
    }

}