package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("SafetyType")
public class SafetyType {

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String mSafetyFunctionType;

    @XStreamOmitField
    private String mInSafetyType;

    @XStreamAsAttribute
    @XStreamAlias("value")
    private String mInSafetyValue;

    public void setSafetyFunctionType(String safetyFunctionType) {
        this.mSafetyFunctionType = safetyFunctionType;
    }

    public String getSafetyFunctionType() {
        return mSafetyFunctionType;
    }

    public void setInSafetyType(String inSafetyType) {
        this.mInSafetyType = inSafetyType;
    }

    public String getInSafetyType() {
        return mInSafetyType;
    }

    public void setInSafetyValue(String inSafetyValue) {
        this.mInSafetyValue = inSafetyValue;
    }

    public String getInSafetyValue() {
        return mInSafetyValue;
    }
}