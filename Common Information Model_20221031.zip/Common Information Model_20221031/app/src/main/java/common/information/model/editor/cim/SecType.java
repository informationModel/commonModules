package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("SecType")
public class SecType {

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String mCybFunctionType;

    @XStreamOmitField
    private String mInCybType;

    @XStreamAsAttribute
    @XStreamAlias("value")
    private String mInCybValue;

    public void setCybFunctionType(String cybFunctionType) {
        this.mCybFunctionType = cybFunctionType;
    }

    public String getCybFunctionType() {
        return mCybFunctionType;
    }

    public void setInCybType(String inCybType) {
        this.mInCybType = inCybType;
    }

    public String getInCybType() {
        return mInCybType;
    }

    public void setInCybValue(String inCybValue) {
        this.mInCybValue = inCybValue;
    }

    public String getInCybValue() {
        return mInCybValue;
    }
}