package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Security")
public class Security {
    @XStreamAlias("PhyisicalSecurity")
    private PhysicalSecurity physicalSecurity;

    @XStreamAlias("CyberSecurity")
    private CyberSecurity cyberSecurity;

    public void setPhysicalSecurity() {
        physicalSecurity = new PhysicalSecurity();
    }

    public void setCyberSecurity() {
        if (cyberSecurity == null)
            cyberSecurity = new CyberSecurity();
    }

    public CyberSecurity getCyberSecurity() {
        return cyberSecurity;
    }

    public PhysicalSecurity getPhysicalSecurity() {
        return physicalSecurity;
    }

    public void setCyberSecurity(CyberSecurity cyberSecurity) {
        this.cyberSecurity = cyberSecurity;
    }

    public void setPhysicalSecurity(PhysicalSecurity physicalSecurity) {
        this.physicalSecurity = physicalSecurity;
    }
}