package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Service")
public class ServiceProfile {

    @XStreamAsAttribute
    @XStreamAlias("type")
    private String mType; // IDL, XML

    @XStreamAlias("ID")
    private String mID;

    @XStreamAlias("PVType")
    private String mPvType;

    @XStreamAlias("MOType")
    private String mMOType;

    @XStreamAlias("IDLPath")
    private String path;

    @XStreamImplicit
    private List<ServicesProperties> mProperties;

    @XStreamAlias("Methods")
    private List<Method> mMethods;

    public void setType(String type) {
        this.mType = type;
    }

    public String getType() {
        return mType;
    }

    public void setID(String ID) {
        this.mID = ID;
    }

    public String getID() {
        return mID;
    }

    public void setPvType(String pvType) {
        this.mPvType = pvType;
    }

    public String getPvType() {
        return mPvType;
    }

    public void createProperties() {
        if (mProperties == null) {
            this.mProperties = new LinkedList<>();
        }
    }

    public void setProperties(List<ServicesProperties> properties) {
        this.mProperties = properties;
    }

    public List<ServicesProperties> getProperties() {
        return mProperties;
    }

    public void setMOType(String moType) {
        this.mMOType = moType;
    }

    public String getMoType() {
        return mMOType;
    }

    public void createMethods() {
        if (mMethods == null)
            this.mMethods = new LinkedList<>();
    }

    public List<Method> getMethods() {
        return mMethods;
    }
    
    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
