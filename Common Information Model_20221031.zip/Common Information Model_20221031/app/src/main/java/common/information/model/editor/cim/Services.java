package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Services")
public class Services {

    @XStreamImplicit
    private List<ServiceProfile> serviceProfiles;
    
    public Services(){
        serviceProfiles = new LinkedList<>();
    }

    public List<ServiceProfile> getServiceProfiles() {
        return serviceProfiles;
    }
}
