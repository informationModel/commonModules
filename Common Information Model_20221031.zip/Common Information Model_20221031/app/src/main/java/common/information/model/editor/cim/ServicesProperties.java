package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Properties")
public class ServicesProperties {

    @XStreamAlias("Name")
    @XStreamAsAttribute
    public String name = "";

    @XStreamAlias("Value")
    @XStreamAsAttribute
    public String value = "";

}