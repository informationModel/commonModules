package common.information.model.editor.cim;

import java.util.LinkedList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("Shell")
public class Shell {
    @XStreamImplicit(itemFieldName = "Item")
    public List<String> shellCmd;

    public Shell() {
        shellCmd = new LinkedList<>();
    }
}