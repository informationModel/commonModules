package common.information.model.editor.cim;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

public class Speed {

    @XStreamAsAttribute
    public String value = "";

    @XStreamAsAttribute
    public String unit = "";

}