package common.information.model.editor.view.dialog;

import java.util.function.Consumer;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.window.IShellProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class NonblockDialog extends Dialog {
    public NonblockDialog(Shell parentShell) {
        super(parentShell);
    }

    public NonblockDialog(IShellProvider parentShell) {
        super(parentShell);
    }

    @Override
    public final int open() {
        open(null);
        return Dialog.OK;
    }

    public final void open(Consumer<Integer> callback) {
        setBlockOnOpen(false);
        super.open();
        if (callback != null) {
            var shell = getShell();
            var listener = new Listener() {
                @Override
                public void handleEvent(Event event) {
                    shell.removeListener(SWT.Close, this);
                    shell.removeListener(SWT.Dispose, this);
                    callback.accept(getReturnCode());
                }
            };

            shell.addListener(SWT.Close, listener);
            shell.addListener(SWT.Dispose, listener);
        }
    }

    @Override
    protected void createButtonsForButtonBar(Composite parent) {
        // create OK and Cancel buttons by default
        createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,
                true);
        createButton(parent, IDialogConstants.CANCEL_ID,
                IDialogConstants.CANCEL_LABEL, false);
    }

}
