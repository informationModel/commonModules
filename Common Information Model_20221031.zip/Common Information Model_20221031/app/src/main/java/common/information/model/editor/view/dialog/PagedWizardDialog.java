package common.information.model.editor.view.dialog;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IPageChangedListener;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;

public class PagedWizardDialog extends WizardDialog {
	private IWizardPage[] mPages;
	private Button[] mButtons;
	private Button mPrevButton;

	public PagedWizardDialog(Shell parentShell, IWizard newWizard) {
		super(parentShell, newWizard);
	}

	@Override
	protected Control createDialogArea(Composite parent) {

		mPages = getWizard().getPages();

		Composite composite = (Composite) super.createDialogArea(parent);
		composite.setLayout(new GridLayout(1, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, mPages.length, 1));

		Group grpStep = new Group(composite, SWT.NONE);

		GridLayout layout = new GridLayout();
		layout.numColumns = mPages.length;
		layout.makeColumnsEqualWidth = true;

		grpStep.setLayout(layout);
		grpStep.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpStep.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		grpStep.setText("Progress");

		mButtons = new Button[mPages.length];
		for (int i = 0; i < mPages.length; i++) {
			Button button = new Button(grpStep, SWT.NONE);
			button.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
			button.setText(mPages[i].getTitle());
			button.setData(mPages[i]);
			button.addSelectionListener(onClickButton);
			mButtons[i] = button;
		}

		addPageChangedListener(onPageChanged);
		return composite;
	}

	@Override
	protected Button createButton(Composite parent, int id, String label, boolean defaultButton) {
		var button = super.createButton(parent, id, label, defaultButton);
		if (id == IDialogConstants.NEXT_ID || id == IDialogConstants.BACK_ID) {
			button.setVisible(false);
		}
		return button;
	}

	private final IPageChangedListener onPageChanged = (event) -> {
		int index = indexOf(event.getSelectedPage());
		if (index >= 0) {
			Button button = mButtons[index];
			if (mPrevButton != null) {
				mPrevButton.setForeground(new Color(null, 0, 0, 0));
				if (mPrevButton.getData() instanceof IWizardPage) {
					var prevPage = (IWizardPage) mPrevButton.getData();
					if (prevPage.isPageComplete()) {
						mPrevButton.setFont(SWTResourceManager.getBoldFont(button.getFont()));
					}
				}
			}
			button.setForeground(new Color(null, 0, 0, 255));
			mPrevButton = button;
		}
	};

	private final SelectionAdapter onClickButton = new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			Button btn = (Button) e.getSource();
			Object data = btn.getData();
			if (data instanceof IWizardPage) {
				IWizardPage page = (IWizardPage) data;
				int index = indexOf(page);

				showPage(page);
				if (index > 0) {
					page.setPreviousPage(mPages[index - 1]);
				} else {
					page.setPreviousPage(null);
				}
				updateButtons();
			}
		}
	};

	private int indexOf(Object page) {
		for (int i = 0; i < mPages.length; i++) {
			if (mPages[i] == page) {
				return i;
			}
		}
		return -1;
	}
}
