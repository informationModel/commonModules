package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeNode;

import common.information.model.editor.cim.IOVariable;
import common.information.model.editor.cim.InOut;
import common.information.model.editor.cim.Input;
import common.information.model.editor.cim.Output;

public class IOVariableLabelProvider extends LabelProvider {
    @Override
    public String getText(Object element) {
        if (!(element instanceof TreeNode))
            return super.getText(element);

        var node = (TreeNode) element;
        if (node.getValue() instanceof Input) {
            Input input = ((Input) node.getValue());
            if (input.value == null && input.complex == null) {
                return "(" + input.type + ") " + input.name + ", "
                        + input.unit + ", " + input.description;
            } else {
                return getComplexText(input);
            }
        } else if (node.getValue() instanceof Output) {
            Output output = ((Output) node.getValue());
            if (output.value == null && output.complex == null) {
                return "(" + output.type + ") " + output.name + ", "
                        + output.unit + ", " + output.description;
            } else {
                return getComplexText(output);
            }
        } else if (node.getValue() instanceof InOut) {
            InOut inout = ((InOut) node.getValue());
            if (inout.value == null && inout.complex == null) {
                return "(" + inout.type + ") " + inout.name + ", "
                        + inout.unit + ", " + inout.description;
            } else {
                return getComplexText(inout);
            }
        }
        return super.getText(element);
    }

    public String getComplexText(Object obj) {

        String text = "";

        IOVariable ioVariable = (IOVariable) obj;

        if (ioVariable.complex == null) {
            text = "(" + ioVariable.type + ") " + ioVariable.name + ", "
                    + ioVariable.unit + ", " + ioVariable.description + ", " + ioVariable.value;

            ioVariable.isNone = true;
        }

        else if (ioVariable.complex.equals("array")) {
            String values = "";
            for (int i = 0; i < ioVariable.values.item.size(); i++) {
                if (i == 0)
                    values += "[";
                values += ioVariable.values.item.get(i);
                if (i == ioVariable.values.item.size() - 1)
                    values += "]";
                else
                    values += ", ";
            }
            text = "(" + ioVariable.complex + ") " + ioVariable.name + ", "
                    + ioVariable.type + ", " + ioVariable.unit + ioVariable.description + ", " + values;

            ioVariable.isArray = true;
        }

        else if (ioVariable.complex.equals("class")) {
            text = "(" + ioVariable.complex + ") " + ioVariable.name + ", " + ioVariable.clsName;

            ioVariable.isClass = true;
        }

        else if (ioVariable.complex.equals("vector")) {
            String values = "";
            for (int i = 0; i < ioVariable.values.item.size(); i++) {
                if (i == 0)
                    values += "[";
                values += ioVariable.values.item.get(i);
                if (i == ioVariable.values.item.size() - 1)
                    values += "]";
                else
                    values += ", ";
            }
            text = "(" + ioVariable.complex + ") " + ioVariable.name + ", "
                    + ioVariable.type + ", " + ioVariable.unit + ioVariable.description + ", " + values;

            ioVariable.isVector = true;
        }

        else if (ioVariable.complex.equals("pointer")) {
            text = "(" + ioVariable.complex + ") " + ioVariable.name + ", " + ioVariable.inDataType;
            ioVariable.isPointer = true;
        }

        return text;
    }

}