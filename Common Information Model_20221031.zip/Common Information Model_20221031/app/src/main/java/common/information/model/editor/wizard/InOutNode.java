package common.information.model.editor.wizard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeViewer;

import common.information.model.editor.cim.InOut;

public class InOutNode extends TreeNode {
	public InOutNode() {
		this(new InOut());
	}

	public InOutNode(InOut value) {
		super(value);
	}

	@Override
	public InOut getValue() {
		return (InOut) value;
	}

	public void setValue(InOut inOut) {
		super.value = inOut;
	}

	/**
	 * Edit을 통한 Update시 Output과 하위의 트리를 생성 및 설정
	 * 
	 * @param inOut  Root 아래의 최상위 노드
	 * @param viewer 트리뷰어
	 */
	public void setNode(InOut inOut, TreeViewer viewer) {
		InOutNode[] children = null;
		setValue(inOut);

		if (inOut.inouts != null) {
			children = new InOutNode[inOut.inouts.size()];
			for (int i = 0; i < inOut.inouts.size(); i++) {
				children[i] = new InOutNode(inOut.inouts.get(i));
				children[i].setNode(inOut.inouts.get(i), viewer);
				children[i].setParent(this);
			}
			setChildren(children);
			viewer.add(this, children);
		} else {
			return;
		}
	}

	public InOutNode addChild(TreeViewer viewer, InOut inOut, Boolean isOld) {
		var node = new InOutNode(inOut);
		var old = getChildren();
		TreeNode[] children;
		if (old != null) {
			children = Arrays.copyOf(old, old.length + 1);
			children[old.length] = node;
		} else {
			children = new TreeNode[] { node };
		}

		if (isOld == false) {
			if (getValue().inouts == null) {
				List<InOut> outputList = new ArrayList<>();
				getValue().inouts = outputList;
			} else {
			}
			getValue().inouts.add(inOut);
		} else {
		}

		node.setParent(this);
		setChildren(children);
		viewer.add(this, node);

		return node;
	}

	public boolean removeChild(TreeViewer viewer, String name) {
		var old = getChildren();
		if (old == null)
			return false;

		var index = IntStream.range(0, old.length)
				.filter(i -> name.equals(((InOut) old[i].getValue()).name))
				.findFirst().orElse(-1);
		if (index < 0)
			return false;

		var children = new TreeNode[old.length - 1];
		System.arraycopy(old, 0, children, 0, index);
		System.arraycopy(old, index + 1, children, index, old.length - index - 1);
		getValue().inouts.remove(index);

		old[index].setParent(null);
		viewer.remove(this, index);
		return true;
	}
}
