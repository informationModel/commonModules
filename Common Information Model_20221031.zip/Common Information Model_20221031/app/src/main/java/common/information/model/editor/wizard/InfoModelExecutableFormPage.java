package common.information.model.editor.wizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.cim.Module;

public class InfoModelExecutableFormPage extends WizardPage {
    private Text text_mainurl, text_liburl;
    private Table table_main, table_lib, table_shell;

    private Module module;
    private boolean isOld = false;
    private Text text_shellCmd;
    private Button btn_libDel, btn_mainDel, btn_libAdd, btn_mainAdd, btn_shellAdd, btn_shellDel, btn_shellUpdate,
            btn_libUpdate, btn_mainUpdate;

    public InfoModelExecutableFormPage(Module module) {
        super("wizardPage", "ExecutableForm", null);
        setDescription("Enter ExecutableForm");
        this.module = module;
    }

    public InfoModelExecutableFormPage(Module module, boolean isOld) {
        super("wizardPage", "ExecutableForm", null);
        setDescription("Enter ExecutableForm");
        this.module = module;
        this.isOld = isOld;
    }

    @Override
    public void createControl(Composite parent) {

        ExeAddSelectionListener exeAddSelectionListener = new ExeAddSelectionListener();
        Composite rootComposite = new Composite(parent, SWT.NONE);

        setControl(rootComposite);
        rootComposite.setLayout(new GridLayout(1, false));

        ScrolledComposite scrolledComposite = new ScrolledComposite(rootComposite,
                SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
        scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
        scrolledComposite.setExpandHorizontal(true);
        scrolledComposite.setExpandVertical(true);

        Composite composite = new Composite(scrolledComposite, SWT.NONE);
        composite.setLayout(new GridLayout(1, false));

        Group grpMain = new Group(composite, SWT.NONE);
        grpMain.setLayout(new GridLayout(3, false));
        grpMain.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        grpMain.setText("Main");

        Label lblMainurls = new Label(grpMain, SWT.NONE);
        lblMainurls.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
        lblMainurls.setText("Input ExForm (url, path of file, exe, sh, ph ...)");

        text_mainurl = new Text(grpMain, SWT.BORDER);
        text_mainurl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

        Composite composite_main = new Composite(grpMain, SWT.NONE);
        composite_main.setLayout(new GridLayout(3, false));
        composite_main.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

        btn_mainAdd = new Button(composite_main, SWT.NONE);
        btn_mainAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_mainAdd.setText("Add");
        btn_mainAdd.addSelectionListener(exeAddSelectionListener);

        btn_mainUpdate = new Button(composite_main, SWT.NONE);
        btn_mainUpdate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_mainUpdate.setText("Update");
        btn_mainUpdate.addSelectionListener(exeAddSelectionListener);

        btn_mainDel = new Button(composite_main, SWT.NONE);
        btn_mainDel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_mainDel.setText("Delete");
        btn_mainDel.addSelectionListener(exeAddSelectionListener);

        table_main = new Table(grpMain, SWT.BORDER | SWT.FULL_SELECTION);
        table_main.setHeaderVisible(true);
        table_main.setLinesVisible(true);
        GridData gd_table_main = new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1);
        gd_table_main.heightHint = 150;
        table_main.setLayoutData(gd_table_main);
        table_main.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                var selected = table_main.getSelection()[0];
                text_mainurl.setText(selected.getText());
            }
        });

        TableColumn tblclmn_mainItem = new TableColumn(table_main, SWT.NONE);
        tblclmn_mainItem.setWidth(450);
        tblclmn_mainItem.setText("Main Executable Form");

        table_main.addControlListener(new ControlListener() {
            @Override
            public void controlResized(ControlEvent e) {
                Rectangle rect = table_main.getClientArea();
                if (rect.width > 0) {
                    tblclmn_mainItem.setWidth(rect.width);
                }
            }

            @Override
            public void controlMoved(ControlEvent e) {
                // TODO Auto-generated method stub
            }
        });

        Group grpLib = new Group(composite, SWT.NONE);
        grpLib.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        grpLib.setText("Lib");
        grpLib.setLayout(new GridLayout(4, false));

        Label lblLiburls = new Label(grpLib, SWT.NONE);
        lblLiburls.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
        lblLiburls.setText("Input ExForm (url, path of file, exe, sh, ph ...)");

        text_liburl = new Text(grpLib, SWT.BORDER);
        text_liburl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 2));

        Composite composite_lib = new Composite(grpLib, SWT.NONE);
        composite_lib.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
        composite_lib.setLayout(new GridLayout(3, false));

        btn_libAdd = new Button(composite_lib, SWT.NONE);
        btn_libAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_libAdd.setText("Add");
        btn_libAdd.addSelectionListener(exeAddSelectionListener);

        btn_libUpdate = new Button(composite_lib, SWT.NONE);
        btn_libUpdate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_libUpdate.setText("Update");
        btn_libUpdate.addSelectionListener(exeAddSelectionListener);

        btn_libDel = new Button(composite_lib, SWT.NONE);
        btn_libDel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_libDel.setText("Delete");
        btn_libDel.addSelectionListener(exeAddSelectionListener);

        table_lib = new Table(grpLib, SWT.BORDER | SWT.FULL_SELECTION);
        table_lib.setLinesVisible(true);
        table_lib.setHeaderVisible(true);
        GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 4, 1);
        gd_table.heightHint = 150;
        table_lib.setLayoutData(gd_table);

        table_lib.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                var selected = table_lib.getSelection()[0];
                text_liburl.setText(selected.getText());
            }
        });

        TableColumn tblclmn_libItem = new TableColumn(table_lib, SWT.NONE);
        tblclmn_libItem.setWidth(450);
        tblclmn_libItem.setText("Lib Executable Form");

        table_lib.addControlListener(new ControlListener() {
            @Override
            public void controlResized(ControlEvent e) {
                Rectangle rect = table_lib.getClientArea();
                if (rect.width > 0) {
                    tblclmn_libItem.setWidth(rect.width);
                }
            }

            @Override
            public void controlMoved(ControlEvent e) {
                // TODO Auto-generated method stub
            }
        });

        Group grpShellCommand = new Group(composite, SWT.NONE);
        grpShellCommand.setLayout(new GridLayout(1, false));
        grpShellCommand.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
        grpShellCommand.setText("Shell Command");

        Label lbl_InputCommand = new Label(grpShellCommand, SWT.NONE);
        lbl_InputCommand.setText("Input Command");

        text_shellCmd = new Text(grpShellCommand, SWT.BORDER);
        text_shellCmd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

        Composite composite_shell = new Composite(grpShellCommand, SWT.NONE);
        composite_shell.setLayout(new GridLayout(3, false));
        composite_shell.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

        btn_shellAdd = new Button(composite_shell, SWT.NONE);
        btn_shellAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_shellAdd.setText("Add");
        btn_shellAdd.addSelectionListener(exeAddSelectionListener);

        btn_shellUpdate = new Button(composite_shell, SWT.NONE);
        btn_shellUpdate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_shellUpdate.setText("Update");
        btn_shellUpdate.addSelectionListener(exeAddSelectionListener);

        btn_shellDel = new Button(composite_shell, SWT.NONE);
        btn_shellDel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_shellDel.setText("Delete");
        btn_shellDel.addSelectionListener(exeAddSelectionListener);

        table_shell = new Table(grpShellCommand, SWT.BORDER | SWT.FULL_SELECTION);
        table_shell.setHeaderVisible(true);
        table_shell.setLinesVisible(true);
        GridData gd_table_shell = new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1);
        gd_table_shell.heightHint = 150;
        table_shell.setLayoutData(gd_table_shell);
        table_shell.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                var selected = table_shell.getSelection()[0];
                text_shellCmd.setText(selected.getText());
            }
        });

        TableColumn tblclmn_shell = new TableColumn(table_shell, SWT.NONE);
        tblclmn_shell.setWidth(100);
        tblclmn_shell.setText("Command");
        table_shell.addControlListener(new ControlListener() {
            @Override
            public void controlResized(ControlEvent e) {
                Rectangle rect = table_shell.getClientArea();
                if (rect.width > 0) {
                    tblclmn_shell.setWidth(rect.width);
                }
            }

            @Override
            public void controlMoved(ControlEvent e) {
                // TODO Auto-generated method stub
            }
        });

        scrolledComposite.setContent(composite);
        scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
        // setPageComplete(false);

        setExFormPage(isOld);
    }

    public class ExeAddSelectionListener extends SelectionAdapter {
        @Override
        public void widgetSelected(SelectionEvent e) {

            if (e.getSource() == btn_mainAdd) {
                TableItem tableItem = new TableItem(table_main, SWT.NONE);
                String url = text_mainurl.getText();
                tableItem.setText(0, url);
                table_main.setSelection(tableItem);
                module.ExecutableForm.setMainURLs();
                module.ExecutableForm.main.urlnPath.add(url);
                text_mainurl.setText("");

            } else if (e.getSource() == btn_mainDel) {
                var selected = table_main.getSelection()[0];
                var idx = table_main.indexOf(selected);
                table_main.remove(idx);
                module.ExecutableForm.setMainURLs();
                module.ExecutableForm.main.urlnPath.remove(idx);
                text_mainurl.setText("");

            } else if (e.getSource() == btn_mainUpdate) {
                var selected = table_main.getSelection()[0];
                var idx = table_main.indexOf(selected);
                String url = text_mainurl.getText();
                selected.setText(0, url);
                module.ExecutableForm.setMainURLs();
                module.ExecutableForm.main.urlnPath.set(idx, url);

            } else if (e.getSource() == btn_libAdd) {
                TableItem tableItem = new TableItem(table_lib, SWT.NONE);
                String url = text_liburl.getText();
                tableItem.setText(0, url);
                table_lib.setSelection(tableItem);
                module.ExecutableForm.setLibURLs();
                module.ExecutableForm.lib.urlnPath.add(url);
                text_liburl.setText("");

            } else if (e.getSource() == btn_libDel) {
                var selected = table_lib.getSelection()[0];
                var idx = table_lib.indexOf(selected);
                table_lib.remove(idx);
                module.ExecutableForm.setLibURLs();
                module.ExecutableForm.lib.urlnPath.remove(idx);
                text_liburl.setText("");

            } else if (e.getSource() == btn_libUpdate) {
                var selected = table_lib.getSelection()[0];
                var idx = table_lib.indexOf(selected);
                String url = text_liburl.getText();
                selected.setText(0, url);
                module.ExecutableForm.setLibURLs();
                module.ExecutableForm.lib.urlnPath.set(idx, url);

            } else if (e.getSource() == btn_shellAdd) {
                TableItem tableItem = new TableItem(table_shell, SWT.NONE);
                String cmd = text_shellCmd.getText();
                tableItem.setText(0, cmd);
                table_shell.setSelection(tableItem);
                module.ExecutableForm.setShellCmd();
                module.ExecutableForm.shell.shellCmd.add(cmd);
                text_shellCmd.setText("");

            } else if (e.getSource() == btn_shellDel) {
                var selected = table_shell.getSelection()[0];
                var idx = table_shell.indexOf(selected);
                table_shell.remove(idx);
                module.ExecutableForm.setShellCmd();
                module.ExecutableForm.shell.shellCmd.remove(idx);
                text_shellCmd.setText("");

            } else if (e.getSource() == btn_shellUpdate) {
                var selected = table_shell.getSelection()[0];
                var idx = table_shell.indexOf(selected);
                String cmd = text_shellCmd.getText();
                selected.setText(0, cmd);
                module.ExecutableForm.setShellCmd();
                module.ExecutableForm.shell.shellCmd.set(idx, cmd);
            }
        }
    }

    public void setExFormPage(boolean isOld) {
        if (isOld) {
            if (module.ExecutableForm != null) {

                module.ExecutableForm.setMainURLs();
                module.ExecutableForm.setLibURLs();
                module.ExecutableForm.setShellCmd();

                var main = module.ExecutableForm.main.urlnPath;
                var lib = module.ExecutableForm.lib.urlnPath;
                var shell = module.ExecutableForm.shell.shellCmd;

                if (main != null) {
                    for (int i = 0; i < main.size(); i++) {
                        TableItem item = new TableItem(table_main, SWT.NONE);
                        item.setText(0, main.get(i));
                    }
                }
                if (lib != null) {
                    for (int i = 0; i < lib.size(); i++) {
                        TableItem item = new TableItem(table_lib, SWT.NONE);
                        item.setText(0, lib.get(i));
                    }
                }
                if (shell != null) {
                    for (int i = 0; i < shell.size(); i++) {
                        TableItem item = new TableItem(table_shell, SWT.NONE);
                        item.setText(0, shell.get(i));
                    }
                }
            } else
                System.out.println("ExecutableForm 정보가 없습니다.");
        }
    }
}