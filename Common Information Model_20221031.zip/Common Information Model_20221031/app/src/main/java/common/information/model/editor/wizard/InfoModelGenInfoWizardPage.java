package common.information.model.editor.wizard;

import java.util.UUID;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.cim.GenInfo;
import common.information.model.editor.cim.Module;

public class InfoModelGenInfoWizardPage extends WizardPage {
	public Text mVenderID, mModuleName, mModuleID, mIID, mMajorNumber, mMinorNumber, mDescription, mExamples,
			mVSPID_1, mSerial, mManufacturer;
	public Button safetyBtn, secBtn;
	private Module module;
	private Button hwswBtn;
	private Button hwBtn;
	private Button swBtn;
	private Button toolsBtn;
	private Button basicBtn;
	private Button compositeBtn;
	private boolean isOld;
	private int compValue, swValue, hwValue, safetyValue, securityValue = 0;
	private String zeroLevelValue, firstLevelValue;
	private Button moduleBtn;
	private Text mVSPID_2;
	private Text mVSPID_3;
	private Combo firstClassCombo;

	public InfoModelGenInfoWizardPage(Module module) {
		super("wizardPage", "General Info", null);
		setDescription("Enter General Information");
		this.module = module;
	}

	public InfoModelGenInfoWizardPage(Module module, boolean isOld) {
		super("wizardPage", "General Info", null);
		setDescription("Enter General Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		SelectHwSwInfoListener sHwSwListener = new SelectHwSwInfoListener();
		GenInfoModifyListener gModifyListener = new GenInfoModifyListener();
		LimitKeyValueListener lKeyValueListener = new LimitKeyValueListener();
		Composite rootComposite = new Composite(parent, SWT.NONE);

		setControl(rootComposite);
		GridLayout gl_rootComposite = new GridLayout(1, false);
		rootComposite.setLayout(gl_rootComposite);

		ScrolledComposite scrolledComposite = new ScrolledComposite(rootComposite,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		GridData gd_scrolledComposite = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_scrolledComposite.heightHint = 613;
		scrolledComposite.setLayoutData(gd_scrolledComposite);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);

		Composite composite_main = new Composite(scrolledComposite, SWT.NULL);
		composite_main.setLayout(new GridLayout(1, false));

		Composite composite_info = new Composite(composite_main, SWT.NONE);
		composite_info.setLayout(new GridLayout(1, false));
		GridData gd_composite_info = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		composite_info.setLayoutData(gd_composite_info);

		Group grpGeninfo = new Group(composite_info, SWT.NONE);
		grpGeninfo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpGeninfo.setText("General Information");
		grpGeninfo.setLayout(new GridLayout(4, false));

		Label moduleNameLabel = new Label(grpGeninfo, SWT.NONE);
		moduleNameLabel.setText("Module Name");

		mModuleName = new Text(grpGeninfo, SWT.BORDER);
		mModuleName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
		mModuleName.addModifyListener(gModifyListener);

		Label manufacturerlbl = new Label(grpGeninfo, SWT.NONE);
		manufacturerlbl.setText("Manufacturer");

		mManufacturer = new Text(grpGeninfo, SWT.BORDER);
		mManufacturer.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));
		mManufacturer.addModifyListener(gModifyListener);

		Composite geninfoComp = new Composite(grpGeninfo, SWT.NONE);
		geninfoComp.setLayout(new GridLayout(2, false));
		geninfoComp.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 4, 1));

		Label descriptionlbl = new Label(geninfoComp, SWT.NONE);
		descriptionlbl.setText("Description");

		Label exampleslbl = new Label(geninfoComp, SWT.NONE);
		exampleslbl.setText("Example");

		mDescription = new Text(geninfoComp, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL);
		GridData descriptionData = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		descriptionData.heightHint = 80;
		mDescription.setLayoutData(descriptionData);
		mDescription.addModifyListener(gModifyListener);

		mExamples = new Text(geninfoComp, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL);
		GridData exampleData = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		exampleData.heightHint = 80;
		mExamples.setLayoutData(exampleData);

		Label venderSpecificlbl = new Label(composite_info, SWT.NONE);
		venderSpecificlbl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		venderSpecificlbl.setText("Vender Specific PID (Hexa)");

		Composite vsPIDComposite = new Composite(composite_info, SWT.NONE);
		vsPIDComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		vsPIDComposite.setLayout(new GridLayout(3, false));

		mVSPID_1 = new Text(vsPIDComposite, SWT.BORDER);
		mVSPID_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mVSPID_1.setMessage("00 ~ ff");
		mVSPID_1.setTextLimit(2);
		mVSPID_1.addVerifyListener(lKeyValueListener);

		mVSPID_2 = new Text(vsPIDComposite, SWT.BORDER);
		mVSPID_2.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mVSPID_2.setMessage("00 ~ ff");
		mVSPID_2.setTextLimit(2);
		mVSPID_2.addVerifyListener(lKeyValueListener);

		mVSPID_3 = new Text(vsPIDComposite, SWT.BORDER);
		mVSPID_3.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mVSPID_3.setMessage("00 ~ ff");
		mVSPID_3.setTextLimit(2);
		mVSPID_3.addVerifyListener(lKeyValueListener);

		Label revisionLabel = new Label(composite_info, SWT.NONE);
		revisionLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		revisionLabel.setText("Revision Number (Hexa)");

		Composite verComposite = new Composite(composite_info, SWT.NONE);
		verComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		verComposite.setLayout(new GridLayout(4, false));

		Label majorNumLabel = new Label(verComposite, SWT.NONE);
		majorNumLabel.setText("Major Number");

		mMajorNumber = new Text(verComposite, SWT.BORDER);
		mMajorNumber.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMajorNumber.setMessage("0000 ~ ffff");
		mMajorNumber.setTextLimit(4);
		mMajorNumber.addVerifyListener(lKeyValueListener);

		Label minorNumLabel = new Label(verComposite, SWT.NONE);
		minorNumLabel.setText("Minor Number");

		mMinorNumber = new Text(verComposite, SWT.BORDER);
		mMinorNumber.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMinorNumber.setMessage("0000 ~ ffff");
		mMinorNumber.setTextLimit(4);
		mMinorNumber.addVerifyListener(lKeyValueListener);

		Label serialLabel = new Label(composite_info, SWT.NONE);
		serialLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		serialLabel.setText("Serial Number (Decimal)");

		mSerial = new Text(composite_info, SWT.BORDER);
		mSerial.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mSerial.setMessage("0 ~ 4,294,967,295");
		mSerial.setTextLimit(10);

		Label instanceLabel = new Label(composite_info, SWT.NONE);
		instanceLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		instanceLabel.setText("Instance ID (0 ~ 255)");

		mIID = new Text(composite_info, SWT.BORDER);
		mIID.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mIID.setText("0");
		mIID.setTextLimit(3);

		Label cbLabel = new Label(composite_info, SWT.NONE);
		cbLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cbLabel.setText("Composite Type");

		Composite cbComposite = new Composite(composite_info, SWT.NONE);
		cbComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		cbComposite.setLayout(new FillLayout(SWT.HORIZONTAL));

		basicBtn = new Button(cbComposite, SWT.RADIO);
		basicBtn.setText("Basic");

		compositeBtn = new Button(cbComposite, SWT.RADIO);
		compositeBtn.setText("Composite");

		Label safeSecureLabel = new Label(composite_info, SWT.NONE);
		safeSecureLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safeSecureLabel.setText("Safety/Security");

		Composite safeSecureComp = new Composite(composite_info, SWT.NONE);
		safeSecureComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safeSecureComp.setLayout(new FillLayout(SWT.HORIZONTAL));

		safetyBtn = new Button(safeSecureComp, SWT.CHECK);
		safetyBtn.setText("Safety");
		safetyBtn.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {

				if (safetyBtn.getSelection()) {
					module.isSafety = true;
					safetyValue = 1;
				} else {
					module.isSafety = false;
					safetyValue = 0;
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				module.isSafety = false;
			}
		});

		secBtn = new Button(safeSecureComp, SWT.CHECK);
		secBtn.setText("Security");

		Label classLabel = new Label(composite_info, SWT.NONE);
		classLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		classLabel.setText("Classfication");

		Composite classificationComp = new Composite(composite_info, SWT.NONE);
		classificationComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		classificationComp.setLayout(new FillLayout(SWT.HORIZONTAL));

		hwswBtn = new Button(classificationComp, SWT.RADIO);
		hwswBtn.setText("HW-SW Modules");
		hwswBtn.addSelectionListener(sHwSwListener);

		hwBtn = new Button(classificationComp, SWT.RADIO);
		hwBtn.setText("HW Modules");
		hwBtn.addSelectionListener(sHwSwListener);

		swBtn = new Button(classificationComp, SWT.RADIO);
		swBtn.setText("SW Modules");
		swBtn.addSelectionListener(sHwSwListener);

		toolsBtn = new Button(classificationComp, SWT.RADIO);
		toolsBtn.setText("Tools");

		Label classfication1Label = new Label(composite_info, SWT.NONE);
		classfication1Label.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		classfication1Label.setText("1st Level Classfication");

		firstClassCombo = new Combo(composite_info, SWT.READ_ONLY);
		firstClassCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		firstClassCombo.setToolTipText("Select Items...");
		firstClassCombo.setItems(new String[] { "Planning", "Sensing", "Actuating", "Communication", "Interaction",
				"Orchestration/Decision Making", "Management" });
		firstClassCombo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int idx = firstClassCombo.getSelectionIndex();
				if (idx == 0)
					firstLevelValue = "0000";
				else if (idx == 1)
					firstLevelValue = "0001";
				else if (idx == 2)
					firstLevelValue = "0010";
				else if (idx == 3)
					firstLevelValue = "0011";
				else if (idx == 4)
					firstLevelValue = "0100";
				else if (idx == 5)
					firstLevelValue = "0101";
				else if (idx == 6)
					firstLevelValue = "0110";
			}
		});
		toolsBtn.addSelectionListener(sHwSwListener);
		secBtn.addSelectionListener(new SelectionListener() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (secBtn.getSelection()) {
					module.isSecurity = true;
					securityValue = 1;
				} else {
					module.isSecurity = false;
					securityValue = 0;
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				module.isSecurity = false;
			}
		});
		compositeBtn.addSelectionListener(sHwSwListener);
		basicBtn.addSelectionListener(sHwSwListener);
		mIID.addListener(SWT.Verify, new Listener() {

			@Override
			public void handleEvent(Event e) {
				String string = e.text;
				char[] chars = new char[string.length()];
				string.getChars(0, chars.length, chars, 0);
				for (int i = 0; i < chars.length; i++) {
					if (!('0' <= chars[i] && chars[i] <= '9' || chars[i] == '.')) {
						e.doit = false;
						return;
					}
				}
			}
		});
		mSerial.addListener(SWT.Verify, new Listener() {

			@Override
			public void handleEvent(Event e) {
				String string = e.text;
				char[] chars = new char[string.length()];
				string.getChars(0, chars.length, chars, 0);
				for (int i = 0; i < chars.length; i++) {
					if (!('0' <= chars[i] && chars[i] <= '9' || chars[i] == '.')) {
						e.doit = false;
						return;
					}
				}
			}
		});

		Composite composite_btn = new Composite(composite_main, SWT.NONE);
		composite_btn.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 1, 1));
		composite_btn.setLayout(new GridLayout(2, false));

		Button btn_edit = new Button(composite_btn, SWT.NONE);
		btn_edit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btn_edit.setText("Edit GenInfo");
		btn_edit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				composite_info.setEnabled(true);
				moduleBtn.setEnabled(true);
			}
		});

		moduleBtn = new Button(composite_btn, SWT.NONE);
		moduleBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		moduleBtn.setText("Create ModuleID");
		moduleBtn.addSelectionListener(new MakeModuleID());
		mExamples.addModifyListener(gModifyListener);

		scrolledComposite.setContent(composite_main);
		scrolledComposite.setMinSize(composite_main.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		setControl(rootComposite);

		if (isOld == true) {
			updatePage(module);
			setComposite(module);
			setSWHWButton(module);
			setSafeSecureButton(module);
			composite_info.setEnabled(false);
			moduleBtn.setEnabled(false);
			btn_edit.setEnabled(true);
			isOld = false;
		} else
			btn_edit.setEnabled(false);
	}

	@Override
	public void setVisible(boolean isVisible) {
		super.setVisible(isVisible);
	}

	public void updateGenInfo(GenInfo genInfo) {
		genInfo.setModuleName(mModuleName.getText());
		genInfo.setManufacturer(mManufacturer.getText());
		genInfo.setDescription(mDescription.getText());
		genInfo.setExamples(mExamples.getText());
	}

	public void updatePage(Module module) {
		mModuleName.setText(module.GenInfo.getModuleName());
		mManufacturer.setText(module.GenInfo.getManufacturer());
		mDescription.setText(module.GenInfo.getDescription());
		mExamples.setText(module.GenInfo.getExamples());
	}

	public void setComposite(Module module) {
		if (module.IDnType.mIDtype != null) {
			if (module.IDnType.mIDtype.equals("Com"))
				compositeBtn.setSelection(true);
			else if (module.IDnType.mIDtype.equals("Bas"))
				basicBtn.setSelection(true);
		}
	}

	// module isHW, SW 설정해주어야 함
	public void setSWHWButton(Module module) {
		if (module.IDnType.mSWList.mSWList != null && module.IDnType.mHWList.mHWList != null) {
			hwswBtn.setSelection(true);
			module.isHw = true;
			module.isSw = true;
		} else if (module.IDnType.mSWList.mSWList != null) {
			swBtn.setSelection(true);
			module.isSw = true;
		} else if (module.IDnType.mHWList.mHWList != null) {
			hwBtn.setSelection(true);
			module.isHw = true;
		} else {
			toolsBtn.setSelection(true);
		}
	}

	public void setSafeSecureButton(Module module) {
		if (module.SafeSecure.getSafety() != null &&
				module.SafeSecure.getSecurity() != null) {
			safetyBtn.setSelection(true);
			secBtn.setSelection(true);
			module.isSafety = true;
			module.isSecurity = true;
		} else if (module.SafeSecure.getSafety() != null) {
			safetyBtn.setSelection(true);
			module.isSafety = true;
		} else if (module.SafeSecure.getSecurity() != null) {
			secBtn.setSelection(true);
			module.isSecurity = true;
		} else {
		}
	}

	/**
	 * Classfiaction 선택 옵션에 관한 리스너
	 */
	public class SelectHwSwInfoListener extends SelectionAdapter {
		@Override
		public void widgetSelected(SelectionEvent e) {
			if (hwswBtn.getSelection()) {
				module.isHw = true;
				module.isSw = true;
				module.isTool = false;
				swValue = 1;
				hwValue = 1;
				zeroLevelValue = "00";
			} else if (hwBtn.getSelection()) {
				module.isHw = true;
				module.isSw = false;
				module.isTool = false;
				swValue = 0;
				hwValue = 1;
				zeroLevelValue = "01";
			} else if (swBtn.getSelection()) {
				module.isHw = false;
				module.isSw = true;
				module.isTool = false;
				swValue = 1;
				hwValue = 0;
				zeroLevelValue = "10";
			} else if (toolsBtn.getSelection()) {
				module.isHw = false;
				module.isSw = false;
				module.isTool = true;
				swValue = 0;
				hwValue = 0;
				zeroLevelValue = "11";
			}
			if (basicBtn.getSelection()) {
				module.IDnType.mIDtype = "Bas";
				compValue = 0;
			} else if (compositeBtn.getSelection()) {
				module.IDnType.mIDtype = "Com";
				compValue = 1;
			}
		}
	}

	public class LimitKeyValueListener implements VerifyListener {

		@Override
		public void verifyText(VerifyEvent event) {
			String string = event.text;
			char[] chars = new char[string.length()];
			string.getChars(0, chars.length, chars, 0);
			for (int i = 0; i < chars.length; i++) {
				if (!('0' <= chars[i] && chars[i] <= '9' || chars[i] == 'a' || chars[i] == 'b' || chars[i] == 'c'
						|| chars[i] == 'd' || chars[i] == 'e' || chars[i] == 'f')) {
					event.doit = false;
					return;
				}
			}
		}

	}

	public class GenInfoModifyListener implements ModifyListener {

		@Override
		public void modifyText(ModifyEvent event) {
			if (!isOld) {
				module.GenInfo.setModuleName(mModuleName.getText());
				module.GenInfo.setManufacturer(mManufacturer.getText());
				module.GenInfo.setDescription(mDescription.getText());
				module.GenInfo.setExamples(mExamples.getText());
			}
			if (!mManufacturer.getText().isEmpty()) {
			} else if (mManufacturer.getText().isEmpty()) {
				
			}
		}
	}

	public class MakeModuleID extends SelectionAdapter {
		@Override
		public void widgetSelected(SelectionEvent e) {
			UUID uuid = UUIDType5.nameUUIDFromNamespaceAndString(UUIDType5.NAMESPACE_DNS, mManufacturer.getText());
			String[] vIDn = uuid.toString().split("-");
			String mVID = vIDn[0] + vIDn[1] + vIDn[2] + vIDn[3] + vIDn[4];
			String sType = Integer.toString(compValue) + Integer.toString(swValue) + Integer.toString(hwValue)
					+ Integer.toString(safetyValue) + Integer.toString(securityValue) + "000";
			int iType = Integer.parseUnsignedInt(sType, 2);
			String pType = Integer.toHexString(iType);
				String vsPID = mVSPID_1.getText() + mVSPID_2.getText() + mVSPID_3.getText();
				String rev = mMajorNumber.getText() + mMinorNumber.getText();
			String sNo = Integer.toHexString(Integer.parseInt(mSerial.getText()));
			String sCID = zeroLevelValue + firstLevelValue + "000000000000000000";
			int iCID = Integer.parseInt(sCID, 2);
			String mCID = Integer.toHexString(iCID);
			String miid = Integer.toHexString(Integer.parseInt(mIID.getText()));
			String moduleID = mVID + "-" + pType + vsPID + "-" + rev + "-" + sNo + "-" + mCID + "-" + miid;
			module.IDnType.moduleID = moduleID;
			System.out.println("ModuleID = " + mVID + pType + vsPID + rev + mCID);
		}
	}

}