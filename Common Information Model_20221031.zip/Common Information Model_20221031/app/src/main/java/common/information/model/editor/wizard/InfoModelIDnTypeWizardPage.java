package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.dnd.DragSource;
import org.eclipse.swt.dnd.DragSourceAdapter;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.cim.Module;

public class InfoModelIDnTypeWizardPage extends WizardPage {
	public Text mModuleID, mIDType, mModuleName, mManufacturer, mDescription, mExample, mSafety, mSecurity,
			mInfoModelVersion;
	private Module module;
	private Group grpHwlist, grpSwlist;
	private Boolean isOld;
	private Composite composite_hwswList, composite_main;
	private ListViewer swListViewer, hwListViewer;

	public InfoModelIDnTypeWizardPage(Module module) {
		super("wizardPage", "IDnType", null);
		setDescription("Enter IDnType Information");
		this.module = module;
		this.isOld = false;
	}

	public InfoModelIDnTypeWizardPage(Module module, Boolean isOld) {
		super("wizardPage", "IDnType", null);
		setDescription("Enter IDnType Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		VersionModifyListener versionModifyListener = new VersionModifyListener();
		Composite rootComposite = new Composite(parent, SWT.NONE);
		rootComposite.setLayout(new GridLayout(1, false));

		ScrolledComposite scrolledComposite = new ScrolledComposite(rootComposite,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);

		composite_main = new Composite(scrolledComposite, SWT.NULL);
		composite_main.setLayout(new GridLayout(1, false));

		Composite composite_idnType = new Composite(composite_main, SWT.NONE);
		composite_idnType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		composite_idnType.setLayout(new GridLayout(1, false));

		Label lblNewLabel_1 = new Label(composite_idnType, SWT.NONE);
		lblNewLabel_1.setSize(52, 15);
		lblNewLabel_1.setText("Module Name");

		mModuleName = new Text(composite_idnType, SWT.BORDER);
		mModuleName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mModuleName.setSize(564, 21);

		Label idTypelbl = new Label(composite_idnType, SWT.NONE);
		idTypelbl.setSize(52, 15);
		idTypelbl.setText("ID type");

		mIDType = new Text(composite_idnType, SWT.BORDER);
		mIDType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mIDType.setSize(564, 21);
		mIDType.setEditable(false);

		Label lblNewLabel = new Label(composite_idnType, SWT.NONE);
		lblNewLabel.setSize(60, 15);
		lblNewLabel.setText("Module ID");

		mModuleID = new Text(composite_idnType, SWT.BORDER);
		mModuleID.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mModuleID.setSize(564, 21);
		mModuleID.setEnabled(false);

		Label lblNewLabel_2 = new Label(composite_idnType, SWT.NONE);
		lblNewLabel_2.setSize(72, 15);
		lblNewLabel_2.setText("Manufacturer");

		mManufacturer = new Text(composite_idnType, SWT.BORDER);
		mManufacturer.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mManufacturer.setSize(564, 21);

		Label lblInfomodelversion = new Label(composite_idnType, SWT.NONE);
		lblInfomodelversion.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblInfomodelversion.setText("InfoModelVersion");

		mInfoModelVersion = new Text(composite_idnType, SWT.BORDER);
		mInfoModelVersion.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mInfoModelVersion.addModifyListener(versionModifyListener);
		mInfoModelVersion.setText("1.0");

		composite_hwswList = new Composite(composite_main, SWT.NONE);
		composite_hwswList.setLayout(new GridLayout(1, false));
		composite_hwswList.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		grpHwlist = new Group(composite_hwswList, SWT.NONE);
		grpHwlist.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpHwlist.setText("HW-List");
		grpHwlist.setLayout(new GridLayout(1, false));

		Composite composite_hw = new Composite(grpHwlist, SWT.NONE);
		composite_hw.setLayout(new GridLayout(3, false));
		composite_hw.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		Text mHWText = new Text(composite_hw, SWT.BORDER);
		mHWText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Button hwAddBtn = new Button(composite_hw, SWT.NONE);
		hwAddBtn.setText("Add");
		hwAddBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (mHWText.getText().equals("")) {
				} else {
					hwListViewer.getList().add(mHWText.getText());
					module.IDnType.mHWList.mHWList.add(mHWText.getText());
					mHWText.setText("");
				}
			}
		});

		Button hwDeleteBtn = new Button(composite_hw, SWT.NONE);
		hwDeleteBtn.setText("Delete");
		hwDeleteBtn.addSelectionListener(new SelectionAdapter() { // delete 버튼 동작
			@Override
			public void widgetSelected(SelectionEvent e) {
				hwListViewer.getList().remove(hwListViewer.getList().getSelectionIndices());
			}
		});

		hwListViewer = new ListViewer(grpHwlist, SWT.BORDER | SWT.V_SCROLL);
		hwListViewer.getList().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Button btn_hwModuleList = new Button(composite_hw, SWT.NONE);
		btn_hwModuleList.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		btn_hwModuleList.setText("HW module repository");
		btn_hwModuleList.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				HwListDialog mDialog = new HwListDialog(new Shell(), hwListViewer, module);
				mDialog.open();
			}
		});

		grpSwlist = new Group(composite_hwswList, SWT.NONE);
		grpSwlist.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpSwlist.setText("SW-List");
		grpSwlist.setLayout(new GridLayout(1, false));

		Composite composite_sw = new Composite(grpSwlist, SWT.NONE);
		composite_sw.setLayout(new GridLayout(3, false));
		composite_sw.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		Text mSWText = new Text(composite_sw, SWT.BORDER);
		mSWText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Button swAddBtn = new Button(composite_sw, SWT.NONE);
		swAddBtn.setText("Add");
		swAddBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (mSWText.getText().equals("")) {
				} else {
					swListViewer.getList().add(mSWText.getText());
					module.IDnType.mSWList.mSWList.add(mSWText.getText());
					mSWText.setText("");
				}
			}
		});

		Button swDeleteBtn = new Button(composite_sw, SWT.NONE);
		swDeleteBtn.setText("Delete");
		swDeleteBtn.addSelectionListener(new SelectionAdapter() { // delete 버튼 동작
			@Override
			public void widgetSelected(SelectionEvent e) {
				swListViewer.getList().remove(swListViewer.getList().getSelectionIndices());
			}
		});

		swListViewer = new ListViewer(grpSwlist, SWT.BORDER | SWT.V_SCROLL);
		swListViewer.getList().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Button btn_swModuleList = new Button(composite_sw, SWT.NONE);
		btn_swModuleList.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		btn_swModuleList.setText("SW module repository");
		btn_swModuleList.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				SwListDialog mDialog = new SwListDialog(new Shell(), swListViewer, module);
				mDialog.open();
			}
		});

		scrolledComposite.setContent(composite_main);
		scrolledComposite.setMinSize(composite_main.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		setControl(rootComposite);

		if (isOld == true) {
			updatePage(module);
			mInfoModelVersion.setText(module.IDnType.informationModelVersion);
			setSWList(module);
			setHWList(module);
		}
	}

	public class VersionModifyListener implements ModifyListener {
		@Override
		public void modifyText(ModifyEvent event) {
			module.IDnType.informationModelVersion = mInfoModelVersion.getText();
		}
	}

	public void setVisible(boolean isVisible) {
		super.setVisible(isVisible);
		if (isVisible) {
			updatePage(module);
			if (module.IDnType.mIDtype != null) {
				if (module.IDnType.mIDtype.equals("Bas")) {
					grpHwlist.setVisible(false);
					grpSwlist.setVisible(false);
					((GridData) grpHwlist.getLayoutData()).exclude = true;
					((GridData) grpSwlist.getLayoutData()).exclude = true;
					composite_main.layout(true, true);
				} 
				else {
					grpHwlist.setVisible(module.isHw);
					grpSwlist.setVisible(module.isSw);
					((GridData) grpHwlist.getLayoutData()).exclude = !module.isHw;
					((GridData) grpSwlist.getLayoutData()).exclude = !module.isSw;
					composite_main.layout(true, true);
				}
			}
			else {
				grpHwlist.setVisible(module.isHw);
				grpSwlist.setVisible(module.isSw);
				((GridData) grpHwlist.getLayoutData()).exclude = !module.isHw;
				((GridData) grpSwlist.getLayoutData()).exclude = !module.isSw;
				composite_main.layout(true, true);
			}
		}
	}

	public void updatePage(Module module) {
		if (module.GenInfo.mModuleName != null) {
			mModuleName.setText(module.GenInfo.getModuleName());
		} else
			mModuleName.setText("");
		if (module.IDnType.mIDtype != null)
			mIDType.setText(module.IDnType.mIDtype);
		else
			mIDType.setText("");
		if (module.IDnType.moduleID != null)
			mModuleID.setText(module.IDnType.moduleID);
		else
			mModuleID.setText("");
		if (module.GenInfo.getManufacturer() != null) {
			mManufacturer.setText(module.GenInfo.getManufacturer());
		} else
			mManufacturer.setText("");
	}

	public void setSWList(Module module) {
		var swList = module.IDnType.mSWList.mSWList;
		if (swList != null) {
			for (int i = 0; i < module.IDnType.mSWList.mSWList.size(); i++)
				swListViewer.getList().add(module.IDnType.mSWList.mSWList.get(i));
		} else {
		}
	}

	public void setHWList(Module module) {
		var hwList = module.IDnType.mHWList.mHWList;
		if (hwList != null) {
			for (int i = 0; i < module.IDnType.mHWList.mHWList.size(); i++)
				hwListViewer.getList().add(module.IDnType.mHWList.mHWList.get(i));
		} else {
		}
	}

	public void setDragDrop(TableViewer tableViewer, ListViewer listViewer, Text text) {
		DragSource ds = new DragSource(tableViewer.getControl(), SWT.NONE);
		ds.setTransfer(new Transfer[] { TextTransfer.getInstance() });
		ds.addDragListener(new DragSourceAdapter() {
			@Override
			public void dragSetData(DragSourceEvent event) {
				event.data = tableViewer.getTable().getSelection()[0].getText();
			}
		});

		DropTarget dt = new DropTarget(text, SWT.NONE);
		dt.setTransfer(new Transfer[] { TextTransfer.getInstance() });
		dt.addDropListener(new DropTargetAdapter() {
			@Override
			public void drop(DropTargetEvent event) {
				Boolean isOldItem = false;
				for (int i = 0; i < listViewer.getList().getItems().length; i++) {
					if (listViewer.getList().getItem(i).equals((String) event.data)) {
						isOldItem = true;
						break;
					}
				}
				if (isOldItem == false)
					text.setText((String) event.data);
			}
		});
	}
}