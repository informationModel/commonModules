package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.TreeNodeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import common.information.model.editor.cim.IOVariable;
import common.information.model.editor.cim.InOut;
import common.information.model.editor.cim.Input;
import common.information.model.editor.cim.Output;
import common.information.model.editor.cim.Module;

public class InfoModelIOVariablesPage extends WizardPage {
	private Text mNameText;
	private Combo mUnitCombo;
	private Text mDescriptionText;
	private Text mValueText;
	public TreeViewer treeViewer;
	public TreeItem mInputs;
	public TreeItem mOutputs;
	public TreeItem mInOuts;
	Button[] mBtns = new Button[3];
	String[] mPuts = new String[] { "Inputs", "Outputs", "InOuts" };
	InputNode mInRoot = new InputNode();
	OutputNode mOutRoot = new OutputNode();
	InOutNode mInOutRoot = new InOutNode();
	private ToolItem inputsItem;
	private ToolItem outputsItem;
	private ToolItem inOutsItem;
	private Module module;
	private Combo comboType;
	private boolean isOld;
	private boolean isClass, isPointer, isArray, isVector, isNormal;
	private int index_none = 0, index_arr = 1, index_class = 2, index_pointer = 3, index_vec = 4;
	private Text text_clsName;
	private Text text_complexName;
	private Text text_pName;
	private Table table_arr;
	private Combo combo_complex, combo_inDataType;

	private Composite composite_arrvec;
	private Composite composite_normal;
	private Composite composite_class;
	private Composite composite_pointer;
	private Button btn_valAdd;
	private Button btn_valDel;

	public InfoModelIOVariablesPage(Module module) {
		super("wizardPage", "IOVariables", null);
		setDescription("Enter IOVariables Information");
		this.module = module;
		this.isOld = false;
	}

	public InfoModelIOVariablesPage(Module module, boolean isOld) {
		super("wizardPage", "IOVariables", null);
		setDescription("Enter IOVariables Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);

		setControl(container);
		container.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite_iovariables = new Composite(container, SWT.BORDER);
		composite_iovariables.setLayout(new GridLayout(2, false));

		ScrolledComposite scrolledComposite = new ScrolledComposite(composite_iovariables,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 3));
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);

		Composite composite_input = new Composite(scrolledComposite, SWT.NONE);
		composite_input.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite_input.setLayout(new GridLayout(1, false));

		Label lbl_Complex = new Label(composite_input, SWT.NONE);
		lbl_Complex.setText("Complex");

		combo_complex = new Combo(composite_input, SWT.NONE | SWT.READ_ONLY);
		combo_complex.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo_complex.setItems(module.complexList);
		combo_complex.select(0);
		combo_complex.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				changeComplex(container);
				if (isVector || isArray) {
					table_arr.removeAll();
				}
			}
		});

		composite_normal = new Composite(composite_input, SWT.NONE);
		composite_normal.setLayout(new GridLayout(3, false));
		composite_normal.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblName = new Label(composite_normal, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblName.setText("Name");

		mNameText = new Text(composite_normal, SWT.BORDER);
		mNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblType = new Label(composite_normal, SWT.NONE);
		lblType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblType.setText("Type");

		comboType = new Combo(composite_normal, SWT.BORDER | SWT.READ_ONLY);
		comboType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		comboType.setItems(module.typeList);

		Label lblUnit = new Label(composite_normal, SWT.NONE);
		lblUnit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblUnit.setText("Unit");

		mUnitCombo = new Combo(composite_normal, SWT.BORDER);
		mUnitCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		mUnitCombo.setItems(module.unitList);

		Label lblDescription = new Label(composite_normal, SWT.NONE);
		lblDescription.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblDescription.setText("Description");

		mDescriptionText = new Text(composite_normal, SWT.BORDER);
		mDescriptionText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblValue = new Label(composite_normal, SWT.NONE);
		lblValue.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblValue.setText("Value");

		mValueText = new Text(composite_normal, SWT.BORDER);
		mValueText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btn_valAdd = new Button(composite_normal, SWT.NONE);
		btn_valAdd.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		btn_valAdd.setText("Add");
		btn_valAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem item = new TableItem(table_arr, SWT.NONE);
				item.setText(0, mValueText.getText());
				mValueText.setText("");
				container.layout(true, true);
			}
		});

		btn_valDel = new Button(composite_normal, SWT.NONE);
		btn_valDel.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		btn_valDel.setText("Del");
		btn_valDel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = table_arr.getSelection()[0];
				var idx = table_arr.indexOf(selected);

				table_arr.remove(idx);
				container.layout(true, true);
			}
		});

		composite_class = new Composite(composite_input, SWT.NONE);
		composite_class.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		composite_class.setLayout(new GridLayout(2, false));

		Label lbl_clsName = new Label(composite_class, SWT.NONE);
		lbl_clsName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 2, 1));
		lbl_clsName.setText("Name");

		text_clsName = new Text(composite_class, SWT.BORDER);
		text_clsName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		Label lblComplexName = new Label(composite_class, SWT.NONE);
		lblComplexName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 2, 1));
		lblComplexName.setText("Complex Name");

		text_complexName = new Text(composite_class, SWT.BORDER);
		text_complexName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

		composite_pointer = new Composite(composite_input, SWT.NONE);
		composite_pointer.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		composite_pointer.setLayout(new GridLayout(1, false));

		Label lbl_pName = new Label(composite_pointer, SWT.NONE);
		lbl_pName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 1, 1));
		lbl_pName.setText("Name");

		text_pName = new Text(composite_pointer, SWT.BORDER);
		text_pName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lbl_inDataType = new Label(composite_pointer, SWT.NONE);
		lbl_inDataType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 1, 1));
		lbl_inDataType.setText("InDataType");

		combo_inDataType = new Combo(composite_pointer, SWT.BORDER | SWT.READ_ONLY);
		combo_inDataType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo_inDataType.setItems(module.typeList);

		composite_arrvec = new Composite(composite_input, SWT.NONE);
		composite_arrvec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		composite_arrvec.setLayout(new GridLayout(1, false));

		TableViewer tableViewer_arrValue = new TableViewer(composite_arrvec, SWT.BORDER | SWT.FULL_SELECTION);
		table_arr = tableViewer_arrValue.getTable();
		table_arr.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		table_arr.setHeaderVisible(true);

		TableViewerColumn tableViewerColumn_value = new TableViewerColumn(tableViewer_arrValue, SWT.NONE);
		TableColumn tblclmnValue = tableViewerColumn_value.getColumn();
		tblclmnValue.setWidth(100);
		tblclmnValue.setText("Value");

		scrolledComposite.setContent(composite_input);
		scrolledComposite.setMinSize(composite_input.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		ToolBar toolBar_1 = new ToolBar(composite_iovariables, SWT.FLAT | SWT.RIGHT);
		toolBar_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		inputsItem = new ToolItem(toolBar_1, SWT.RADIO);
		inputsItem.setText("Inputs");
		inputsItem.setSelection(true);

		outputsItem = new ToolItem(toolBar_1, SWT.RADIO);
		outputsItem.setText("Outputs");

		inOutsItem = new ToolItem(toolBar_1, SWT.RADIO);
		inOutsItem.setText("InOuts");

		treeViewer = new TreeViewer(composite_iovariables, SWT.BORDER);
		Tree tree_1 = treeViewer.getTree();
		tree_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 3));

		Composite btnComposite = new Composite(composite_iovariables, SWT.NONE);
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnComposite.setLayout(new GridLayout(3, true));

		Button addBtn = new Button(btnComposite, SWT.NONE);
		addBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		addBtn.setText("Add");
		addBtn.addSelectionListener(new SelectionAdapter() { // add 버튼을 통해 tree에 추가
			@Override
			public void widgetSelected(SelectionEvent e) {
				var input = new Input(); // input,output,inout 생성
				var output = new Output();
				var inout = new InOut();

				if (inputsItem.getSelection()) {
					update(input, combo_complex.getSelectionIndex());

					var parent = (InputNode) treeViewer.getStructuredSelection().getFirstElement();
					if (parent == null) {
						parent = mInRoot;
					}

					var node = parent.addChild(treeViewer, input, false);
					treeViewer.expandToLevel(parent, 1);
					treeViewer.setSelection(new StructuredSelection(node));
					module.IOVariables.Inputs = mInRoot.getValue().inputs;
				} else if (outputsItem.getSelection()) {
					update(output, combo_complex.getSelectionIndex());

					var parent = (OutputNode) treeViewer.getStructuredSelection().getFirstElement();

					if (parent == null)
						parent = mOutRoot;

					var node = parent.addChild(treeViewer, output, false);
					treeViewer.expandToLevel(parent, 1);
					treeViewer.setSelection(new StructuredSelection(node));
					module.IOVariables.Outputs = mOutRoot.getValue().outputs;

				} else if (inOutsItem.getSelection()) {
					update(inout, combo_complex.getSelectionIndex());

					var parent = (InOutNode) treeViewer.getStructuredSelection().getFirstElement();
					if (parent == null) {
						parent = mInOutRoot;
					}
					var node = parent.addChild(treeViewer, inout, false);
					treeViewer.expandToLevel(parent, 1);
					treeViewer.setSelection(new StructuredSelection(node));
					module.IOVariables.InOuts = mInOutRoot.getValue().inouts;
				}
			}
		});

		Button updateBtn = new Button(btnComposite, SWT.NONE);
		updateBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		updateBtn.setText("Update");
		updateBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = treeViewer.getStructuredSelection().getFirstElement();
				if (selected instanceof InputNode) {
					var node = (InputNode) selected;
					update(node.getValue(), combo_complex.getSelectionIndex());
					treeViewer.remove(mInRoot);
					treeViewer.setInput(mInRoot);
					if (mInRoot.getChildren() != null)
						treeViewer.add(mInRoot, mInRoot.getChildren());
					treeViewer.expandAll();
					treeViewer.setSelection(new StructuredSelection(node));
				} else if (selected instanceof OutputNode) {
					var node = (OutputNode) selected;
					update(node.getValue(), combo_complex.getSelectionIndex());
					treeViewer.remove(mOutRoot);
					treeViewer.setInput(mOutRoot);
					if (mInRoot.getChildren() != null)
						treeViewer.add(mOutRoot, mOutRoot.getChildren());
					treeViewer.expandAll();
					treeViewer.setSelection(new StructuredSelection(node));
				} else if (selected instanceof InOutNode) {
					var node = (InOutNode) selected;
					update(node.getValue(), combo_complex.getSelectionIndex());
					treeViewer.remove(mInOutRoot);
					treeViewer.setInput(mInOutRoot);
					if (mInRoot.getChildren() != null)
						treeViewer.add(mInOutRoot, mInOutRoot.getChildren());
					treeViewer.expandAll();
					treeViewer.setSelection(new StructuredSelection(node));
				}
			}
		});

		Button deleteBtn = new Button(btnComposite, SWT.NONE);
		deleteBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		deleteBtn.setText("Delete");
		deleteBtn.addSelectionListener(new SelectionAdapter() { // delete 버튼을 통해 tree에 추가

			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = treeViewer.getStructuredSelection().getFirstElement();
				if (selected instanceof InputNode) {
					var node = (InputNode) selected;
					var parent = (InputNode) node.getParent();
					if (parent == null)
						parent = mInRoot;
					parent.removeChild(treeViewer, node.getValue().name);
					if (parent == mInRoot) {
						deselect();
					} else
						treeViewer.setSelection(new StructuredSelection(parent));
				} else if (selected instanceof OutputNode) {
					var node = (OutputNode) selected;
					var parent = (OutputNode) node.getParent();
					if (parent == null)
						parent = mOutRoot;
					parent.removeChild(treeViewer, node.getValue().name);
					if (parent == mOutRoot) {
						deselect();
					} else
						treeViewer.setSelection(new StructuredSelection(parent));
				} else if (selected instanceof InOutNode) {
					var node = (InOutNode) selected;
					var parent = (InOutNode) node.getParent();
					if (parent == null)
						parent = mInOutRoot;
					parent.removeChild(treeViewer, node.getValue().name);
					if (parent == mInOutRoot) {
						deselect();
					} else
						treeViewer.setSelection(new StructuredSelection(parent));
				}
			}
		});

		treeViewer.setContentProvider(new TreeNodeContentProvider());
		treeViewer.setLabelProvider(new IOVariableLabelProvider());
		treeViewer.setInput(mInRoot);
		treeViewer.getTree().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				var tree = (Tree) e.widget;
				if (tree.getItem(new Point(e.x, e.y)) == null)
					treeViewer.setSelection(StructuredSelection.EMPTY);
				deselect();
			}
		});
		treeViewer.addSelectionChangedListener(e -> {
			var selected = e.getStructuredSelection().getFirstElement();
			if (selected instanceof InputNode) {
				var value = ((InputNode) selected).getValue();
				setInfo(value);
			} else if (selected instanceof OutputNode) {
				var value = ((OutputNode) selected).getValue();
				setInfo(value);
			} else if (selected instanceof InOutNode) {
				var value = ((InOutNode) selected).getValue();
				setInfo(value);
			}
			changeComplex(container);
		});
		inOutsItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (isOld == false) {
					treeViewer.setInput(mInOutRoot);
					if (mInOutRoot.getChildren() != null)
						treeViewer.add(mInOutRoot, mInOutRoot.getChildren());
					treeViewer.expandAll();
				} else if (isOld == true) {
					treeViewer.setInput(mInOutRoot);
					updateInOut(module);
				}
			}
		});
		outputsItem.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				if (isOld == false) {
					treeViewer.setInput(mOutRoot);
					if (mOutRoot.getChildren() != null)
						treeViewer.add(mOutRoot, mOutRoot.getChildren());
					treeViewer.expandAll();
				} else if (isOld == true) {
					treeViewer.setInput(mOutRoot);
					updateOutput(module);
				}
			}
		});
		inputsItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (isOld == false) {
					treeViewer.setInput(mInRoot);
					if (mInRoot.getChildren() != null)
						treeViewer.add(mInRoot, mInRoot.getChildren());
					treeViewer.expandAll();
				} else if (isOld == true) {
					treeViewer.setInput(mInRoot);
					updateInput(module);
				}
			}
		});

		composite_class.setVisible(false);
		composite_pointer.setVisible(false);
		composite_arrvec.setVisible(false);
		btn_valAdd.setVisible(false);
		btn_valDel.setVisible(false);
		((GridData) btn_valAdd.getLayoutData()).exclude = true;
		((GridData) btn_valDel.getLayoutData()).exclude = true;
		((GridData) composite_class.getLayoutData()).exclude = true;
		((GridData) composite_pointer.getLayoutData()).exclude = true;
		((GridData) composite_arrvec.getLayoutData()).exclude = true;

		if (isOld == true) {
			updateInput(module);
			updateOutput(module);
			updateInOut(module);
		}
	}

	private void update(IOVariable ioVariable, int complex) {
		if (complex == index_none) {
			ioVariable.isNone = true;
			ioVariable.name = mNameText.getText();
			ioVariable.type = comboType.getText();
			ioVariable.unit = mUnitCombo.getText();
			ioVariable.description = mDescriptionText.getText();
			if (!mValueText.getText().equals("")) {
				ioVariable.value = mValueText.getText();
			}
		} else if (complex == index_class) {
			ioVariable.isClass = true;
			ioVariable.complex = combo_complex.getText();
			ioVariable.name = text_clsName.getText();
			ioVariable.clsName = text_complexName.getText();
		} else if (complex == index_arr || complex == index_vec) {
			if (complex == index_arr)
				ioVariable.isArray = true;
			else
				ioVariable.isVector = true;

			ioVariable.complex = combo_complex.getText();
			ioVariable.name = mNameText.getText();
			ioVariable.type = comboType.getText();
			ioVariable.unit = mUnitCombo.getText();
			ioVariable.description = mDescriptionText.getText();
			ioVariable.createValues();
			for (int i = 0; i < table_arr.getItemCount(); i++) {
				ioVariable.values.item.add(table_arr.getItem(i).getText());
			}

		} else if (complex == index_pointer) {
			ioVariable.isPointer = true;
			ioVariable.complex = combo_complex.getText();
			ioVariable.name = text_pName.getText();
			ioVariable.inDataType = combo_inDataType.getText();
		}
	}

	public void setInfo(IOVariable ioVariable) {
		if (ioVariable.isNone) {
			combo_complex.select(index_none);
			mNameText.setText(ioVariable.name);
			comboType.setText(ioVariable.type);
			mDescriptionText.setText(ioVariable.description);
			mUnitCombo.setText(ioVariable.unit);
			if (ioVariable.value != null) mValueText.setText(ioVariable.value);
		} else if (ioVariable.isArray || ioVariable.isVector) {
			if (ioVariable.isArray)
				combo_complex.select(index_arr);
			else
				combo_complex.select(index_vec);
			mNameText.setText(ioVariable.name);
			comboType.setText(ioVariable.type);
			mDescriptionText.setText(ioVariable.description);
			mUnitCombo.setText(ioVariable.unit);
			table_arr.removeAll();
			var vList = ioVariable.values.item;
			for (int i = 0; i < vList.size(); i++) {
				TableItem item = new TableItem(table_arr, SWT.NONE);
				item.setText(0, vList.get(i));
			}
		} else if (ioVariable.isClass) {
			combo_complex.select(index_class);
			text_clsName.setText(ioVariable.name);
			text_complexName.setText(ioVariable.clsName);
		} else if (ioVariable.isPointer) {
			combo_complex.select(index_pointer);
			text_pName.setText(ioVariable.name);
			combo_inDataType.setText(ioVariable.inDataType);
		}
	}

	private void deselect() {
		mNameText.setText("");
		comboType.setText("");
		mDescriptionText.setText("");
		mUnitCombo.setText("");
		mValueText.setText("");
		table_arr.removeAll();
	}

	public void updateInput(Module module) {
		var inputs = module.IOVariables.Inputs;
		mInRoot.getValue().inputs = inputs;

		if (inputs != null) {
			for (int i = 0; i < inputs.size(); i++) {
				var node = mInRoot.addChild(treeViewer, inputs.get(i), true);
				treeViewer.expandToLevel(mInRoot, 1);
				if (inputs.get(i).inputs != null) {
					var idx = inputs.get(i).inputs.size();
					for (int j = 0; j < idx; j++) {
						node.addChild(treeViewer, inputs.get(i).inputs.get(j), true);
						treeViewer.expandToLevel(node, 1);
					}
				}
			}
		} else {
		}
	}

	public void updateOutput(Module module) {
		var outputs = module.IOVariables.Outputs;
		mOutRoot.getValue().outputs = outputs;

		if (outputs != null) {
			for (int i = 0; i < outputs.size(); i++) {
				var node = mOutRoot.addChild(treeViewer, outputs.get(i), true);
				treeViewer.expandToLevel(mOutRoot, 1);
				if (node.getValue().outputs != null) {
					var idx = node.getValue().outputs.size();
					for (int j = 0; j < idx; j++) {
						node.addChild(treeViewer, node.getValue().outputs.get(j), true);
						treeViewer.expandToLevel(node, 1);
					}
				}
			}
		} else {
		}
	}

	public void updateInOut(Module module) {
		var inouts = module.IOVariables.InOuts;
		mInOutRoot.getValue().inouts = inouts;

		if (inouts != null) {
			for (int i = 0; i < inouts.size(); i++) {
				var node = mInOutRoot.addChild(treeViewer, inouts.get(i), true);
				treeViewer.expandToLevel(mInOutRoot, 1);
				if (node.getValue().inouts != null) {
					var idx = node.getValue().inouts.size();
					for (int j = 0; j < idx; j++) {
						node.addChild(treeViewer, node.getValue().inouts.get(j), true);
						treeViewer.expandToLevel(node, 1);
					}
				}
			}
		} else {
		}
	}

	public void changeComplex(Composite container) {
		isClass = false;
		isPointer = false;
		isArray = false;
		isVector = false;
		isNormal = false;
		// array
		if (combo_complex.getSelectionIndex() == index_arr) {
			isClass = false;
			isPointer = false;
			isArray = true;
			isVector = false;
			isNormal = true;
		}
		// class
		else if (combo_complex.getSelectionIndex() == index_class) {
			isClass = true;
			isPointer = false;
			isArray = false;
			isVector = false;
			isNormal = false;
		}
		// pointer
		else if (combo_complex.getSelectionIndex() == index_pointer) {
			isClass = false;
			isPointer = true;
			isArray = false;
			isVector = false;
			isNormal = false;
		}
		// vector
		else if (combo_complex.getSelectionIndex() == index_vec) {
			isClass = false;
			isPointer = false;
			isArray = false;
			isVector = true;
			isNormal = true;
		}
		// None
		else {
			isClass = false;
			isPointer = false;
			isArray = false;
			isVector = false;
			isNormal = true;
		}
		composite_class.setVisible(isClass);
		composite_pointer.setVisible(isPointer);
		composite_arrvec.setVisible(isArray);
		composite_normal.setVisible(isNormal);

		boolean isTable = isArray || isVector;
		composite_arrvec.setVisible(isTable);
		((GridData) composite_arrvec.getLayoutData()).exclude = !isTable;

		btn_valAdd.setVisible(isTable);
		btn_valDel.setVisible(isTable);
		((GridData) btn_valAdd.getLayoutData()).exclude = !isTable;
		((GridData) btn_valDel.getLayoutData()).exclude = !isTable;

		((GridData) composite_class.getLayoutData()).exclude = !isClass;
		((GridData) composite_pointer.getLayoutData()).exclude = !isPointer;
		((GridData) composite_normal.getLayoutData()).exclude = !isNormal;
		container.layout(true, true);
	}
}