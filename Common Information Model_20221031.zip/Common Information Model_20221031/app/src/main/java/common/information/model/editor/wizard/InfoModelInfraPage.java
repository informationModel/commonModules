package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.cim.Databus;
import common.information.model.editor.cim.InfraStructure;
import common.information.model.editor.cim.Module;

public class InfoModelInfraPage extends WizardPage {
	private Text mConTypeText, mTypeNetText, mTypeAppText, mSpeedValueText, mRPowerValueText, mRPowerUnitText,
			mSpeedUnitText,
			mTypePhyText, mDBTypeText, mMiddlewareNameText, mIPText, mMiddlewareVersionText;

	private String[] dataBusBtnName = { "ConnectorType", "TypePhyMac", "TypeNetTrans", "TypeApp", "SpeedValue",
			"SpeedUnit" };
	private TableViewer tableViewer;
	private Module module;

	private Text mMPowerValueText;
	private Text mMPowerUnitText;
	private boolean isOld;

	public InfoModelInfraPage(Module module) {
		super("wsizardPage", "InfraStructure", null);
		setDescription("Enter Infra Information");
		this.module = module;
		this.isOld = false;
	}

	public InfoModelInfraPage(Module module, boolean isOld) {
		super("wsizardPage", "InfraStructure", null);
		setDescription("Enter Infra Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		InfraModifyListener iModifyListener = new InfraModifyListener();
		Composite rootComposite = new Composite(parent, SWT.NONE);
		rootComposite.setLayout(new GridLayout(1, false));

		ScrolledComposite scrolledComposite = new ScrolledComposite(rootComposite,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);

		Composite composite_main = new Composite(scrolledComposite, SWT.NULL);
		composite_main.setLayout(new GridLayout(1, false));

		Group grpPowers = new Group(composite_main, SWT.NONE);
		grpPowers.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		grpPowers.setLayout(new GridLayout(4, false));
		grpPowers.setText("Powers");

		Label lblRPowerValue = new Label(grpPowers, SWT.NONE);
		lblRPowerValue.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblRPowerValue.setText("RatedPower value");

		mRPowerValueText = new Text(grpPowers, SWT.BORDER);
		mRPowerValueText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mRPowerValueText.addModifyListener(iModifyListener);

		Label lblRPowerUnit = new Label(grpPowers, SWT.NONE);
		lblRPowerUnit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblRPowerUnit.setText("RatedPower unit");

		mRPowerUnitText = new Text(grpPowers, SWT.BORDER);
		mRPowerUnitText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mRPowerUnitText.addModifyListener(iModifyListener);

		Label lblMPowerValue = new Label(grpPowers, SWT.NONE);
		lblMPowerValue.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblMPowerValue.setText("MaxPower value");

		mMPowerValueText = new Text(grpPowers, SWT.BORDER);
		mMPowerValueText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMPowerValueText.addModifyListener(iModifyListener);

		Label lblMPowerUnit = new Label(grpPowers, SWT.NONE);
		lblMPowerUnit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblMPowerUnit.setText("MaxPower unit");

		mMPowerUnitText = new Text(grpPowers, SWT.BORDER);
		mMPowerUnitText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMPowerUnitText.addModifyListener(iModifyListener);

		Group grpDatabus = new Group(composite_main, SWT.NONE);
		grpDatabus.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		grpDatabus.setLayout(new GridLayout(1, false));
		grpDatabus.setText("Databus");

		Composite dComposite = new Composite(grpDatabus, SWT.NONE);
		dComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		dComposite.setLayout(new GridLayout(4, false));

		Label lblConType = new Label(dComposite, SWT.NONE);
		lblConType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblConType.setText("ConnectorType");

		mConTypeText = new Text(dComposite, SWT.BORDER);
		mConTypeText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblTypePhy = new Label(dComposite, SWT.NONE);
		lblTypePhy.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblTypePhy.setText("TypePhyMac");

		mTypePhyText = new Text(dComposite, SWT.BORDER);
		mTypePhyText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblTypeNet = new Label(dComposite, SWT.NONE);
		lblTypeNet.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblTypeNet.setText("TypeNetTrans");

		mTypeNetText = new Text(dComposite, SWT.BORDER);
		mTypeNetText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblTypeApp = new Label(dComposite, SWT.NONE);
		lblTypeApp.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblTypeApp.setText("TypeApp");

		mTypeAppText = new Text(dComposite, SWT.BORDER);
		mTypeAppText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblSpeedValue = new Label(dComposite, SWT.NONE);
		lblSpeedValue.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblSpeedValue.setText("Speed value");

		mSpeedValueText = new Text(dComposite, SWT.BORDER);
		mSpeedValueText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Label lblSpeedUnit = new Label(dComposite, SWT.NONE);
		lblSpeedUnit.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblSpeedUnit.setText("Speed unit");

		mSpeedUnitText = new Text(dComposite, SWT.BORDER);
		mSpeedUnitText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Composite btnComposite = new Composite(grpDatabus, SWT.NONE);
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		btnComposite.setLayout(new GridLayout(3, false));

		Button addBtn = new Button(btnComposite, SWT.NONE);
		addBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		addBtn.setText("Add");
		addBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Databus databus = new Databus();
				update(databus);
				module.Infra.dataBuses.add(databus);
				TableItem tableItem = new TableItem(tableViewer.getTable(), SWT.NONE);
				tableItem.setText(0, databus.connectorType);
				tableItem.setText(1, databus.typePhyMac);
				tableItem.setText(2, databus.typeNetTrans);
				tableItem.setText(3, databus.typeApp);
				tableItem.setText(4, databus.speed.value);
				tableItem.setText(5, databus.speed.unit);

				tableViewer.getTable().setSelection(tableItem);
			}
		});

		Button updateBtn = new Button(btnComposite, SWT.NONE);
		updateBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		updateBtn.setText("Update");
		updateBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = tableViewer.getTable().getSelection()[0];
				var idx = tableViewer.getTable().indexOf(selected);
				var selectedDatabus = module.Infra.dataBuses.get(idx);

				update(selectedDatabus);
			}
		});

		Button deleteBtn = new Button(btnComposite, SWT.NONE);
		deleteBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		deleteBtn.setText("Delete");
		deleteBtn.addSelectionListener(new SelectionAdapter() { // delete 버튼 동작
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = tableViewer.getTable().getSelection()[0];
				var idx = tableViewer.getTable().indexOf(selected);

				tableViewer.getTable().remove(idx);
				module.Infra.dataBuses.remove(idx);
				deselected();
			}
		});

		tableViewer = new TableViewer(grpDatabus, SWT.BORDER | SWT.FULL_SELECTION);
		GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_table.heightHint = 80;
		tableViewer.getTable().setLayoutData(gd_table);
		tableViewer.getTable().setHeaderVisible(true);
		tableViewer.getTable().setLinesVisible(true);
		TableViewerColumn[] tableViewerColumnList = new TableViewerColumn[6];

		for (int i = 0; i < tableViewerColumnList.length; i++) {
			tableViewerColumnList[i] = new TableViewerColumn(tableViewer, SWT.NONE);
			TableColumn tblclmn = tableViewerColumnList[i].getColumn();
			tblclmn.setText(dataBusBtnName[i]);
		}

		tableViewer.getControl().addControlListener(new ControlListener() {
			@Override
			public void controlResized(ControlEvent e) {
				Rectangle rect = tableViewer.getTable().getClientArea();
				if (rect.width > 0) {
					int extraSpace = rect.width / tableViewer.getTable().getColumnCount();
					for (int i = 0; i < tableViewerColumnList.length; i++) {
						tableViewerColumnList[i].getColumn().setWidth(extraSpace);
					}
				}
			}

			@Override
			public void controlMoved(ControlEvent e) {
			}
		});
		tableViewer.addSelectionChangedListener(e -> {
			var selected = tableViewer.getTable().getSelection()[0];
			var idx = tableViewer.getTable().indexOf(selected);
			var selectedDatabus = module.Infra.dataBuses.get(idx);

			mConTypeText.setText(selectedDatabus.connectorType);
			mTypePhyText.setText(selectedDatabus.typePhyMac);
			mTypeNetText.setText(selectedDatabus.typeNetTrans);
			mTypeAppText.setText(selectedDatabus.typeApp);
			mSpeedUnitText.setText(selectedDatabus.speed.unit);
			mSpeedValueText.setText(selectedDatabus.speed.value);
		});

		Composite composite = new Composite(composite_main, SWT.NONE);
		composite.setLayout(new GridLayout(4, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		Label lblDBType = new Label(composite, SWT.NONE);
		lblDBType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblDBType.setText("DBType");

		mDBTypeText = new Text(composite, SWT.BORDER);
		mDBTypeText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mDBTypeText.addModifyListener(iModifyListener);
 
		Label lblMiddlewareName = new Label(composite, SWT.NONE);
		lblMiddlewareName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblMiddlewareName.setText("Middleware name");

		mMiddlewareNameText = new Text(composite, SWT.BORDER);
		mMiddlewareNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMiddlewareNameText.addModifyListener(iModifyListener);

		Label lblIP = new Label(composite, SWT.NONE);
		lblIP.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblIP.setText("IP");

		mIPText = new Text(composite, SWT.BORDER);
		mIPText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mIPText.addModifyListener(iModifyListener);

		Label lblMiddlewareVersion = new Label(composite, SWT.NONE);
		lblMiddlewareVersion.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblMiddlewareVersion.setText("Middleware version");

		mMiddlewareVersionText = new Text(composite, SWT.BORDER);
		mMiddlewareVersionText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMiddlewareVersionText.addModifyListener(iModifyListener);

		scrolledComposite.setContent(composite_main);
		scrolledComposite.setMinSize(composite_main.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		setControl(rootComposite);

		if (isOld == true) {
			updatePage(module);
			updateDatabus(module);
			isOld = false;
		}
	}

	public class InfraModifyListener implements ModifyListener {

		@Override
		public void modifyText(ModifyEvent event) {
			if (!isOld) setInfra(module.Infra);
		}

	}

	public void updatePage(Module module) {
		if (module.Infra.powers.ratedPower.powerValue != null) mRPowerValueText.setText(module.Infra.powers.ratedPower.powerValue);
		if (module.Infra.powers.ratedPower.powerUnit != null)
			mRPowerUnitText.setText(module.Infra.powers.ratedPower.powerUnit);
		if (module.Infra.powers.maxPower.powerValue != null)
			mMPowerValueText.setText(module.Infra.powers.maxPower.powerValue);
		if (module.Infra.powers.maxPower.powerUnit != null) mMPowerUnitText.setText(module.Infra.powers.maxPower.powerUnit);
		if (module.Infra.dbType != null) mDBTypeText.setText(module.Infra.dbType);
		if (module.Infra.IPcode != null) mIPText.setText(module.Infra.IPcode);
		if (module.Infra.mMiddleware.middlewareName != null) mMiddlewareNameText.setText(module.Infra.mMiddleware.middlewareName);
		if (module.Infra.mMiddleware.middlewareVersion != null) mMiddlewareVersionText.setText(module.Infra.mMiddleware.middlewareVersion);
	}

	public void updateDatabus(Module module) {
		var dataBuses = module.Infra.dataBuses;

		if(dataBuses != null) {
			for (int i = 0; i < dataBuses.size(); i++) {
				TableItem tableItem = new TableItem(tableViewer.getTable(), SWT.NONE);
				tableItem.setText(0, dataBuses.get(i).connectorType);
				tableItem.setText(1, dataBuses.get(i).typePhyMac);
				tableItem.setText(2, dataBuses.get(i).typeNetTrans);
				tableItem.setText(3, dataBuses.get(i).typeApp);
				tableItem.setText(4, dataBuses.get(i).speed.value);
				tableItem.setText(5, dataBuses.get(i).speed.unit);
			}
		}
	}

	private void update(Databus databus) {
		databus.connectorType = mConTypeText.getText();
		databus.typePhyMac = mTypePhyText.getText();
		databus.typeNetTrans = mTypeNetText.getText();
		databus.typeApp = mTypeAppText.getText();
		databus.speed.value = mSpeedValueText.getText();
		databus.speed.unit = mSpeedUnitText.getText();
	}

	public void setInfra(InfraStructure infra) {
		infra.powers.ratedPower.powerValue = mRPowerValueText.getText();
		infra.powers.ratedPower.powerUnit = mRPowerUnitText.getText();
		infra.powers.maxPower.powerValue = mMPowerValueText.getText();
		infra.powers.maxPower.powerUnit = mMPowerUnitText.getText();
		infra.dbType = mDBTypeText.getText();
		infra.IPcode = mIPText.getText();
		infra.mMiddleware.middlewareName = mMiddlewareNameText.getText();
		infra.mMiddleware.middlewareVersion = mMiddlewareVersionText.getText();
	}

	public void deselected() {
		mConTypeText.setText("");
		mTypePhyText.setText("");
		mTypeNetText.setText("");
		mTypeAppText.setText("");
		mSpeedValueText.setText("");
		mSpeedUnitText.setText("");
	}

}