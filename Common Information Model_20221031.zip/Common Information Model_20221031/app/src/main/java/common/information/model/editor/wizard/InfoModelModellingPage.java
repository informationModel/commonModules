package common.information.model.editor.wizard;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.cim.ModelCase;
import common.information.model.editor.cim.Module;

public class InfoModelModellingPage extends WizardPage {
    private Text textSimulator, text_MdfName, text_MdfPath, text_3dfName, text_3dfPath;
    private Module module;
    private Table table;
    public String[] typeMdf = { "URDF", "SDF", "NA" };
    public String[] type3df = { "STL", "OBJ", "3DS", "DAE", "FBX", "NA" };
    private Combo combo_MdfType;
    private Combo combo_3dfType;
    public String filePath;
    boolean isOld = false;
    private Button fileUploadMDF;
    private Button fileUpload3DF;

    public InfoModelModellingPage(Module module) {
        super("wizardPage", "Modelling", null);
        setDescription("Enter Modelling of Module Information");
        this.module = module;
    }

    public InfoModelModellingPage(Module module, boolean isOld) {
        super("wizardPage", "Modelling", null);
        setDescription("Enter Modelling of Module Information");
        this.module = module;
        this.isOld = isOld;
    }

    @Override
    public void createControl(Composite parent) {
        Composite container = new Composite(parent, SWT.NONE);

        setControl(container);
        container.setLayout(new GridLayout(1, false));

        ScrolledComposite scrolledComposite = new ScrolledComposite(container,
                SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
        scrolledComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
        scrolledComposite.setExpandHorizontal(true);
        scrolledComposite.setExpandVertical(true);

        Composite composite = new Composite(scrolledComposite, SWT.NONE);
        composite.setLayout(new GridLayout(4, false));

        Label lblSimulator = new Label(composite, SWT.NONE);
        lblSimulator.setText("Simulator");

        textSimulator = new Text(composite, SWT.BORDER);
        textSimulator.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 3, 1));

        Group grpMDF = new Group(composite, SWT.NONE);
        grpMDF.setText("MDF [Model Description Format]");
        grpMDF.setLayout(new GridLayout(4, false));
        grpMDF.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 4, 1));

        Label lblMdfType = new Label(grpMDF, SWT.NONE);
        lblMdfType.setText("Type");

        combo_MdfType = new Combo(grpMDF, SWT.NONE);
        combo_MdfType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
        for (int i = 0; i < typeMdf.length; i++) {
            combo_MdfType.add(typeMdf[i]);
        }
        combo_MdfType.select(combo_MdfType.getItemCount() - 1);

        Label lblMdfName = new Label(grpMDF, SWT.NONE);
        lblMdfName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
        lblMdfName.setText("Name");

        text_MdfName = new Text(grpMDF, SWT.BORDER);
        text_MdfName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

        Label lbl_MdfPath = new Label(grpMDF, SWT.NONE);
        lbl_MdfPath.setText("Path");

        text_MdfPath = new Text(grpMDF, SWT.BORDER);
        text_MdfPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

        fileUploadMDF = new Button(grpMDF, SWT.NONE);
        fileUploadMDF.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
        fileUploadMDF.setText("Select File");
        fileUploadMDF.addSelectionListener(mMdfUploadSelectionListener);

        Group grp3DF = new Group(composite, SWT.NONE);
        grp3DF.setText("3DF [3D model format]");
        grp3DF.setLayout(new GridLayout(3, false));
        grp3DF.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false, 4, 1));

        Label lbl3dfType = new Label(grp3DF, SWT.NONE);
        lbl3dfType.setText("Type");

        combo_3dfType = new Combo(grp3DF, SWT.NONE);
        combo_3dfType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
        for (int i = 0; i < type3df.length; i++) {
            combo_3dfType.add(type3df[i]);
        }
        combo_3dfType.select(combo_3dfType.getItemCount() - 1);

        Label lbl3dfName = new Label(grp3DF, SWT.NONE);
        lbl3dfName.setText("Name");

        text_3dfName = new Text(grp3DF, SWT.BORDER);
        text_3dfName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

        Label lbl3dfPath = new Label(grp3DF, SWT.NONE);
        lbl3dfPath.setText("Path");

        text_3dfPath = new Text(grp3DF, SWT.BORDER);
        text_3dfPath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

        fileUpload3DF = new Button(grp3DF, SWT.NONE);
        fileUpload3DF.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
        fileUpload3DF.setText("Select File");
        fileUpload3DF.addSelectionListener(m3DFUploadSelectionListener);

        Composite composite_btn = new Composite(composite, SWT.NONE);
        composite_btn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 4, 1));
        composite_btn.setLayout(new GridLayout(2, false));

        Button btn_add = new Button(composite_btn, SWT.NONE);
        btn_add.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_add.setText("Add");
        btn_add.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                TableItem tableItem = new TableItem(table, SWT.NONE);
                tableItem.setText(0, textSimulator.getText());
                tableItem.setText(1, combo_MdfType.getText());
                tableItem.setText(2, text_MdfPath.getText());
                tableItem.setText(3, combo_3dfType.getText());
                tableItem.setText(4, text_3dfPath.getText());
                table.setSelection(tableItem);

                ModelCase modelCase = new ModelCase();
                modelCase.simulator = tableItem.getText(0);
                modelCase.modelFile[0].type = tableItem.getText(1);
                modelCase.modelFile[0].fileName = text_MdfName.getText();
                modelCase.modelFile[0].filePath = tableItem.getText(2);
                modelCase.modelFile[1].type = tableItem.getText(3);
                modelCase.modelFile[1].fileName = text_3dfName.getText();
                ;
                modelCase.modelFile[1].filePath = tableItem.getText(4);

                module.Modelling.simulationModel.add(modelCase);

                clear();
            }
        });

        Button btn_del = new Button(composite_btn, SWT.NONE);
        btn_del.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
        btn_del.setText("Delete");
        btn_del.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                var selected = table.getSelection()[0];
                var idx = table.indexOf(selected);
                table.remove(idx);
                module.Modelling.simulationModel.remove(idx);
            }
        });

        TableViewer tableViewer_simModel = new TableViewer(composite, SWT.BORDER | SWT.FULL_SELECTION);
        table = tableViewer_simModel.getTable();
        table.setLinesVisible(true);
        table.setHeaderVisible(true);
        GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 4, 1);
        gd_table.heightHint = 150;
        table.setLayoutData(gd_table);

        tableViewer_simModel.addSelectionChangedListener(e -> {
            var selected = table.getSelection()[0];
            var idx = table.indexOf(selected);
            var modelCase = module.Modelling.simulationModel.get(idx);

            textSimulator.setText(modelCase.simulator);
            text_MdfName.setText(modelCase.modelFile[0].fileName);
            text_MdfPath.setText(modelCase.modelFile[0].filePath);
            text_3dfName.setText(modelCase.modelFile[1].fileName);
            text_3dfPath.setText(modelCase.modelFile[1].filePath);
            for (int i = 0; i < combo_3dfType.getItemCount(); i++) {
                if (combo_3dfType.getItem(i).equals(modelCase.modelFile[1].type)) {
                    combo_3dfType.select(i);
                }
            }
            for (int i = 0; i < combo_MdfType.getItemCount(); i++) {
                if (combo_MdfType.getItem(i).equals(modelCase.modelFile[0].type)) {
                    combo_MdfType.select(i);
                }
            }
        });

        TableViewerColumn tableViewerColumn_sim = new TableViewerColumn(tableViewer_simModel, SWT.NONE);
        TableColumn tblclmnSimulator = tableViewerColumn_sim.getColumn();
        tblclmnSimulator.setWidth(100);
        tblclmnSimulator.setText("Simulator");

        TableViewerColumn tableViewerColumn_mdfType = new TableViewerColumn(tableViewer_simModel, SWT.LEFT);
        TableColumn tblclmn_mdfType = tableViewerColumn_mdfType.getColumn();
        tblclmn_mdfType.setWidth(85);
        tblclmn_mdfType.setText("MDF Type");

        TableViewerColumn tableViewerColumn_mdfPath = new TableViewerColumn(tableViewer_simModel, SWT.LEFT);
        TableColumn tblclmn_mdfPath = tableViewerColumn_mdfPath.getColumn();
        tblclmn_mdfPath.setWidth(112);
        tblclmn_mdfPath.setText("MDF Path");

        TableViewerColumn tableViewerColumn_3dfType = new TableViewerColumn(tableViewer_simModel, SWT.NONE);
        TableColumn tblclmn_3dfType = tableViewerColumn_3dfType.getColumn();
        tblclmn_3dfType.setWidth(100);
        tblclmn_3dfType.setText("3DF Type");

        TableViewerColumn tableViewerColumn_3dfPath = new TableViewerColumn(tableViewer_simModel, SWT.NONE);
        TableColumn tblclmn_3dfPath = tableViewerColumn_3dfPath.getColumn();
        tblclmn_3dfPath.setWidth(100);
        tblclmn_3dfPath.setText("3DF Path");
        scrolledComposite.setContent(composite);
        scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));

        tableViewer_simModel.getControl().addControlListener(new ControlListener() {
            @Override
            public void controlResized(ControlEvent e) {
                Rectangle rect = tableViewer_simModel.getTable().getClientArea();
                if (rect.width > 0) {
                    int width = rect.width / 12;
                    tblclmnSimulator.setWidth(width * 2);
                    tblclmn_mdfType.setWidth(width * 1);
                    tblclmn_mdfPath.setWidth(width * 4);
                    tblclmn_3dfType.setWidth(width * 1);
                    tblclmn_3dfPath.setWidth(width * 4);
                }
            }

            @Override
            public void controlMoved(ControlEvent e) {
            }
        });

        // Edit일 경우
        setModellingPage(isOld);
    }

    private final SelectionListener mMdfUploadSelectionListener = new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
            Path mdfPath;
            FileDialog fd = new FileDialog(getShell(), SWT.OPEN);
			var path = Path.of(".").toAbsolutePath().normalize().resolve("workspace/resources");
            fd.setText("Choose a MDF File");
            fd.setFilterPath(path.toString());
            fd.open();
            String xPath = fd.getFilterPath() + "/" + fd.getFileName();
            var mdfFile = new File(xPath);
            try {
                mdfPath = Files.move(mdfFile.toPath(), Path.of(path.toString(), fd.getFileName()), StandardCopyOption.REPLACE_EXISTING);
                mdfPath = Path.of(mdfFile.toPath().toString()).relativize(mdfPath);
                text_MdfName.setText(fd.getFileName());
                text_MdfPath.setText(mdfPath.toString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    };

    private final SelectionListener m3DFUploadSelectionListener = new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
            Path m3DFPath;
            FileDialog fd = new FileDialog(getShell(), SWT.OPEN);
			var path = Path.of(".").toAbsolutePath().normalize().resolve("workspace/resources");
            fd.setText("Choose a 3DF File");
            fd.setFilterPath(path.toString());
            fd.open();
            String xPath = fd.getFilterPath() + "/" + fd.getFileName();
            var m3dfFile = new File(xPath);
            try {
                m3DFPath = Files.move(m3dfFile.toPath(), Path.of(path.toString(), fd.getFileName()), StandardCopyOption.REPLACE_EXISTING);
                m3DFPath = Path.of(m3dfFile.toPath().toString()).relativize(m3DFPath);
                text_3dfName.setText(fd.getFileName());
                text_3dfPath.setText(m3DFPath.toString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    };

    public void clear() {
        textSimulator.setText("");
        text_MdfName.setText("");
        text_MdfPath.setText("");
        text_3dfName.setText("");
        text_3dfPath.setText("");
        combo_3dfType.select(combo_3dfType.getItemCount() - 1);
        combo_MdfType.select(combo_MdfType.getItemCount() - 1);
    }

    public void setModellingPage(boolean isOld) {
        if (isOld) {
            if (module.Modelling.simulationModel != null) {
                for (int i = 0; i < module.Modelling.simulationModel.size(); i++) {
                    ModelCase modelcase = module.Modelling.simulationModel.get(i);
                    TableItem item = new TableItem(table, SWT.NONE);
                    item.setText(0, modelcase.simulator);
                    item.setText(1, modelcase.modelFile[0].type);
                    item.setText(2, modelcase.modelFile[0].filePath);
                    item.setText(3, modelcase.modelFile[1].type);
                    item.setText(4, modelcase.modelFile[1].filePath);

                    table.setSelection(item);
                }
            } else {
                System.out.println("ModellingPage 정보가 없습니다.");
            }
        } else
            return;
    }
}
