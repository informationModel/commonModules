package common.information.model.editor.wizard;

import java.io.FileReader;
import java.util.Arrays;

import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.TreeNodeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;

import com.google.gson.Gson;

import common.information.model.editor.cim.BitsnCPUarch;
import common.information.model.editor.cim.CompilerType;
import common.information.model.editor.cim.ExecutionType;
import common.information.model.editor.cim.Library;
import common.information.model.editor.cim.OSType;
import common.information.model.editor.cim.Property;
import common.information.model.editor.cim.RangeString;
import common.information.model.editor.cim.Values;
import common.information.model.editor.cim.Module;

public class InfoModelPropertiesPage extends WizardPage {
	public Text mNameText, mDescriptionText, mValueText, mLibrariesName, mLibrariesVer,
			mTimeConstraint,
			mCPUarch, text_clsName, textName_class, text_complexName, textName_pointer;
	public Combo immuteCombo, mOPTypeCombo, mhardRTCombo, minstanceTypeCombo, mOSbits, mCPUbits, mTypeCombo, mUnitCombo,
			mOSName, mOStype, mOSVersion, mRangeOSmin, mRangeOSmax, mRangeCompilermin, mRangeCompilermax, mCompilerName;
	public TreeViewer treeViewer;
	PropertyNode mRoot = new PropertyNode();
	private java.util.List<OSList> osLists, compilerLists;
	private List list_lib;
	private Module module;
	private int libIndex;
	private boolean isOld;
	private Composite composite_class, composite_pointer, composite_array, composite_normal, composite_vector;
	private boolean isClass, isPointer, isArray, isVector, isNormal;
	private int index_none = 0, index_arr = 1, index_class = 2, index_pointer = 3, index_vec = 4;
	private Combo combo_complex;
	private Label lbl_clsName;
	private Table table_arrValue;
	private Table table_vec;
	private Button btn_valAdd;
	private Button btn_valDel;
	private Combo combo_indataType;

	/**
	 * @wbp.parser.constructor
	 */
	public InfoModelPropertiesPage(Module module) {
		super("wizardPage", "Properties", null);
		setDescription("Enter Properties Information");
		this.module = module;
		this.isOld = false;
	}

	public InfoModelPropertiesPage(Module module, boolean isOld) {
		super("wizardPage", "Properties", null);
		setDescription("Enter Properties Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		ProperModifyListener pModifyListener = new ProperModifyListener();
		Composite container = new Composite(parent, SWT.NONE);

		setControl(container);
		FillLayout fillLayout = new FillLayout(SWT.HORIZONTAL);
		fillLayout.spacing = 5;
		container.setLayout(fillLayout);

		TabFolder tabFolder = new TabFolder(container, SWT.NONE);

		TabItem tbtm_properties = new TabItem(tabFolder, SWT.NONE);
		tbtm_properties.setText("Property");

		Composite composite_property = new Composite(tabFolder, SWT.NONE);
		tbtm_properties.setControl(composite_property);
		composite_property.setLayout(new GridLayout(2, false));

		ScrolledComposite scrolledComposite_list = new ScrolledComposite(composite_property,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite_list.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		scrolledComposite_list.setExpandHorizontal(true);
		scrolledComposite_list.setExpandVertical(true);

		Composite composite_list = new Composite(scrolledComposite_list, SWT.NONE);
		composite_list.setSize(188, 333);
		composite_list.setLayout(new GridLayout(1, false));

		Composite p_Composite = new Composite(composite_list, SWT.NONE);
		p_Composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		p_Composite.setLayout(new GridLayout(2, false));
		treeViewer = new TreeViewer(composite_property, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
		treeViewer.setContentProvider(new TreeNodeContentProvider());
		treeViewer.setLabelProvider(new PropertyLabelProvider());
		treeViewer.setInput(mRoot);

		Tree tree = treeViewer.getTree();
		tree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 2));
		treeViewer.getTree().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				var tree = (Tree) e.widget;
				if (tree.getItem(new Point(e.x, e.y)) == null)
					treeViewer.setSelection(StructuredSelection.EMPTY);
				deselect();
				changeComplex(container);
			}
		});
		treeViewer.addSelectionChangedListener(e -> {
			var selected = e.getStructuredSelection().getFirstElement();
			if (selected instanceof PropertyNode) {
				var value = ((PropertyNode) selected).getValue();
				if (value.isClass()) {
					combo_complex.select(index_class);
					changeComplex(container);
					textName_class.setText(value.getName());
					text_complexName.setText(value.getComplexName());
				} else if (value.isArray() || value.isVector()) {
					if (value.isArray()) {
						combo_complex.select(index_arr);
						table_arrValue.removeAll();
						var vList = value.getValues().item;
						for (int i = 0; i < vList.size(); i++) {
							TableItem item = new TableItem(table_arrValue, SWT.NONE);
							item.setText(0, vList.get(i));
						}
					}

					else if (value.isVector()) {
						combo_complex.select(index_vec);
						table_vec.removeAll();
						var vList = value.getValues().item;
						for (int i = 0; i < vList.size(); i++) {
							TableItem item = new TableItem(table_vec, SWT.NONE);
							item.setText(0, vList.get(i));
						}
					}
					changeComplex(container);
					mNameText.setText(value.getName());
					mTypeCombo.setText(value.getType());
					mDescriptionText.setText(value.getDescription());
					mUnitCombo.setText(value.getUnit());

				}

				else if (value.isPointer()) {
					combo_complex.select(index_pointer);
					changeComplex(container);
					textName_pointer.setText(value.getName());
					combo_indataType.setText(value.getInDataType());
				} else {
					combo_complex.select(index_none);
					changeComplex(container);
					mNameText.setText(value.getName());
					mTypeCombo.setText(value.getType());
					mDescriptionText.setText(value.getDescription());
					mUnitCombo.setText(value.getUnit());
					mValueText.setText(value.getValue());
				}
			}
		});

		Label lblComplex = new Label(p_Composite, SWT.NONE);
		lblComplex.setText("Complex");

		combo_complex = new Combo(p_Composite, SWT.NONE | SWT.READ_ONLY);
		combo_complex.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo_complex.setItems(module.complexList);
		combo_complex.select(0);
		combo_complex.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				changeComplex(container);
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}

		});

		composite_class = new Composite(p_Composite, SWT.NONE);
		composite_class.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, true, 2, 1));
		composite_class.setLayout(new GridLayout(1, false));

		Label lblName_class = new Label(composite_class, SWT.NONE);
		lblName_class.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true, 1, 1));
		lblName_class.setText("Property Name");

		textName_class = new Text(composite_class, SWT.BORDER);
		textName_class.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblComplexName = new Label(composite_class, SWT.NONE);
		lblComplexName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, true, 1, 1));
		lblComplexName.setText("Complex Name");

		text_complexName = new Text(composite_class, SWT.BORDER);
		text_complexName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		composite_pointer = new Composite(p_Composite, SWT.NONE);
		composite_pointer.setLayout(new GridLayout(1, false));
		composite_pointer.setLayoutData(new GridData(SWT.FILL, SWT.TOP, false, true, 2, 1));

		Label lblName_pointer = new Label(composite_pointer, SWT.NONE);
		lblName_pointer.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 1, 1));
		lblName_pointer.setText("Name");

		textName_pointer = new Text(composite_pointer, SWT.BORDER);
		textName_pointer.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));

		Label lblIndatatype = new Label(composite_pointer, SWT.NONE);
		lblIndatatype.setText("InDataType");

		combo_indataType = new Combo(composite_pointer, SWT.BORDER);
		combo_indataType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo_indataType.setItems(module.typeList);

		composite_normal = new Composite(p_Composite, SWT.NONE);
		composite_normal.setLayout(new GridLayout(4, false));
		composite_normal.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 2, 2));

		Label lblName = new Label(composite_normal, SWT.NONE);
		lblName.setText("Name");

		mNameText = new Text(composite_normal, SWT.BORDER);
		mNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblType = new Label(composite_normal, SWT.NONE);
		lblType.setText("Type");

		mTypeCombo = new Combo(composite_normal, SWT.DROP_DOWN | SWT.READ_ONLY);
		mTypeCombo.setItems(module.typeList);
		mTypeCombo.setText("Select Type...");
		mTypeCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		mTypeCombo.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				Combo combo = (Combo) e.getSource();
				boolean isClass = false;
				if (combo.getText().equals("class")) {
					isClass = true;
				} else
					isClass = false;
				lbl_clsName.setVisible(isClass);
				text_clsName.setVisible(isClass);
				((GridData) lbl_clsName.getLayoutData()).exclude = !isClass;
				((GridData) text_clsName.getLayoutData()).exclude = !isClass;
				container.layout(true, true);

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}

		});

		lbl_clsName = new Label(composite_normal, SWT.NONE);
		lbl_clsName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 1, 1));
		lbl_clsName.setText("Class Name");

		text_clsName = new Text(composite_normal, SWT.BORDER);
		text_clsName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblDescription = new Label(composite_normal, SWT.NONE);
		lblDescription.setText("Description");

		mDescriptionText = new Text(composite_normal, SWT.BORDER);
		mDescriptionText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblUnit = new Label(composite_normal, SWT.NONE);
		lblUnit.setText("Unit");

		mUnitCombo = new Combo(composite_normal, SWT.BORDER);
		mUnitCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		mUnitCombo.setItems(module.unitList);

		Label lblValue = new Label(composite_normal, SWT.NONE);
		lblValue.setText("Value");

		mValueText = new Text(composite_normal, SWT.BORDER);
		mValueText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		btn_valAdd = new Button(composite_normal, SWT.NONE);
		btn_valAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btn_valAdd.setText("Add");
		btn_valAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem item;
				if (combo_complex.getSelectionIndex() == index_arr) {
					item = new TableItem(table_arrValue, SWT.NONE);
					item.setText(0, mValueText.getText());
				} else if (combo_complex.getSelectionIndex() == index_vec) {
					item = new TableItem(table_vec, SWT.NONE);
					item.setText(0, mValueText.getText());
				}
				mValueText.setText("");
				container.layout(true, true);
			}
		});

		btn_valDel = new Button(composite_normal, SWT.NONE);
		btn_valDel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		btn_valDel.setText("Del");
		btn_valDel.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem selected;
				int idx = 0;
				if (combo_complex.getSelectionIndex() == index_arr) {
					selected = table_arrValue.getSelection()[0];
					idx = table_arrValue.indexOf(selected);
					table_arrValue.remove(idx);
				} else if (combo_complex.getSelectionIndex() == index_vec) {
					selected = table_vec.getSelection()[0];
					idx = table_vec.indexOf(selected);
					table_vec.remove(idx);
				}
				container.layout(true, true);
			}
		});

		scrolledComposite_list.setContent(composite_list);
		scrolledComposite_list.setMinSize(composite_list.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		composite_array = new Composite(p_Composite, SWT.NONE);
		composite_array.setLayout(new GridLayout(2, false));
		composite_array.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 2, 1));

		TableViewer tableViewer_arrValue = new TableViewer(composite_array, SWT.BORDER | SWT.FULL_SELECTION);
		table_arrValue = tableViewer_arrValue.getTable();
		table_arrValue.setHeaderVisible(true);
		table_arrValue.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));

		TableViewerColumn tableViewerColumn_value = new TableViewerColumn(tableViewer_arrValue, SWT.NONE);
		TableColumn tblclmnValue = tableViewerColumn_value.getColumn();
		tblclmnValue.setWidth(100);
		tblclmnValue.setText("Value");

		composite_vector = new Composite(p_Composite, SWT.NONE);
		composite_vector.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		composite_vector.setLayout(new GridLayout(3, false));

		TableViewer tableViewer_vecValue = new TableViewer(composite_vector, SWT.BORDER | SWT.FULL_SELECTION);
		table_vec = tableViewer_vecValue.getTable();
		table_vec.setHeaderVisible(true);
		table_vec.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1));

		TableViewerColumn tableViewerColumn_value_vec = new TableViewerColumn(tableViewer_vecValue, SWT.NONE);
		TableColumn tblclmnValue_vec = tableViewerColumn_value_vec.getColumn();
		tblclmnValue_vec.setWidth(100);
		tblclmnValue_vec.setText("Value");

		scrolledComposite_list.setContent(composite_list);
		scrolledComposite_list.setMinSize(composite_list.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		Composite btnComposite = new Composite(composite_property, SWT.NONE);
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnComposite.setLayout(new GridLayout(3, false));

		Button addPropertybtn = new Button(btnComposite, SWT.NONE);
		addPropertybtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		addPropertybtn.setText("Add");
		addPropertybtn.addSelectionListener(new SelectionAdapter() { // add 버튼을 통해 tree에 추가

			@Override
			public void widgetSelected(SelectionEvent e) {
				var property = new Property(); // Property 생성

				if (isClass) {
					updateClass(property); // property 입력 정보 갱신
				}
				// Array
				else if (isArray) {
					Values val = new Values();
					for (int i = 0; i < table_arrValue.getItemCount(); i++) {
						val.item.add(table_arrValue.getItem(i).getText(0));
					}
					updateArray(property, val); // property 입력 정보 갱신
				}
				// Vector
				else if (isVector) {
					Values val = new Values();
					for (int i = 0; i < table_vec.getItemCount(); i++) {
						val.item.add(table_vec.getItem(i).getText(0));
					}
					updateVector(property, val); // property 입력 정보 갱신
				}
				// Pointer
				else if (isPointer) {
					updatePointer(property);
				}
				// None
				else {
					update(property); // property 입력 정보 갱신
				}
				var parent = (PropertyNode) treeViewer.getStructuredSelection().getFirstElement(); // parent를 선택한
				// 노드로 지정
				if (parent == null) { // parent를 선택하지 않았거나, 없을 경우 최상위 노드로 지정
					parent = mRoot;
				}

				var node = parent.addChild(treeViewer, property, false); // parent에 property 정보를 포함한 child 추가
				treeViewer.expandToLevel(parent, 1); // treeViewer 크기를 1칸 확장
				treeViewer.setSelection(new StructuredSelection(node)); // 선택을 parent에서 새로 추가된 node로 변경
				// 현재 정보 모듈에 저장
				module.Properties.setProperties(mRoot.getValue().mProperties);
			}
		});

		Button updatePropertybtn = new Button(btnComposite, SWT.NONE);
		updatePropertybtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		updatePropertybtn.setText("Update");
		updatePropertybtn.addSelectionListener(new SelectionAdapter() { // update 버튼을 통해 property update
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = treeViewer.getStructuredSelection().getFirstElement();
				if (selected instanceof PropertyNode) {
					var node = (PropertyNode) selected;

					if (isClass) {
						updateClass(node.getValue()); // property 입력 정보 갱신
					}

					else if (isArray) {
						Values val = new Values();
						for (int i = 0; i < table_arrValue.getItemCount(); i++) {
							val.item.add(table_arrValue.getItem(i).getText(0));
						}
						updateArray(node.getValue(), val); // property 입력 정보 갱신
					}

					else if (isVector) {
						Values val = new Values();
						for (int i = 0; i < table_vec.getItemCount(); i++) {
							val.item.add(table_vec.getItem(i).getText(0));
						}
						updateVector(node.getValue(), val); // property 입력 정보 갱신
					}

					else if (isPointer) {
						updatePointer(node.getValue());
					}

					else {
						update(node.getValue()); // property 입력 정보 갱신
					}
					treeViewer.refresh();
					treeViewer.setInput(mRoot);
					if (mRoot.getChildren() != null)
						treeViewer.add(mRoot, mRoot.getChildren());
					treeViewer.expandAll();
					treeViewer.setSelection(new StructuredSelection(node));
				}
			}
		});

		Button deletePropertybtn = new Button(btnComposite, SWT.NONE);
		deletePropertybtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		deletePropertybtn.setText("Delete");
		deletePropertybtn.addSelectionListener(new SelectionAdapter() { // delete 버튼을 통해 tree에 추가
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = treeViewer.getStructuredSelection().getFirstElement();
				if (selected instanceof PropertyNode) {
					var node = (PropertyNode) selected;
					var parent = (PropertyNode) node.getParent();
					if (parent == null)
						parent = mRoot;
					parent.removeChild(treeViewer, node.getValue().getName());
					if (parent == mRoot) {
						deselect();
						changeComplex(container);
					} else
						treeViewer.setSelection(new StructuredSelection(parent));
					// module.Properties.setProperties(mRoot.getValue().mProperties);
				}
			}
		});

		TabItem tbtm_ostype = new TabItem(tabFolder, SWT.NONE);
		tbtm_ostype.setText("OS Type");

		ScrolledComposite scrolledComposite_os = new ScrolledComposite(tabFolder, SWT.H_SCROLL | SWT.V_SCROLL);
		tbtm_ostype.setControl(scrolledComposite_os);
		scrolledComposite_os.setExpandHorizontal(true);
		scrolledComposite_os.setExpandVertical(true);

		Composite composite_os = new Composite(scrolledComposite_os, SWT.NONE);
		composite_os.setLayout(new GridLayout(1, false));

		Group grpOstype = new Group(composite_os, SWT.NONE);
		grpOstype.setLayout(new GridLayout(3, false));
		grpOstype.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpOstype.setText("OSType");

		Label lblType_ostype = new Label(grpOstype, SWT.NONE);
		lblType_ostype.setText("Type");

		Label lblNewLabel_1_2_1 = new Label(grpOstype, SWT.NONE);
		lblNewLabel_1_2_1.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true, 1, 1));
		lblNewLabel_1_2_1.setText("Version");

		Label lblBits = new Label(grpOstype, SWT.NONE);
		lblBits.setText("Bits");

		mOStype = new Combo(grpOstype, SWT.DROP_DOWN | SWT.READ_ONLY);
		mOStype.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		setOSList();
		mOStype.addModifyListener(pModifyListener);
		mOStype.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var idx = mOStype.getSelectionIndex();
				mOSVersion.removeAll();
				for (int i = 0; i < osLists.get(idx).getVersion().size(); i++) {
					mOSVersion.add(osLists.get(idx).getVersion().get(i));
				}
			}
		});

		mOSVersion = new Combo(grpOstype, SWT.DROP_DOWN | SWT.READ_ONLY);
		mOSVersion.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mOSVersion.addModifyListener(pModifyListener);

		mOSbits = new Combo(grpOstype, SWT.DROP_DOWN | SWT.READ_ONLY);
		mOSbits.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mOSbits.setItems(new String[] { "32", "64" });
		mOSbits.addModifyListener(pModifyListener);

		scrolledComposite_os.setContent(composite_os);
		scrolledComposite_os.setMinSize(composite_os.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		TabItem tbtm_compilerType = new TabItem(tabFolder, SWT.NONE);
		tbtm_compilerType.setText("Compiler Type");

		ScrolledComposite scrolledComposite_compiler = new ScrolledComposite(tabFolder, SWT.H_SCROLL | SWT.V_SCROLL);
		tbtm_compilerType.setControl(scrolledComposite_compiler);
		scrolledComposite_compiler.setExpandHorizontal(true);
		scrolledComposite_compiler.setExpandVertical(true);

		Composite composite_compiler = new Composite(scrolledComposite_compiler, SWT.NONE);
		composite_compiler.setLayout(new GridLayout(1, false));

		Group grpCompilertype_1 = new Group(composite_compiler, SWT.NONE);
		grpCompilertype_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpCompilertype_1.setText("CompilerType");
		grpCompilertype_1.setLayout(new GridLayout(2, true));

		Label lblOsName = new Label(grpCompilertype_1, SWT.NONE);
		lblOsName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, true, 1, 1));
		lblOsName.setText("OS Name");

		Label lblVerrangeos = new Label(grpCompilertype_1, SWT.NONE);
		lblVerrangeos.setText("verRangeOS");

		mOSName = new Combo(grpCompilertype_1, SWT.BORDER | SWT.READ_ONLY);
		mOSName.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		mOSName.setItems(mOStype.getItems());
		mOSName.addModifyListener(pModifyListener);
		mOSName.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var idx = mOSName.getSelectionIndex();
				mRangeOSmin.removeAll();
				mRangeOSmax.removeAll();
				for (int i = 0; i < osLists.get(idx).getVersion().size(); i++) {
					mRangeOSmin.add(osLists.get(idx).getVersion().get(i));
				}
			}
		});

		Composite composite_vro = new Composite(grpCompilertype_1, SWT.NONE);
		composite_vro.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		composite_vro.setLayout(new GridLayout(4, false));

		Label lblMin = new Label(composite_vro, SWT.NONE);
		lblMin.setText("min");

		mRangeOSmin = new Combo(composite_vro, SWT.BORDER | SWT.READ_ONLY);
		mRangeOSmin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mRangeOSmin.addModifyListener(pModifyListener);
		mRangeOSmin.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				mRangeOSmax.removeAll();
				var idx = mRangeOSmin.getSelectionIndex();
				var maxCount = mRangeOSmin.getItemCount() - idx;
				for (int i = 0; i < maxCount; i++) {
					mRangeOSmax.add(mRangeOSmin.getItem(idx).toString(), i);
					idx++;
				}
			}
		});

		Label lblMax = new Label(composite_vro, SWT.NONE);
		lblMax.setText("max");

		mRangeOSmax = new Combo(composite_vro, SWT.BORDER | SWT.READ_ONLY);
		mRangeOSmax.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mRangeOSmax.addModifyListener(pModifyListener);

		Label lbl_cName = new Label(grpCompilertype_1, SWT.NONE);
		lbl_cName.setText("compilerName");

		Label lbl_vrc = new Label(grpCompilertype_1, SWT.NONE);
		lbl_vrc.setAlignment(SWT.RIGHT);
		lbl_vrc.setText("verRangeCompiler");

		mCompilerName = new Combo(grpCompilertype_1, SWT.BORDER | SWT.READ_ONLY);
		mCompilerName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		setCompilerList();
		mCompilerName.addModifyListener(pModifyListener);
		mCompilerName.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var idx = mCompilerName.getSelectionIndex();
				mRangeCompilermin.removeAll();
				mRangeCompilermax.removeAll();
				for (int i = 0; i < compilerLists.get(idx).getVersion().size(); i++) {
					mRangeCompilermin.add(compilerLists.get(idx).getVersion().get(i));
				}
			}
		});

		Composite composite_vrc = new Composite(grpCompilertype_1, SWT.NONE);
		composite_vrc.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		composite_vrc.setLayout(new GridLayout(4, false));

		Label lblMin_1 = new Label(composite_vrc, SWT.NONE);
		lblMin_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMin_1.setText("min");

		mRangeCompilermin = new Combo(composite_vrc, SWT.BORDER | SWT.READ_ONLY);
		mRangeCompilermin.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mRangeCompilermin.addModifyListener(pModifyListener);
		mRangeCompilermin.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				mRangeCompilermax.removeAll();
				var idx = mRangeCompilermin.getSelectionIndex();
				var maxCount = mRangeCompilermin.getItemCount() - idx;
				for (int i = 0; i < maxCount; i++) {
					mRangeCompilermax.add(mRangeCompilermin.getItem(idx).toString(), i);
					idx++;
				}
			}
		});

		Label lblMax_1 = new Label(composite_vrc, SWT.NONE);
		lblMax_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblMax_1.setText("max");

		mRangeCompilermax = new Combo(composite_vrc, SWT.BORDER | SWT.READ_ONLY);
		mRangeCompilermax.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, true, 1, 1));
		mRangeCompilermax.addModifyListener(pModifyListener);

		Label lbl_bitsCPU = new Label(grpCompilertype_1, SWT.NONE);
		lbl_bitsCPU.setText("bits");

		Label lbl_CPUarch = new Label(grpCompilertype_1, SWT.NONE);
		lbl_CPUarch.setText("CPUarch");

		mCPUbits = new Combo(grpCompilertype_1, SWT.DROP_DOWN | SWT.READ_ONLY);
		mCPUbits.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mCPUbits.setItems(new String[] { "32", "64" });
		mCPUbits.addModifyListener(pModifyListener);

		mCPUarch = new Text(grpCompilertype_1, SWT.BORDER);
		mCPUarch.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mCPUarch.addModifyListener(pModifyListener);

		scrolledComposite_compiler.setContent(composite_compiler);
		scrolledComposite_compiler.setMinSize(composite_compiler.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		TabItem tbtm_executionType = new TabItem(tabFolder, SWT.NONE);
		tbtm_executionType.setText("Execution Type");

		ScrolledComposite scrolledComposite_execution = new ScrolledComposite(tabFolder, SWT.H_SCROLL | SWT.V_SCROLL);
		tbtm_executionType.setControl(scrolledComposite_execution);
		scrolledComposite_execution.setExpandHorizontal(true);
		scrolledComposite_execution.setExpandVertical(true);

		Composite composite_execution = new Composite(scrolledComposite_execution, SWT.NONE);
		composite_execution.setLayout(new GridLayout(1, false));

		Group grpExecutiontype = new Group(composite_execution, SWT.NONE);
		grpExecutiontype.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		grpExecutiontype.setSize(552, 157);
		grpExecutiontype.setText("ExecutionType");
		grpExecutiontype.setLayout(new GridLayout(2, false));

		Label lbl_ostype = new Label(grpExecutiontype, SWT.NONE);
		lbl_ostype.setText("opType");

		Label lbl_hardRt = new Label(grpExecutiontype, SWT.NONE);
		lbl_hardRt.setText("hardRT");

		mOPTypeCombo = new Combo(grpExecutiontype, SWT.READ_ONLY | SWT.DROP_DOWN);
		mOPTypeCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mOPTypeCombo.setItems("PERIODIC", "SPORADIC", "EVENTDRIVEN", "NONRT");
		mOPTypeCombo.addModifyListener(pModifyListener);

		mhardRTCombo = new Combo(grpExecutiontype, SWT.READ_ONLY | SWT.DROP_DOWN);
		mhardRTCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mhardRTCombo.setItems("TRUE", "FALSE");
		mhardRTCombo.addModifyListener(pModifyListener);

		Label lbl_timecons = new Label(grpExecutiontype, SWT.NONE);
		lbl_timecons.setText("timeConstraint");
		lbl_timecons.setAlignment(SWT.RIGHT);

		Label lbl_insType = new Label(grpExecutiontype, SWT.NONE);
		lbl_insType.setText("instanceType");
		lbl_insType.setAlignment(SWT.RIGHT);

		mTimeConstraint = new Text(grpExecutiontype, SWT.BORDER);
		mTimeConstraint.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mTimeConstraint.addModifyListener(pModifyListener);

		minstanceTypeCombo = new Combo(grpExecutiontype, SWT.READ_ONLY | SWT.DROP_DOWN);
		minstanceTypeCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		minstanceTypeCombo.setItems("Singleton", "MultitonStatic", "MultitonCommutative");
		minstanceTypeCombo.addModifyListener(pModifyListener);

		scrolledComposite_execution.setContent(composite_execution);
		scrolledComposite_execution.setMinSize(composite_execution.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		TabItem tbtm_libraries = new TabItem(tabFolder, SWT.NONE);
		tbtm_libraries.setText("Libraries");

		ScrolledComposite scrolledComposite_lib = new ScrolledComposite(tabFolder,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		tbtm_libraries.setControl(scrolledComposite_lib);
		scrolledComposite_lib.setExpandHorizontal(true);
		scrolledComposite_lib.setExpandVertical(true);

		Composite composite_lib = new Composite(scrolledComposite_lib, SWT.NONE);
		composite_lib.setLayout(new GridLayout(1, false));

		Composite composite_addDel = new Composite(composite_lib, SWT.NONE);
		composite_addDel.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		composite_addDel.setLayout(new GridLayout(6, false));

		Label lbl_name = new Label(composite_addDel, SWT.NONE);
		lbl_name.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lbl_name.setText("Name");

		mLibrariesName = new Text(composite_addDel, SWT.BORDER);
		mLibrariesName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lbl_version = new Label(composite_addDel, SWT.NONE);
		lbl_version.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lbl_version.setText("Version");

		mLibrariesVer = new Text(composite_addDel, SWT.BORDER);
		mLibrariesVer.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Button btn_add = new Button(composite_addDel, SWT.NONE);
		btn_add.setText("Add");
		btn_add.addSelectionListener(new SelectionAdapter() { // add 버튼 동작
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (mLibrariesVer.getText().equals("")) {
					MessageBox mbx = new MessageBox(getShell(), SWT.OK
							| SWT.ICON_WARNING);
					mbx.setMessage("추가할 항목이 없습니다.");
					mbx.setText("Edit Warning");
					mbx.open();
				} else {
					// 위젯 List에 추가
					list_lib.add(mLibrariesName.getText() + " " + mLibrariesVer.getText());
					// 라이브러리 List에 추가
					Library lib = new Library(mLibrariesName.getText(), mLibrariesVer.getText());
					module.Properties.getmLibraries().getmLibraries().add(lib);
				}
				mLibrariesName.setText("");
				mLibrariesVer.setText("");
			}
		});

		Button btn_del = new Button(composite_addDel, SWT.NONE);
		btn_del.setText("Delete");
		btn_del.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				list_lib.remove(list_lib.getSelectionIndices());
				module.Properties.getmLibraries().getmLibraries().remove(libIndex);
			}
		});

		list_lib = new List(composite_lib, SWT.BORDER);
		list_lib.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		list_lib.addListener(SWT.Selection, new Listener() {
			@Override
			public void handleEvent(org.eclipse.swt.widgets.Event event) {
				int[] selection = list_lib.getSelectionIndices();
				libIndex = selection[0];
			}
		});

		scrolledComposite_lib.setContent(composite_lib);
		scrolledComposite_lib.setMinSize(composite_lib.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		if (isOld == true) {
			updateProperty(module);
			updateType(module);
			isOld = false;
		}

		composite_class.setVisible(false);
		composite_pointer.setVisible(false);
		composite_array.setVisible(false);
		composite_vector.setVisible(false);
		lbl_clsName.setVisible(false);
		text_clsName.setVisible(false);
		btn_valAdd.setVisible(false);
		btn_valDel.setVisible(false);
		((GridData) btn_valAdd.getLayoutData()).exclude = true;
		((GridData) btn_valDel.getLayoutData()).exclude = true;
		((GridData) composite_class.getLayoutData()).exclude = true;
		((GridData) composite_pointer.getLayoutData()).exclude = true;
		((GridData) composite_array.getLayoutData()).exclude = true;
		((GridData) composite_vector.getLayoutData()).exclude = true;
		((GridData) lbl_clsName.getLayoutData()).exclude = true;
		((GridData) text_clsName.getLayoutData()).exclude = true;
	}

	public void deselect() {
		mNameText.setText("");
		mTypeCombo.setText("");
		mDescriptionText.setText("");
		mUnitCombo.setText("");
		mValueText.setText("");
		textName_class.setText("");
		textName_pointer.setText("");
		text_clsName.setText("");
		text_complexName.setText("");

		combo_complex.select(index_none);
		table_arrValue.removeAll();
		table_vec.removeAll();
		// immuteCombo.setText("");
	}

	private void update(Property property) {
		property.setName(mNameText.getText());
		property.setType(mTypeCombo.getText());
		property.setUnit(mUnitCombo.getText());
		property.setDescription(mDescriptionText.getText());
		property.setValue(mValueText.getText());
		property.setNone(true);
	}

	private void updateClass(Property property) {
		property.setmComplex(combo_complex.getText());
		property.setName(textName_class.getText());
		property.setComplexName(text_complexName.getText());
		property.setClass(true);
	}

	private void updateArray(Property property, Values val) {
		property.setmComplex(combo_complex.getText());
		property.setName(mNameText.getText());
		property.setType(mTypeCombo.getText());
		property.setUnit(mUnitCombo.getText());
		property.setDescription(mDescriptionText.getText());
		property.createValues();
		property.setValues(val);
		property.setArray(true);
	}

	private void updateVector(Property property, Values val) {
		property.setmComplex(combo_complex.getText());
		property.setName(mNameText.getText());
		property.setType(mTypeCombo.getText());
		property.setUnit(mUnitCombo.getText());
		property.setDescription(mDescriptionText.getText());
		property.createValues();
		property.setValues(val);
		property.setVector(true);
	}

	private void updatePointer(Property property) {
		property.setmComplex(combo_complex.getText());
		property.setName(textName_pointer.getText());
		property.setInDataType(combo_indataType.getText());
		property.setPointer(true);
	}

	public void setOSType(OSType osType) {
		if (mOStype.getText().equals(""))
			osType.setType(null);
		else
			osType.setType(mOStype.getText());

		if (mOSVersion.getText().equals(""))
			osType.setVersion(null);
		else
			osType.setVersion(mOSVersion.getText());

		if (mOSbits.getText().equals(""))
			osType.setBits(null);
		else
			osType.setBits(mOSbits.getText());
	}

	public void setExecutionType(ExecutionType executionType) {
		if (mOPTypeCombo.getText().equals(""))
			executionType.setmOPType(null);
		else
			executionType.setmOPType(mOPTypeCombo.getText());

		if (mhardRTCombo.getText().equals(""))
			executionType.setmHardRT(null);
		else
			executionType.setmHardRT(mhardRTCombo.getText());

		if (mTimeConstraint.getText().equals(""))
			executionType.setmTimeConstraint(null);
		else
			executionType.setmTimeConstraint(mTimeConstraint.getText());

		if (minstanceTypeCombo.getText().equals(""))
			executionType.setmInstanceType(null);
		else
			executionType.setmInstanceType(minstanceTypeCombo.getText());
	}

	public void setCompilerType(CompilerType compilerType) {
		if (mOSName.getText().equals(""))
			compilerType.setmOSName(null);
		else
			compilerType.setmOSName(mOSName.getText());

		if (mCompilerName.getText().equals(""))
			compilerType.setmCompilerName(null);
		else
			compilerType.setmCompilerName(mCompilerName.getText());

		if (mRangeOSmax.getText().equals("") && mRangeOSmin.getText().equals(""))
			compilerType.setmVerRangeOS(null);
		else
			compilerType.setmVerRangeOS(new RangeString(mRangeOSmin.getText(), mRangeOSmax.getText()));

		if (mRangeCompilermin.getText().equals("") && mRangeCompilermax.getText().equals(""))
			compilerType
					.setmVerRangeCompiler(null);
		else
			compilerType
					.setmVerRangeCompiler(
							new RangeString(mRangeCompilermin.getText(), mRangeCompilermax.getText()));

		if (mCPUarch.getText().equals("") && mCPUbits.getText().equals(""))
			compilerType.setmBitsnCPUarch(null);
		else if(mCPUarch.getText().equals("")) 
			compilerType.setmBitsnCPUarch(new BitsnCPUarch(mCPUbits.getText(), null));
			else if (mCPUbits.getText().equals(""))
			compilerType.setmBitsnCPUarch(new BitsnCPUarch(null, mCPUarch.getText()));
	else
		compilerType.setmBitsnCPUarch(new BitsnCPUarch(mCPUbits.getText(), mCPUarch.getText()));
		
	}

	public void updateType(Module module) {
		var properties = module.Properties;

		if (properties.mOSType.getType() != null)
			mOStype.setText(properties.mOSType.getType());
		if (properties.mOSType.getVersion() != null)
			mOSVersion.setText(properties.mOSType.getVersion());
		findComboItem(module, mOSbits);
		if (properties.mCompilerType.getmOSName() != null)
			mOSName.setText(properties.mCompilerType.getmOSName());
		if (properties.mCompilerType.getmCompilerName() != null)
			mCompilerName.setText(properties.mCompilerType.getmCompilerName());

		if (properties.mCompilerType.getmVerRangeOS() != null) {
			if (properties.mCompilerType.getmVerRangeOS().getMin() != null)
				mRangeOSmin.setText(properties.mCompilerType.getmVerRangeOS().getMin());
			if (properties.mCompilerType.getmVerRangeOS().getMax() != null)
				mRangeOSmax.setText(properties.mCompilerType.getmVerRangeOS().getMax());
		}

		
		if (properties.mCompilerType.getmVerRangeCompiler() != null) {
			if (properties.mCompilerType.getmVerRangeCompiler().getMin() != null)
				mRangeCompilermin.setText(properties.mCompilerType.getmVerRangeCompiler().getMin());
			if (properties.mCompilerType.getmVerRangeCompiler().getMax() != null)
				mRangeCompilermax.setText(properties.mCompilerType.getmVerRangeCompiler().getMax());
		}
		
		if (properties.mCompilerType.getmBitsnCPUarch() != null) {
			if (properties.mCompilerType.getmBitsnCPUarch().getmCPUarch() != null)
			mCPUarch.setText(properties.mCompilerType.getmBitsnCPUarch().getmCPUarch());
			findComboItem(module, mCPUbits);
		}
		
		if (properties.mExecutionType.getmTimeConstraint() != null)
			mTimeConstraint.setText(properties.mExecutionType.getmTimeConstraint());
		
		findComboItem(module, mOPTypeCombo);
		findComboItem(module, mhardRTCombo);
		findComboItem(module, minstanceTypeCombo);

		if (module.Properties.getmLibraries().getmLibraries() != null) {
			var libraries = module.Properties.getmLibraries().getmLibraries();
			for (int i = 0; i < libraries.size(); i++) {
				list_lib.add(libraries.get(i).getmName() + " " + libraries.get(i).getmVersion());
			}
		}
	}

	public void updateProperty(Module module) {
		var properties = module.Properties.getProperties();
		mRoot.getValue().mProperties = properties;

		if (properties != null) {
			for (int i = 0; i < properties.size(); i++) {
				var node = mRoot.addChild(treeViewer, properties.get(i), true);
				treeViewer.expandToLevel(mRoot, 1);
				if (node.getValue().mProperties != null) {
					node.setNode(properties.get(i), treeViewer);
					treeViewer.expandAll();
				}
			}
		} else {
			return;
		}
	}

	public void findComboItem(Module module, Combo combo) {
		for (int i = 0; i < combo.getItemCount(); i++) {

			if (combo == mOSbits) {
				if (module.Properties.mOSType.getBits() != null) {
					if (module.Properties.mOSType.getBits().equals(mOSbits.getItem(i).toString()))
						mOSbits.select(i);
				}
			} else if (combo == mCPUbits) {
				if (module.Properties.mCompilerType.getmBitsnCPUarch().getmBits() != null) {
					if (module.Properties.mCompilerType.getmBitsnCPUarch().getmBits()
							.equals(mCPUbits.getItem(i).toString()))
						mCPUbits.select(i);
				}
			} else if (combo == mOPTypeCombo) {
				if (module.Properties.mExecutionType.getmOPType() != null) {
					if (module.Properties.mExecutionType.getmOPType().equals(mOPTypeCombo.getItem(i).toString()))
						mOPTypeCombo.select(i);
				}
			} else if (combo == mhardRTCombo) {
				if (module.Properties.mExecutionType.getmHardRT() != null) {
					if (module.Properties.mExecutionType.getmHardRT().equals(mhardRTCombo.getItem(i).toString()))
						mhardRTCombo.select(i);
				}
			} else if (combo == minstanceTypeCombo) {
				if (module.Properties.mExecutionType.getmInstanceType() != null) {
					if (module.Properties.mExecutionType.getmInstanceType()
							.equals(minstanceTypeCombo.getItem(i).toString()))
						minstanceTypeCombo.select(i);
				}
			}
		}
	}

	public void changeComplex(Composite container) {
		isClass = false;
		isPointer = false;
		isArray = false;
		isVector = false;
		isNormal = false;
		// array
		if (combo_complex.getSelectionIndex() == index_arr) {
			isClass = false;
			isPointer = false;
			isArray = true;
			isVector = false;
			isNormal = true;
		}
		// class
		else if (combo_complex.getSelectionIndex() == index_class) {
			isClass = true;
			isPointer = false;
			isArray = false;
			isVector = false;
			isNormal = false;
		}
		// pointer
		else if (combo_complex.getSelectionIndex() == index_pointer) {
			isClass = false;
			isPointer = true;
			isArray = false;
			isVector = false;
			isNormal = false;
		}
		// vector
		else if (combo_complex.getSelectionIndex() == index_vec) {
			isClass = false;
			isPointer = false;
			isArray = false;
			isVector = true;
			isNormal = true;
		}
		// None
		else {
			isClass = false;
			isPointer = false;
			isArray = false;
			isVector = false;
			isNormal = true;
		}
		composite_class.setVisible(isClass);
		composite_pointer.setVisible(isPointer);
		composite_array.setVisible(isArray);
		composite_normal.setVisible(isNormal);
		composite_vector.setVisible(isVector);

		boolean isTable = isArray || isVector;
		btn_valAdd.setVisible(isTable);
		btn_valDel.setVisible(isTable);
		((GridData) btn_valAdd.getLayoutData()).exclude = !isTable;
		((GridData) btn_valDel.getLayoutData()).exclude = !isTable;

		((GridData) composite_class.getLayoutData()).exclude = !isClass;
		((GridData) composite_pointer.getLayoutData()).exclude = !isPointer;
		((GridData) composite_array.getLayoutData()).exclude = !isArray;
		((GridData) composite_normal.getLayoutData()).exclude = !isNormal;
		((GridData) composite_vector.getLayoutData()).exclude = !isVector;
		container.layout(true, true);

	}

	public class ProperModifyListener implements ModifyListener {

		@Override
		public void modifyText(ModifyEvent event) {
			if (!isOld) {
				setOSType(module.Properties.getmOSType());
				setCompilerType(module.Properties.getmCompilerType());
				setExecutionType(module.Properties.getmExecutionType());
				module.Properties.setProperties(mRoot.getValue().mProperties);
			}
		}
	}

	public void setOSList() {
		try (var file = new FileReader("OSList.json")) {
			Gson gson = new Gson();
			OSList[] osList = gson.fromJson(file, OSList[].class);
			osLists = Arrays.asList(osList);

			for (int i = 0; i < osLists.size(); i++) {
				System.out.println(osLists.get(i).getName());
				mOStype.add(osLists.get(i).getName());
			}
		} catch (Exception e) {
		}
	}

	public void setCompilerList() {
		try (var file = new FileReader("CompilerList.json")) {
			Gson gson = new Gson();
			OSList[] compilerList = gson.fromJson(file, OSList[].class);
			compilerLists = Arrays.asList(compilerList);

			for (int i = 0; i < compilerLists.size(); i++) {
				System.out.println(compilerLists.get(i).getName());
				mCompilerName.add(compilerLists.get(i).getName());
			}
		} catch (Exception e) {
		}
	}
}
