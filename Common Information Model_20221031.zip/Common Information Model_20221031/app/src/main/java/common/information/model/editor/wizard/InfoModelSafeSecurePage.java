package common.information.model.editor.wizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import common.information.model.editor.cim.Overall;
import common.information.model.editor.cim.PhysicalSecurity;
import common.information.model.editor.cim.SafetyType;
import common.information.model.editor.cim.SecType;
import common.information.model.editor.cim.Module;

public class InfoModelSafeSecurePage extends WizardPage {
	private Tree safetyTree;
	String[] safeOverallItem = { "PL", "SIL" };
	String[] secOverallItem = { "PhysicalSecurity", "CyberSecurity" };
	String[] secPhyItem = { "None", "LatchSensor", "LockwithKey", "LockwithActuator" };
	String[] eValueItem = { "n", "a", "b", "c", "d", "e" };
	String[] nValueItem = { "0", "1", "2", "3", "4" };
	String[] cybSecTypeItem = { "HU_IA", "SD_IA", "ACNT_MGT", "ID_MGT", "AUTH_MGT", "WIRELEE_MGT", "PW_AUTH", "PK_CERT",
			"STR_PK_AUTH",
			"LOGIN_NO", "ACC_UNTRUST_NET", "AUTORIZE", "WIRELESS_USE", "SESS_LOCK", "SESS_TERM", "SECC_CNTR",
			"AUDT_EVT", "TIMESTM", "NON_REP", "COMM_INTG", "PROT_MALI_CODE" };
	String[] safeTypeItem = { "ESTOP", "PSTOP", "LIMWS", "SRSC", "SRFC", "HCOLA", "STCON" };
	private Combo safeOverallValue, safetyFunctionType, inSafetyType, inSafetyValue, secOverallValue, cybSecType;
	private Combo inCybType;
	private Combo inCybValue;
	private Combo safeOverallType;
	private Tree securityTree;
	private Combo secOverallType;
	private ScrolledComposite scrolledComposite_security, scrolledComposite_safety;
	private Composite rootComposite;
	private Module module;
	private boolean isOld;

	public InfoModelSafeSecurePage(Module module) {
		super("wizardPage", "SafeSecure", null);
		setDescription("Safety and Security information");
		this.module = module;
		this.isOld = false;
	}

	public InfoModelSafeSecurePage(Module module, boolean isOld) {
		super("wizardPage", "SafeSecure", null);
		setDescription("Safety and Security information");
		this.module = module;
		this.isOld = true;
	}

	@Override
	public void createControl(Composite parent) {
		rootComposite = new Composite(parent, SWT.NONE);

		setControl(rootComposite);

		rootComposite.setLayout(new GridLayout(2, false));

		scrolledComposite_safety = new ScrolledComposite(rootComposite, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite_safety.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		scrolledComposite_safety.setExpandHorizontal(true);
		scrolledComposite_safety.setExpandVertical(true);

		Group grpSafety = new Group(scrolledComposite_safety, SWT.NONE);
		grpSafety.setText("Safety");
		grpSafety.setLayout(new GridLayout(1, false));

		Group grpOverall = new Group(grpSafety, SWT.NONE);
		grpOverall.setLayout(new GridLayout(2, false));
		grpOverall.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpOverall.setText("Overall");

		safeOverallType = new Combo(grpOverall, SWT.DROP_DOWN | SWT.READ_ONLY);
		safeOverallType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safeOverallType.setItems(safeOverallItem);
		safeOverallType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int idx = safeOverallType.getSelectionIndex();
				if (idx == 0)
					safeOverallValue.setItems(eValueItem);
				else if (idx == 1)
					safeOverallValue.setItems(nValueItem);
			}
		});

		safeOverallValue = new Combo(grpOverall, SWT.DROP_DOWN | SWT.READ_ONLY);
		safeOverallValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safeOverallValue.setItems("");

		Group grpType = new Group(grpSafety, SWT.NONE);
		grpType.setLayout(new GridLayout(1, false));
		grpType.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		grpType.setText("SafetyType");

		Composite composite = new Composite(grpType, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		composite.setLayout(new GridLayout(2, false));

		Label safeTypelbl = new Label(composite, SWT.NONE);
		safeTypelbl.setText("type");

		safetyFunctionType = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
		safetyFunctionType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safetyFunctionType.setItems(safeTypeItem);

		inSafetyType = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
		inSafetyType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		inSafetyType.setItems(safeOverallItem);
		inSafetyType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int idx = inSafetyType.getSelectionIndex();
				if (idx == 0)
					inSafetyValue.setItems(eValueItem);
				else if (idx == 1)
					inSafetyValue.setItems(nValueItem);
			}
		});

		inSafetyValue = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
		inSafetyValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite safetyBtnComp = new Composite(grpType, SWT.NONE);
		safetyBtnComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safetyBtnComp.setLayout(new GridLayout(2, false));

		Button safetyAddBtn = new Button(safetyBtnComp, SWT.NONE);
		safetyAddBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safetyAddBtn.setText("Add");
		safetyAddBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var overall = new Overall();
				var safetyType = new SafetyType();

				if (module.SafeSecure.getSafety() == null) module.SafeSecure.createSafety();
				if (safetyTree.getTopItem() == null) {
					safeOverallUpdate(overall);
					module.SafeSecure.safety.setOverall(overall);
				} else {
				}
				safetyTypeUpdate(safetyType);
				module.SafeSecure.safety.getSafetyTypes().add(safetyType);
				TreeItem treeItem = new TreeItem(safetyTree, SWT.NONE);
				treeItem.setText(safetyType.getSafetyFunctionType() + " : " + safetyType.getInSafetyType()
						+ safetyType.getInSafetyValue());
			}
		});

		Button safetyDeleteBtn = new Button(safetyBtnComp, SWT.NONE);
		safetyDeleteBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		safetyDeleteBtn.setText("Delete");
		safetyDeleteBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = safetyTree.getSelection()[0];
				var idx = safetyTree.indexOf(selected);
				module.SafeSecure.getSafety().getSafetyTypes().remove(idx);
				selected.dispose();
				if (safetyTree.getItems().length == 1)
					module.SafeSecure.safety.getOverall().setOverallType("");
				module.SafeSecure.safety.getOverall().setOverallValue("");
			}
		});

		safetyTree = new Tree(grpType, SWT.BORDER | SWT.V_SCROLL);
		safetyTree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		safetyTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if (safetyTree.getItem(new Point(e.x, e.y)) == null) {
					safetyTree.deselectAll();
				}
			}
		});
		safetyTree.addSelectionListener(new SelectionAdapter() {
			@Override 
			public void widgetSelected(SelectionEvent e) {
				var selected = safetyTree.getSelection()[0];
				var idx = safetyTree.indexOf(selected);
				var selectedType = module.SafeSecure.getSafety().getSafetyTypes().get(idx);

				for (int i = 0; i < safetyFunctionType.getItemCount(); i++) {
					if (selectedType.getSafetyFunctionType().equals(safetyFunctionType.getItem(i).toString())) {
						safetyFunctionType.select(i);
					}
				}
				for (int i = 0; i < inSafetyType.getItemCount(); i++) {
					if (selectedType.getInSafetyType().equals(inSafetyType.getItem(i).toString()))
						inSafetyType.select(i);
					if (i == 0) {
						inSafetyValue.setItems(eValueItem);
					} else {
						inSafetyValue.setItems(nValueItem);
					}
					for (int j = 0; j < inSafetyValue.getItemCount(); j++) {
						if (selectedType.getInSafetyValue()
								.equals(inSafetyValue.getItem(j).toString()))
							inSafetyValue.select(j);
					}
				}
			}
		});

		scrolledComposite_safety.setContent(grpSafety);
		scrolledComposite_safety.setMinSize(grpSafety.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		scrolledComposite_security = new ScrolledComposite(rootComposite, SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite_security.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		scrolledComposite_security.setExpandHorizontal(true);
		scrolledComposite_security.setExpandVertical(true);

		Group grpSecurity = new Group(scrolledComposite_security, SWT.NONE);
		grpSecurity.setText("Security");
		grpSecurity.setLayout(new GridLayout(1, false));

		Group grpSecOverall = new Group(grpSecurity, SWT.NONE);
		grpSecOverall.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpSecOverall.setText("Overall");
		grpSecOverall.setLayout(new GridLayout(2, false));

		secOverallType = new Combo(grpSecOverall, SWT.DROP_DOWN | SWT.READ_ONLY);
		secOverallType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		secOverallType.setItems(secOverallItem);
		secOverallType.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int idx = secOverallType.getSelectionIndex();
				if (idx == 0) {
					secOverallValue.setItems(secPhyItem);
					cybSecType.setEnabled(false);
					inCybType.setEnabled(false);
					inCybValue.setEnabled(false);
				} else if (idx == 1) {
					cybSecType.setEnabled(true);
					inCybType.setEnabled(true);
					inCybValue.setEnabled(true);
					secOverallValue.setItems(nValueItem);
					cybSecType.setItems(cybSecTypeItem);
					inCybType.setItems("SIL");
					inCybValue.setItems(nValueItem);
				}
			}
		});

		secOverallValue = new Combo(grpSecOverall, SWT.DROP_DOWN | SWT.READ_ONLY);
		secOverallValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Group grpSectype = new Group(grpSecurity, SWT.NONE);
		grpSectype.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		grpSectype.setText("SecurityType");
		grpSectype.setLayout(new GridLayout(1, false));

		Composite secTypeComp = new Composite(grpSectype, SWT.NONE);
		secTypeComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		secTypeComp.setLayout(new GridLayout(2, false));

		Label secTypelbl = new Label(secTypeComp, SWT.NONE);
		secTypelbl.setText("type");

		cybSecType = new Combo(secTypeComp, SWT.DROP_DOWN | SWT.READ_ONLY);
		cybSecType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		inCybType = new Combo(secTypeComp, SWT.DROP_DOWN | SWT.READ_ONLY);
		inCybType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		inCybValue = new Combo(secTypeComp, SWT.DROP_DOWN | SWT.READ_ONLY);
		inCybValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite secBtnComp = new Composite(grpSectype, SWT.NONE);
		secBtnComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		secBtnComp.setLayout(new GridLayout(2, false));

		Button secAddBtn = new Button(secBtnComp, SWT.NONE);
		secAddBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		secAddBtn.setText("Add");
		secAddBtn.addSelectionListener(new SelectionAdapter() {
			// @TODO physicalSecurity 중복 입력 불가능하게 만들기, cyberSecurity 추가 입력 시 value 고정
			@Override
			public void widgetSelected(SelectionEvent e) {
				var secType = new SecType();
				var idx = secOverallType.getSelectionIndex();
				TreeItem childItem;

				if (module.SafeSecure.security == null) {
					module.SafeSecure.createSecurity();
				}

				if (idx == 0) {
					var physicalSecurity = new PhysicalSecurity();
					physicalSecurity.setValue(secOverallValue.getText());
					module.SafeSecure.security.setPhysicalSecurity(physicalSecurity);
					var phyParent = new TreeItem(securityTree, SWT.NONE);
					phyParent.setText(secOverallItem[0]);
					childItem = new TreeItem(phyParent, SWT.NONE);
					// }
					childItem.setText(physicalSecurity.getValue());
				} else {
					module.SafeSecure.security.setCyberSecurity();
					cybTypeUpdate(secType);
					module.SafeSecure.security.getCyberSecurity().setOverallValue(secOverallValue.getText());
					if (module.SafeSecure.security.getCyberSecurity().getSecTypes() == null) {
						module.SafeSecure.security.getCyberSecurity().createSecType();
					}
					module.SafeSecure.security.getCyberSecurity().getSecTypes().add(secType);
					if (securityTree.getTopItem() != null) {
						var item = securityTree.getItems();
						if (item.length == 2) {
							for (var items : securityTree.getItems()) {
								if (items.getText().startsWith(secOverallItem[1])) {
									childItem = new TreeItem(items, SWT.NONE);
									childItem.setText(
											secType.getCybFunctionType() + " : " + secType.getInCybType()
													+ secType.getInCybValue());
								}
							}
						} else if (item.length == 1) {
							if (item[0].getText().startsWith(secOverallItem[1])) {
								childItem = new TreeItem(item[0], SWT.NONE);
								childItem.setText(
										secType.getCybFunctionType() + " : " + secType.getInCybType()
												+ secType.getInCybValue());
							} else {
								var cybParent = new TreeItem(securityTree, SWT.NONE);
								childItem = new TreeItem(cybParent, SWT.NONE);
								cybParent.setText(secOverallItem[1] + " : " + module.SafeSecure.security
										.getCyberSecurity().getOverallValue());
								childItem.setText(
										secType.getCybFunctionType() + " : " + secType.getInCybType()
												+ secType.getInCybValue());
							}
						}
					} else {
						var cybParent = new TreeItem(securityTree, SWT.NONE);
						childItem = new TreeItem(cybParent, SWT.NONE);
						cybParent.setText(secOverallItem[1] + " : "
								+ module.SafeSecure.security.getCyberSecurity().getOverallValue());
						childItem.setText(
								secType.getCybFunctionType() + " : " + secType.getInCybType()
										+ secType.getInCybValue());
					}
				}
			}
		});

		Button secDeleteBtn = new Button(secBtnComp, SWT.NONE);
		secDeleteBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		secDeleteBtn.setText("Delete");
		secDeleteBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = securityTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				//최상단 트리일 경우
				if (parentItem != null) {
					var idx = parentItem.indexOf(selected);
					if (parentItem.getText() == secOverallItem[0]) {
						module.SafeSecure.security.setPhysicalSecurity(null);
						selected.getParentItem().dispose();
					} else
						module.SafeSecure.security.getCyberSecurity().getSecTypes().remove(idx);
				} else {
					if (selected.getText() == secOverallItem[0]){
						module.SafeSecure.security.setPhysicalSecurity(null);
					}
					else module.SafeSecure.security.setCyberSecurity(null);
				}

				selected.dispose();
			}
		});

		securityTree = new Tree(grpSectype, SWT.BORDER);
		securityTree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		securityTree.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = securityTree.getSelection()[0];
				var idx = securityTree.indexOf(selected);

				if (selected.getParentItem() == null) {
					if (selected.getText() == "PhysicalSecurity") {
						secOverallType.select(0);
						secOverallValue.setItems(secPhyItem);
						cybSecType.setEnabled(false);
						inCybType.setEnabled(false);
						inCybValue.setEnabled(false);
						for (int j = 0; j < secOverallValue.getItemCount(); j++) {
							if (module.SafeSecure.security.getPhysicalSecurity() != null) {
								if (module.SafeSecure.security.getPhysicalSecurity().getValue()
										.equals(secOverallValue.getItem(j).toString()))
									secOverallValue.select(j);	
							} else {
								secOverallValue.setText("");
							}
						}
					} else if (selected.getText().startsWith("CyberSecurity")) {
						secOverallType.select(1);
						cybSecType.setEnabled(true);
						inCybType.setEnabled(true);
						inCybValue.setEnabled(true);
						secOverallValue.setItems(nValueItem);
						cybSecType.setItems(cybSecTypeItem);
						inCybType.setItems("SIL");
						inCybValue.setItems(nValueItem);
						for (int j = 0; j < secOverallValue.getItemCount(); j++) {
							if (module.SafeSecure.security.getCyberSecurity().getOverallValue()
							.equals(secOverallValue.getItem(j).toString()))
							secOverallValue.select(j);
						}
					}
				} else {
					if (selected.getParentItem().getText().startsWith("CyberSecurity")) {
						var secidx = selected.getParentItem().indexOf(selected);
						var selectedType = module.SafeSecure.getSecurity().getCyberSecurity().getSecTypes()
						.get(secidx);
						secOverallType.select(1);
						cybSecType.setEnabled(true);
						inCybType.setEnabled(true);
						inCybValue.setEnabled(true);
						secOverallValue.setItems(nValueItem);
						cybSecType.setItems(cybSecTypeItem);
						inCybType.setItems("SIL");
						inCybType.select(0);
						inCybValue.setItems(nValueItem);
						for (int j = 0; j < secOverallValue.getItemCount(); j++) {
							if (module.SafeSecure.security.getCyberSecurity().getOverallValue()
									.equals(secOverallValue.getItem(j).toString()))
								secOverallValue.select(j);
						}

						for (int i = 0; i < cybSecType.getItemCount(); i++) {
							if (selectedType.getCybFunctionType().equals(cybSecType.getItem(i).toString()))
								cybSecType.select(i);
						}
						for (int i = 0; i < inCybValue.getItemCount(); i++) {
							if (selectedType.getInCybValue().equals(inCybValue.getItem(i).toString()))
								inCybValue.select(i);
						}
					} else if (selected.getParentItem().getText() == "PhysicalSecurity") {
						secOverallType.select(0);
						secOverallValue.setItems(secPhyItem);
						cybSecType.setEnabled(false);
						inCybType.setEnabled(false);
						inCybValue.setEnabled(false);
						for (int j = 0; j < secOverallValue.getItemCount(); j++) {
							if (module.SafeSecure.security.getPhysicalSecurity().getValue()
									.equals(secOverallValue.getItem(j).toString()))
								secOverallValue.select(j);
						}
					}
				}
			}
		});

		scrolledComposite_security.setContent(grpSecurity);
		scrolledComposite_security.setMinSize(grpSecurity.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		if (isOld == true) {
			updateSafety(module);
			updateSecurity(module);
		}
	}

	public void updateSafety(Module module) {
		if (module.SafeSecure.getSafety() != null) {
			var safeties = module.SafeSecure.getSafety().getSafetyTypes();
			if (safeties != null) {
				findComboItem(module, safeOverallType);
				findComboItem(module, safeOverallValue);
				for (int i = 0; i < safeties.size(); i++) {
					TreeItem safetyItem = new TreeItem(safetyTree, SWT.NONE);
					if (safeties.get(i).getInSafetyType() == null) {
						for (int j = 0; j < nValueItem.length; j++) {
							if (safeties.get(i).getInSafetyValue().equals(nValueItem[j])){
								safeties.get(i).setInSafetyType(safeOverallItem[1]);
								break;
							} else {safeties.get(i).setInSafetyType(safeOverallItem[0]);}
						}
					}
					safetyItem.setText(safeties.get(i).getSafetyFunctionType() + " : " + safeties.get(i).getInSafetyType()
					+ safeties.get(i).getInSafetyValue());
				}
			} else {
				module.SafeSecure.getSafety().setSafetyTypes();
			}	
		}
	}
	
	public void updateSecurity(Module module) {
		if (module.SafeSecure.getSecurity() != null) {
			var cyberSecurity = module.SafeSecure.getSecurity().getCyberSecurity();
			var phySecurity = module.SafeSecure.getSecurity().getPhysicalSecurity();
	
			if (phySecurity != null) {
				var phyParent = new TreeItem(securityTree, SWT.NONE);
				phyParent.setText(secOverallItem[0]);
				var phyItem = new TreeItem(phyParent, SWT.NONE);
				if (phySecurity.getValue() != null) phyItem.setText(phySecurity.getValue());
				securityTree.showItem(phyItem);
			}
			if (cyberSecurity != null) {
				var cyberParent = new TreeItem(securityTree, SWT.NONE);
				cyberParent.setText(secOverallItem[1] + " : " + cyberSecurity.getOverallValue());
				if (cyberSecurity.getSecTypes() != null) {
					for (int i = 0; i < cyberSecurity.getSecTypes().size(); i++) {
						var cyberItem = new TreeItem(cyberParent, SWT.NONE);
						cyberSecurity.getSecTypes().get(i).setInCybType(safeOverallItem[1]);
						cyberItem.setText(cyberSecurity.getSecTypes().get(i).getCybFunctionType() + " : " + cyberSecurity.getSecTypes().get(i).getInCybType()
						+ cyberSecurity.getSecTypes().get(i).getInCybValue());
						securityTree.showItem(cyberItem);
					}
				}
			}
		}
	}

	public void findComboItem(Module module, Combo combo) {
		for (int i = 0; i < combo.getItemCount(); i++) {
			if (combo == safeOverallType) {
				if (module.SafeSecure.safety.getOverall().getOverallType()
						.equals(safeOverallType.getItem(i).toString())) {
							safeOverallType.select(i);
							if (i == 0) {
								safeOverallValue.setItems(eValueItem);
							} else { safeOverallValue.setItems(nValueItem); }
							for (int j = 0; j < safeOverallValue.getItemCount(); j++) {
								if (module.SafeSecure.safety.getOverall().getOverallValue()
										.equals(safeOverallValue.getItem(j).toString()))
									safeOverallValue.select(j);
						}
				}
			}
		}
	}

	private void safeOverallUpdate(Overall overall) {
		overall.setOverallType(safeOverallType.getText());
		overall.setOverallValue(safeOverallValue.getText());
	}

	private void safetyTypeUpdate(SafetyType safetyType) {
		safetyType.setSafetyFunctionType(safetyFunctionType.getText());
		safetyType.setInSafetyType(inSafetyType.getText());
		safetyType.setInSafetyValue(inSafetyValue.getText());
	}

	public void setVisible(boolean isVisible) {
		super.setVisible(isVisible);
		if (isVisible) {
			scrolledComposite_safety.setVisible(module.isSafety);
			scrolledComposite_security.setVisible(module.isSecurity);
			((GridData) scrolledComposite_safety.getLayoutData()).exclude = !module.isSafety;
			((GridData) scrolledComposite_security.getLayoutData()).exclude = !module.isSecurity;
			rootComposite.layout(true, true);
		}
	}

	private void cybTypeUpdate(SecType secType) {
		secType.setCybFunctionType(cybSecType.getText());
		secType.setInCybType(inCybType.getText());
		secType.setInCybValue(inCybValue.getText());
	}

}
