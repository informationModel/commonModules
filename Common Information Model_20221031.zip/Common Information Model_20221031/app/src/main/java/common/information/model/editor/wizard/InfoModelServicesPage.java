package common.information.model.editor.wizard;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import common.information.model.editor.cim.ArgSpec;
import common.information.model.editor.cim.Method;
// import common.information.model.editor.wizard.InfoModelModellingPage.UploadHandler;
import common.information.model.editor.cim.Module;
import common.information.model.editor.cim.ServiceProfile;
import common.information.model.editor.cim.ServicesProperties;

public class InfoModelServicesPage extends WizardPage {
	private Text mProfileID, mPropertiesName,
			mMethodName, mArgName, mPropertiesValue, text_idlpath;
	private Combo mProfilePvType, mMethodMOType, mArgIO, mProfileType, mRetType, mArgType, mProfileMOType;
	private Tree serviceTree;
	int i = 0;
	private Module module;
	private String typeList[] = { "bool", "int", "int8", "int16", "int32", "int64", "uint8", "uint16", "uint32",
			"uint64", "float32", "float64", "any", "enumeration", "void", "array", "class", "pointer", "string",
			"vector" };
	private Button btnAddMethod, btnUpdateMethod, btnDeleteMethod, btnAddSpec, btnUpdateSpec, btnDeleteSpec;
	private Group grpServiceprofile, grpMethod, grpArgspec, grpProper;
	private int serviceProfileIdx;
	private TableViewer tableViewer;
	private boolean isOld;
	private Composite composite_xml;
	private Composite composite_idl;
	private Composite btnProfileComp;
	private Button fileUploadIDL;
	private boolean isIDL;
	private boolean isXML;

	public InfoModelServicesPage(Module module) {
		super("wizardPage", "Services", null);
		setDescription("Service Information");
		this.module = module;
	}

	public InfoModelServicesPage(Module module, boolean isOld) {
		super("wizardPage", "Services", null);
		setDescription("Service Information");
		this.module = module;
		this.isOld = isOld;
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);

		setControl(container);
		container.setLayout(new FillLayout(SWT.HORIZONTAL));

		ScrolledComposite scrolledComposite = new ScrolledComposite(container,
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);

		Composite composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setLayout(new GridLayout(1, false));

		serviceTree = new Tree(container, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
		serviceTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				if (serviceTree.getItem(new Point(e.x, e.y)) == null) {
					serviceTree.deselectAll();
					deselect();
				}
			}
			
		});
		serviceTree.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				if (parentItem == null) {
					var idx = serviceTree.indexOf(selected);
					serviceProfileIdx = idx;
					ServiceProfile sProfile = module.Services.getServiceProfiles().get(idx);
					selectProfile(sProfile);
					if (sProfile.getType().equals("IDL")) {
						grpMethod.setEnabled(false);	
					} else {
						grpMethod.setEnabled(true);
					}
					grpServiceprofile.setEnabled(true);
					btnProfileComp.setEnabled(true);
					grpArgspec.setEnabled(false);
					grpProper.setEnabled(true);
				} else if (parentItem.getParentItem() == null) {
					var pidx = serviceTree.indexOf(parentItem);
					var idx = parentItem.indexOf(selected);
					selectMethod(module.Services.getServiceProfiles().get(pidx),
							module.Services.getServiceProfiles().get(pidx).getMethods().get(idx));
					grpServiceprofile.setEnabled(false);
					btnProfileComp.setEnabled(false);
					grpMethod.setEnabled(true);
					grpArgspec.setEnabled(true);
					grpProper.setEnabled(false);
				} else if (parentItem.getParentItem().getParentItem() == null) {
					var ppidx = serviceTree.indexOf(parentItem.getParentItem());
					var pidx = parentItem.getParentItem().indexOf(parentItem);
					var idx = parentItem.indexOf(selected);
					selectSpec(module.Services.getServiceProfiles().get(ppidx),
							module.Services.getServiceProfiles().get(ppidx).getMethods().get(pidx),
							module.Services.getServiceProfiles().get(ppidx).getMethods().get(pidx).getArgSpecs()
									.get(idx));
					grpServiceprofile.setEnabled(false);
					btnProfileComp.setEnabled(false);
					grpProper.setEnabled(false);
					grpMethod.setEnabled(false);
					grpArgspec.setEnabled(true);
				}
			}
		});

		grpServiceprofile = new Group(composite, SWT.NONE);
		grpServiceprofile.setText("ServiceProfile");
		grpServiceprofile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpServiceprofile.setLayout(new GridLayout(1, false));

		Composite profileCompo = new Composite(grpServiceprofile, SWT.NONE);
		profileCompo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		profileCompo.setLayout(new GridLayout(6, false));

		Label profileTypelbl = new Label(profileCompo, SWT.NONE);
		profileTypelbl.setText("type");

		mProfileType = new Combo(profileCompo, SWT.NONE);
		mProfileType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 5, 1));
		mProfileType.setItems("IDL", "XML");
		mProfileType.addModifyListener(new ModifyListener() {

			@Override
			public void modifyText(ModifyEvent event) {
				isIDL = false;
				isXML = false;
				if (mProfileType.getSelectionIndex() == 0) {
					isIDL = true;
					isXML = false;
					btnProfileComp.setEnabled(true);
				} else if (mProfileType.getSelectionIndex() == 1) {
					isIDL = false;
					isXML = true;
					btnProfileComp.setEnabled(true);
				} else {
					btnProfileComp.setEnabled(false);
				}
				composite_idl.setVisible(isIDL);
				composite_xml.setVisible(isXML);
				grpProper.setVisible(isXML);
				((GridData) composite_idl.getLayoutData()).exclude = !isIDL;
				((GridData) composite_xml.getLayoutData()).exclude = !isXML;
				((GridData) grpProper.getLayoutData()).exclude = !isXML;
				container.layout(true, true);

			}
		});
		composite_xml = new Composite(grpServiceprofile, SWT.NONE);
		composite_xml.setLayout(new GridLayout(4, false));
		composite_xml.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblId = new Label(composite_xml, SWT.NONE);
		lblId.setText("ID");

		mProfileID = new Text(composite_xml, SWT.BORDER);
		mProfileID.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblmProMOType = new Label(composite_xml, SWT.NONE);
		lblmProMOType.setText("MOType");

		mProfileMOType = new Combo(composite_xml, SWT.READ_ONLY);
		mProfileMOType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mProfileMOType.setItems("MANDATORY", "OPTIONAL");

		Label pvTypelbl = new Label(composite_xml, SWT.NONE);
		pvTypelbl.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		pvTypelbl.setText("PvType");

		mProfilePvType = new Combo(composite_xml, SWT.DROP_DOWN | SWT.READ_ONLY);
		mProfilePvType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mProfilePvType.setItems("PHYSICAL", "VIRTUAL");

		composite_idl = new Composite(grpServiceprofile, SWT.NONE);
		composite_idl.setLayout(new GridLayout(3, false));
		composite_idl.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lbl_idlpath = new Label(composite_idl, SWT.NONE);
		lbl_idlpath.setText("IDL Path");

		text_idlpath = new Text(composite_idl, SWT.BORDER);
		text_idlpath.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		fileUploadIDL = new Button(composite_idl, SWT.NONE);
		fileUploadIDL.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		fileUploadIDL.setText("Select File");
		fileUploadIDL.addSelectionListener(UploadSelectionListener);

		grpProper = new Group(grpServiceprofile, SWT.NONE);
		grpProper.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		grpProper.setLayout(new GridLayout(4, false));
		grpProper.setText("Properties");

		tableViewer = new TableViewer(grpProper, SWT.BORDER | SWT.FULL_SELECTION);
		Table tableProperties = tableViewer.getTable();
		tableProperties.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 4, 1));
		tableProperties.setHeaderVisible(true);
		tableProperties.setLinesVisible(true);

		GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 4, 1);
		gd_table.heightHint = 80;
		tableViewer.getTable().setLayoutData(gd_table);

		TableViewerColumn tableViewerColumn_name = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnName = tableViewerColumn_name.getColumn();
		tblclmnName.setWidth(100);
		tblclmnName.setText("Name");

		TableViewerColumn tableViewerColumn_value = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnValue = tableViewerColumn_value.getColumn();
		tblclmnValue.setWidth(100);
		tblclmnValue.setText("Value");

		tableViewer.getControl().addControlListener(new ControlListener() {
			@Override
			public void controlResized(ControlEvent e) {
				Rectangle rect = tableViewer.getTable().getClientArea();
				if (rect.width > 0) {
					int extraSpace = rect.width / tableViewer.getTable().getColumnCount();
					tableViewerColumn_name.getColumn().setWidth(extraSpace);
					tableViewerColumn_value.getColumn().setWidth(extraSpace);
				}
			}

			@Override
			public void controlMoved(ControlEvent e) {
				// TODO Auto-generated method stub
			}
		});

		tableViewer.addSelectionChangedListener(e -> {
			var selected = tableViewer.getTable().getSelection()[0];
			var idx = tableViewer.getTable().indexOf(selected);
			var selectedProperty = module.Services.getServiceProfiles().get(serviceProfileIdx).getProperties().get(idx);

			mPropertiesName.setText(selectedProperty.name);
			mPropertiesValue.setText(selectedProperty.value);
		});

		Label propertieslbl = new Label(grpProper, SWT.NONE);
		propertieslbl.setText("Name");

		mPropertiesName = new Text(grpProper, SWT.BORDER);
		mPropertiesName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Label lblValue = new Label(grpProper, SWT.NONE);
		lblValue.setText("Value");

		mPropertiesValue = new Text(grpProper, SWT.BORDER);
		mPropertiesValue.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite composite_properties = new Composite(grpProper, SWT.NONE);
		composite_properties.setLayout(new GridLayout(2, false));
		composite_properties.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 1));

		Button btn_proAdd = new Button(composite_properties, SWT.NONE);
		btn_proAdd.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btn_proAdd.setText("Add");

		btn_proAdd.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ServicesProperties sp = new ServicesProperties();
				sp.name = mPropertiesName.getText();
				sp.value = mPropertiesValue.getText();
				module.Services.getServiceProfiles().get(serviceProfileIdx).createProperties();
				module.Services.getServiceProfiles().get(serviceProfileIdx).getProperties().add(sp);

				TableItem item = new TableItem(tableViewer.getTable(), SWT.NONE);
				item.setText(0, sp.name);
				item.setText(1, sp.value);

				tableViewer.getTable().setSelection(item);
			}
		});

		Button btn_proDel = new Button(composite_properties, SWT.NONE);
		btn_proDel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btn_proDel.setText("Delete");
		btn_proDel.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = tableViewer.getTable().getSelection()[0];
				var idx = tableViewer.getTable().indexOf(selected);

				tableViewer.getTable().remove(idx);
				module.Services.getServiceProfiles().get(serviceProfileIdx).getProperties().remove(idx);
				mPropertiesName.setText("");
				mPropertiesValue.setText("");
			}
		});

		btnProfileComp = new Composite(grpServiceprofile, SWT.NONE);
		btnProfileComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnProfileComp.setLayout(new GridLayout(3, false));

		Button btnAddProfile = new Button(btnProfileComp, SWT.NONE);
		btnAddProfile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddProfile.setText("Add");
		btnAddProfile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var serviceProfile = new ServiceProfile();
				var profileItem = new TreeItem(serviceTree, SWT.NONE);
				if (isXML) {
					profileUpdate(serviceProfile);
					module.Services.getServiceProfiles().add(serviceProfile);
					profileItem.setText("Service Profile : " + "(" + serviceProfile.getType() + ")" + serviceProfile.getID()
							+ ", " + serviceProfile.getMoType() + ", " + serviceProfile.getPvType());
				} else if (isIDL) {
					profileUpdate(serviceProfile);
					module.Services.getServiceProfiles().add(serviceProfile);
					profileItem.setText("Service Profile : " + "(" + serviceProfile.getType() + ")" + serviceProfile.getPath());
				} else System.out.println("오류 : 타입을 설정해주세요");

			}
		});

		Button btnUpgradeProfile = new Button(btnProfileComp, SWT.NONE);
		btnUpgradeProfile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnUpgradeProfile.setText("Update");
		btnUpgradeProfile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var idx = serviceTree.indexOf(selected);
				var profile = module.Services.getServiceProfiles().get(idx);

				profileUpdate(profile);
				if (mProfileType.getText().equals("XML")) {
					selected.setText("Service Profile : " + "(" + profile.getType() + ")" + profile.getID()
							+ ", " + profile.getMoType() + ", " + profile.getPvType());	
				} else 
					selected.setText(
							"Service Profile : " + "(" + profile.getType() + ")" + profile.getPath());
				serviceTree.redraw();
			}
		});

		Button btnDeleteProfile = new Button(btnProfileComp, SWT.NONE);
		btnDeleteProfile.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnDeleteProfile.setText("Delete");
		btnDeleteProfile.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var idx = serviceTree.indexOf(selected);

				module.Services.getServiceProfiles().remove(idx);
				selected.dispose();
			}
		});

		grpMethod = new Group(composite, SWT.NONE);
		grpMethod.setText("Method");
		grpMethod.setLayout(new GridLayout(1, false));
		grpMethod.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite methodcomp = new Composite(grpMethod, SWT.NONE);
		methodcomp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		methodcomp.setLayout(new GridLayout(4, false));

		Label lblName = new Label(methodcomp, SWT.NONE);
		lblName.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblName.setText("Name");

		mMethodName = new Text(methodcomp, SWT.BORDER);
		mMethodName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblMOType = new Label(methodcomp, SWT.NONE);
		lblMOType.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1));
		lblMOType.setText("MOType");

		mMethodMOType = new Combo(methodcomp, SWT.DROP_DOWN | SWT.READ_ONLY);
		mMethodMOType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mMethodMOType.setItems("MANDATORY", "OPTIONAL");

		Label lblRetType = new Label(methodcomp, SWT.NONE);
		lblRetType.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblRetType.setText("RetType");

		mRetType = new Combo(methodcomp, SWT.READ_ONLY);
		mRetType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mRetType.setItems(typeList);

		Composite btnMethodComp = new Composite(grpMethod, SWT.NONE);
		btnMethodComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnMethodComp.setLayout(new GridLayout(3, false));

		btnAddMethod = new Button(btnMethodComp, SWT.NONE);
		btnAddMethod.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddMethod.setText("Add");
		btnAddMethod.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var method = new Method();
				var selected = serviceTree.getSelection()[0];
				var idx = serviceTree.indexOf(selected);
				methodUpdate(method);
				if (selected.getParentItem() == null) {
					var methodItem = new TreeItem(serviceTree.getSelection()[0], SWT.NONE);
					methodItem.setText(
							"method : (" + method.getMOType() + ") " + method.getName() + ", " + method.getRetType());
					serviceTree.showItem(methodItem);
				} else {
				}
				module.Services.getServiceProfiles().get(idx).createMethods();
				module.Services.getServiceProfiles().get(idx).getMethods().add(method);
			}
		});

		btnUpdateMethod = new Button(btnMethodComp, SWT.NONE);
		btnUpdateMethod.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnUpdateMethod.setText("Update");
		btnUpdateMethod.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var pidx = serviceTree.indexOf(selected.getParentItem());
				var idx = selected.getParentItem().indexOf(selected);
				var method = module.Services.getServiceProfiles().get(pidx).getMethods().get(idx);

				methodUpdate(method);
				selected.setText(
						"method : (" + method.getMOType() + ") " + method.getName() + ", " + method.getRetType());
				serviceTree.redraw();
			}
		});

		btnDeleteMethod = new Button(btnMethodComp, SWT.NONE);
		btnDeleteMethod.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnDeleteMethod.setText("Delete");
		btnDeleteMethod.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				var pidx = serviceTree.indexOf(parentItem);
				var idx = parentItem.indexOf(selected);

				module.Services.getServiceProfiles().get(pidx).getMethods().remove(idx);
				selected.dispose();
			}
		});

		grpArgspec = new Group(composite, SWT.NONE);
		grpArgspec.setText("ArgSpec");
		grpArgspec.setLayout(new GridLayout(1, false));
		grpArgspec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		Composite argcomp = new Composite(grpArgspec, SWT.NONE);
		argcomp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		argcomp.setLayout(new GridLayout(4, false));

		Label lblArgname = new Label(argcomp, SWT.NONE);
		lblArgname.setText("ArgName");

		mArgName = new Text(argcomp, SWT.BORDER);
		mArgName.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));

		Label lblArgType = new Label(argcomp, SWT.NONE);
		lblArgType.setText("ArgType");

		mArgType = new Combo(argcomp, SWT.NONE);
		mArgType.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mArgType.setItems(typeList);

		Label lblArgIO = new Label(argcomp, SWT.NONE);
		lblArgIO.setText("ArgIO");

		mArgIO = new Combo(argcomp, SWT.DROP_DOWN | SWT.READ_ONLY);
		mArgIO.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		mArgIO.setItems("IN", "OUT", "INOUT");

		Composite btnArgSpecComp = new Composite(grpArgspec, SWT.NONE);
		btnArgSpecComp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnArgSpecComp.setLayout(new GridLayout(3, false));

		btnAddSpec = new Button(btnArgSpecComp, SWT.NONE);
		btnAddSpec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnAddSpec.setText("Add");
		btnAddSpec.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var argSpec = new ArgSpec();
				var selected = serviceTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				var profileidx = serviceTree.indexOf(parentItem);
				var methodidx = parentItem.indexOf(selected);
				argUpdate(argSpec);
				if (parentItem.getParentItem() == null) {
					var argSpecItem = new TreeItem(selected, SWT.NONE);
					argSpecItem.setText("argSpec" + " : (" + argSpec.getArgIO() + ")" +
							argSpec.getArgName() + ", " + argSpec.getArgType());
					serviceTree.showItem(argSpecItem);
				} else {
				}
				module.Services.getServiceProfiles().get(profileidx).getMethods().get(methodidx).createArgSpecs();
				module.Services.getServiceProfiles().get(profileidx).getMethods().get(methodidx).getArgSpecs()
						.add(argSpec);
			}
		});

		btnUpdateSpec = new Button(btnArgSpecComp, SWT.NONE);
		btnUpdateSpec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnUpdateSpec.setText("Update");
		btnUpdateSpec.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				var ppidx = serviceTree.indexOf(parentItem.getParentItem());
				var pidx = parentItem.getParentItem().indexOf(parentItem);
				var idx = parentItem.indexOf(selected);
				var argSpec = module.Services.getServiceProfiles().get(ppidx).getMethods().get(pidx).getArgSpecs()
						.get(idx);

				argUpdate(argSpec);
				selected.setText("argSpec" + " : (" + argSpec.getArgIO() + ")" +
						argSpec.getArgName() + ", " + argSpec.getArgType());
				serviceTree.redraw();
			}
		});

		btnDeleteSpec = new Button(btnArgSpecComp, SWT.NONE);
		btnDeleteSpec.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnDeleteSpec.setText("Delete");
		btnDeleteSpec.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				var selected = serviceTree.getSelection()[0];
				var parentItem = selected.getParentItem();
				var ppidx = serviceTree.indexOf(parentItem.getParentItem());
				var pidx = parentItem.getParentItem().indexOf(parentItem);
				var idx = parentItem.indexOf(selected);

				module.Services.getServiceProfiles().get(ppidx).getMethods().get(pidx).getArgSpecs().remove(idx);
				selected.dispose();
			}
		});

		scrolledComposite.setContent(composite);
		scrolledComposite.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		grpServiceprofile.setEnabled(true);
		grpMethod.setEnabled(false);
		grpArgspec.setEnabled(false);
		grpProper.setEnabled(false);
		btnProfileComp.setEnabled(false);

		if (isOld == true) {
			enterInformation(module);
		}

		composite_xml.setVisible(false);
		composite_idl.setVisible(false);
		grpProper.setVisible(false);
		((GridData) composite_xml.getLayoutData()).exclude = true;
		((GridData) composite_idl.getLayoutData()).exclude = true;
		((GridData) grpProper.getLayoutData()).exclude = true;
	}

	public void enterInformation(Module module) {
		var sProfiles = module.Services.getServiceProfiles();

		if (sProfiles != null) {
			for (int i = 0; i < sProfiles.size(); i++) {
				var profileItem = new TreeItem(serviceTree, SWT.NONE);
				if (sProfiles.get(i).getType().equals("XML")) {
					profileItem
							.setText("sProfile : " + "(" + sProfiles.get(i).getType() + ")" + sProfiles.get(i).getID()
									+ ", " + sProfiles.get(i).getMoType() + ", " + sProfiles.get(i).getPvType());
				} else if (sProfiles.get(i).getType().equals("IDL")) {
					profileItem
							.setText("sProfile : " + "(" + sProfiles.get(i).getType() + ")" + sProfiles.get(i).getPath());
				}
				
				if (sProfiles.get(i).getProperties() != null) {
					for (int j = 0; j < sProfiles.get(i).getProperties().size(); j++) {
						TableItem item = new TableItem(tableViewer.getTable(), SWT.NONE);
						item.setText(0, sProfiles.get(i).getProperties().get(j).name);
						item.setText(1, sProfiles.get(i).getProperties().get(j).value);
					}
				} else {
				}
				if (sProfiles.get(i).getType().equals("XML"))
					enterMethod(module, profileItem, i);
			}
		}
	}

	public void enterMethod(Module module, TreeItem treeItem, int i) {
		var methods = module.Services.getServiceProfiles().get(i).getMethods();
		for (int j = 0; j < methods.size(); j++) {
			var methodItem = new TreeItem(treeItem, SWT.NONE);
			methodItem.setText("method : (" + methods.get(j).getMOType() + ") " + methods.get(j).getName() + ", " + methods.get(j).getRetType());
					
			serviceTree.showItem(methodItem);
			if (methods.get(j).getArgSpecs() != null) {
				for (int k = 0; k < methods.get(j).getArgSpecs().size(); k++) {
					var argItem = new TreeItem(methodItem, SWT.NONE);
					argItem.setText("argSpec" + " : (" + methods.get(j).getArgSpecs().get(k).getArgIO() + ")" +
							methods.get(j).getArgSpecs().get(k).getArgName() + ", "
							+ methods.get(j).getArgSpecs().get(k).getArgType());
							
					serviceTree.showItem(argItem);
				}
			}
		}
	}

	private void profileUpdate(ServiceProfile serviceProfile) {

		if (isIDL) {
			serviceProfile.setPath(text_idlpath.getText());
			serviceProfile.setType(mProfileType.getText());
		} else {
			serviceProfile.setType(mProfileType.getText());
			serviceProfile.setType(mProfileType.getText());
			serviceProfile.setID(mProfileID.getText());
			serviceProfile.setPvType(mProfilePvType.getText());
			serviceProfile.setMOType(mProfileMOType.getText());
		}
	}

	private void methodUpdate(Method method) {
		method.setName(mMethodName.getText());
		method.setMOType(mMethodMOType.getText());
		method.setRetType(mRetType.getText());
	}

	private void argUpdate(ArgSpec argSpec) {
		argSpec.setArgType(mArgType.getText());
		argSpec.setArgName(mArgName.getText());
		argSpec.setArgIO(mArgIO.getText());
	}

	private void selectProfile(ServiceProfile serviceProfile) {
		if (serviceProfile.getType().equals("IDL")) {
			mProfileType.setText(serviceProfile.getType());
			text_idlpath.setText(serviceProfile.getPath());
		} else if (serviceProfile.getType().equals("XML")) {
			mProfileType.setText(serviceProfile.getType());
			mProfileID.setText(serviceProfile.getID());
			mProfileMOType.setText(serviceProfile.getMoType());
			mProfilePvType.setText(serviceProfile.getPvType());
			mMethodMOType.setText(serviceProfile.getMoType());
			// 프로펄티 표추가
			tableViewer.getTable().removeAll();
			if (serviceProfile.getProperties() != null) {
				for (int i = 0; i < serviceProfile.getProperties().size(); i++) {
					TableItem item = new TableItem(tableViewer.getTable(), SWT.NONE);
					item.setText(0, serviceProfile.getProperties().get(i).name);
					item.setText(1, serviceProfile.getProperties().get(i).value);
					tableViewer.getTable().setSelection(item);
				}
			}
	
		}
	}

	private void selectMethod(ServiceProfile serviceProfile, Method method) {
		selectProfile(serviceProfile);
		mMethodName.setText(method.getName());
		mMethodMOType.setText(method.getMOType());
		mRetType.setText(method.getRetType());

	}

	private void selectSpec(ServiceProfile serviceProfile, Method method, ArgSpec argSpec) {
		selectMethod(serviceProfile, method);
		mArgType.setText(argSpec.getArgType());
		mArgName.setText(argSpec.getArgName());
		mArgIO.setText(argSpec.getArgIO());
	}

	public void setMethodEnable(boolean enabled) {
		mMethodName.setEnabled(enabled);
		mMethodMOType.setEnabled(enabled);
		mRetType.setEnabled(enabled);
		btnAddMethod.setEnabled(enabled);
		btnDeleteMethod.setEnabled(enabled);
		btnUpdateMethod.setEnabled(enabled);
	}

	public void setArgSpecEnable(boolean enabled) {
		mArgName.setEnabled(enabled);
		mArgType.setEnabled(enabled);
		mArgIO.setEnabled(enabled);
		btnAddSpec.setEnabled(enabled);
		btnUpdateSpec.setEnabled(enabled);
		btnDeleteSpec.setEnabled(enabled);
	}

	public void deselect() {
		composite_xml.setVisible(false);
		composite_idl.setVisible(false);
		grpProper.setVisible(false);
		((GridData) composite_xml.getLayoutData()).exclude = true;
		((GridData) composite_idl.getLayoutData()).exclude = true;
		((GridData) grpProper.getLayoutData()).exclude = true;
		grpServiceprofile.setEnabled(true);
		grpMethod.setEnabled(false);
		grpProper.setEnabled(false);
		grpArgspec.setEnabled(false);
		mProfileType.setText("");
		mProfileID.setText("");
		mProfileMOType.setText("");
		mProfilePvType.setText("");
		mProfileType.setText("");
		text_idlpath.setText("");
		mPropertiesName.setText("");
		mPropertiesValue.setText("");
		tableViewer.getTable().removeAll();
		mMethodName.setText("");
		mMethodMOType.setText("");
		mRetType.setText("");
		mArgName.setText("");
		mArgType.setText("");
		mArgIO.setText("");
	}

	private final SelectionListener UploadSelectionListener = new SelectionAdapter() {
		@Override
		public void widgetSelected(SelectionEvent e) {
			Path idlPath;
            FileDialog fd = new FileDialog(getShell(), SWT.OPEN);
			var path = Path.of(".").toAbsolutePath().normalize().resolve("workspace/resources");
            fd.setText("Choose a IDL File");
            fd.setFilterPath(path.toString());
            fd.open();
            String xPath = fd.getFilterPath() + "/" + fd.getFileName();
            var idlFile = new File(xPath);
            try {
                idlPath = Files.move(idlFile.toPath(), Path.of(path.toString(), fd.getFileName()), StandardCopyOption.REPLACE_EXISTING);
                idlPath = Path.of(idlFile.toPath().toString()).relativize(idlPath);
                text_idlpath.setText(idlPath.toString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
		}
	};
}
