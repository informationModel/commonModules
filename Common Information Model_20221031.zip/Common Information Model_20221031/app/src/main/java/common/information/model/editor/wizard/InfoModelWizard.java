package common.information.model.editor.wizard;

import java.io.FileWriter;

import org.eclipse.jface.wizard.Wizard;

import common.information.model.editor.XmlStream;
import common.information.model.editor.cim.Module;

public class InfoModelWizard extends Wizard {

	private final XmlStream mStream;
	private Module module;
	private boolean isOld;
	private OSList osList;
	InfoModelGenInfoWizardPage infoModelGenInfoWizardPage;
	InfoModelIDnTypeWizardPage infoModelIDnTypeWizardPage;
	InfoModelPropertiesPage infoModelPropertiesPage;
	InfoModelIOVariablesPage infoModelIOVariablesPage;
	InfoModelServicesPage infoModelServicesPage;
	InfoModelInfraPage infoModelInfraPage;
	InfoModelSafeSecurePage infoModelSafeSecurePage;
	InfoModelModellingPage infoModelModellingPage;
	InfoModelExecutableFormPage infoModelExecutableFormPage;

	public InfoModelWizard() {
		mStream = new XmlStream();
		setWindowTitle("InfoModelWizard");
		module = new Module();
		osList = new OSList();
		isOld = false;
		infoModelGenInfoWizardPage = new InfoModelGenInfoWizardPage(module);
		infoModelIDnTypeWizardPage = new InfoModelIDnTypeWizardPage(module);
		infoModelPropertiesPage = new InfoModelPropertiesPage(module);
		infoModelIOVariablesPage = new InfoModelIOVariablesPage(module);
		infoModelServicesPage = new InfoModelServicesPage(module);
		infoModelInfraPage = new InfoModelInfraPage(module);
		infoModelSafeSecurePage = new InfoModelSafeSecurePage(module);
		infoModelModellingPage = new InfoModelModellingPage(module);
		infoModelExecutableFormPage = new InfoModelExecutableFormPage(module);

		addPage(infoModelGenInfoWizardPage);
		addPage(infoModelIDnTypeWizardPage);
		addPage(infoModelPropertiesPage);
		addPage(infoModelIOVariablesPage);
		addPage(infoModelServicesPage);
		addPage(infoModelInfraPage);
		addPage(infoModelSafeSecurePage);
		addPage(infoModelModellingPage);
		addPage(infoModelExecutableFormPage);
	}

	public InfoModelWizard(Module module) {
		mStream = new XmlStream();
		setWindowTitle("InfoModelWizard");
		osList = new OSList();
		this.module = module;
		isOld = true;
		infoModelGenInfoWizardPage = new InfoModelGenInfoWizardPage(module, isOld);
		infoModelIDnTypeWizardPage = new InfoModelIDnTypeWizardPage(module, isOld);
		infoModelPropertiesPage = new InfoModelPropertiesPage(module, isOld);
		infoModelIOVariablesPage = new InfoModelIOVariablesPage(module, isOld);
		infoModelServicesPage = new InfoModelServicesPage(module, isOld);
		infoModelInfraPage = new InfoModelInfraPage(module, isOld);
		infoModelSafeSecurePage = new InfoModelSafeSecurePage(module, isOld);
		infoModelModellingPage = new InfoModelModellingPage(module, isOld);
		infoModelExecutableFormPage = new InfoModelExecutableFormPage(module, isOld);

		addPage(infoModelGenInfoWizardPage);
		addPage(infoModelIDnTypeWizardPage);
		addPage(infoModelPropertiesPage);
		addPage(infoModelIOVariablesPage);
		addPage(infoModelServicesPage);
		addPage(infoModelInfraPage);
		addPage(infoModelSafeSecurePage);
		addPage(infoModelModellingPage);
		addPage(infoModelExecutableFormPage);
	}

	@Override
	public boolean performFinish() {
		try (var stream = new FileWriter("workspace/module/" + module.GenInfo.mModuleName + ".xml")) {
			mStream.toXML(module, stream);
		} catch (Exception e) {
		}

		// refresh();
		return true;
	}
}