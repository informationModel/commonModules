package common.information.model.editor.wizard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.TreeItem;

import common.information.model.editor.cim.Input;

public class InputNode extends TreeNode {

	TreeItem treeitem;

	public InputNode() {
		this(new Input());
	}

	public InputNode(Input value) { // Property 정보를 포함한 PropertyNode
		super(value); // super == TreeNode
	}

	@Override
	public Input getValue() { // getValue()를 통해 Property 정보 반환
		return (Input) value;
	}

	public void setValue(Input input) {
		super.value = input;
	}

	/**
	 * Edit을 통한 Update시 Input과 하위의 트리를 생성 및 설정
	 * 
	 * @param input  Root 아래의 최상위 노드
	 * @param viewer 트리뷰어
	 */
	public void setNode(Input input, TreeViewer viewer) {
		InputNode[] children = null;
		setValue(input);

		if (input.inputs != null) {
			children = new InputNode[input.inputs.size()];
			for (int i = 0; i < input.inputs.size(); i++) {
				children[i] = new InputNode(input.inputs.get(i));
				children[i].setNode(input.inputs.get(i), viewer);
				children[i].setParent(this);
			}
			setChildren(children);
			viewer.add(this, children);
		} else {
			return;
		}
	}

	public InputNode addChild(TreeViewer viewer, Input input, Boolean isOld) { // childNode를 추가
		var node = new InputNode(input);
		var old = getChildren(); // 모든 children 배열 불러오기
		TreeNode[] children;
		if (old != null) { // children 의 유무 판별
			children = Arrays.copyOf(old, old.length + 1); // 모든 children 배열 복사, 1개가 더 추가되어야 하기 때문에 old.length+1 만큼 복사
			children[old.length] = node;
		} else {
			children = new TreeNode[] { node }; // children이 없을 경우 새로 추가
		}

		if (isOld == false) {
			if (getValue().inputs == null) {
				List<Input> inList = new ArrayList<>();
				getValue().inputs = inList;
			} else {
			}
			getValue().inputs.add(input);
		} else {
		}

		node.setParent(this);
		setChildren(children);
		viewer.add(this, node);

		return node;
	}

	public boolean removeChild(TreeViewer viewer, String name) { // childNode를 삭제
		var old = getChildren();
		if (old == null) // 없을 경우 삭제하지 않음
			return false;

		var index = IntStream.range(0, old.length) // 0부터 시작해서 old.length 길이 만큼의 int 스트림 생성
				.filter(i -> name.equals(((Input) old[i].getValue()).name)) // filter를 통해 삭제하고자하는 name을 old 배열의 name에
																			// 있는지 확인
				.findFirst().orElse(-1); // 일치하는 첫 번째 것을 반환(즉, 삭제하고자하는 위치 반환), 없으면 -1을 반환
		if (index < 0) // -1이 되었을 경우 삭제하지 않음
			return false;

		var children = new TreeNode[old.length - 1]; // 삭제해야하므로 children의 크기를 1 줄임
		System.arraycopy(old, 0, children, 0, index); // old 정보를 children에 복사, 이때 index 만큼 읽어옴
		System.arraycopy(old, index + 1, children, index, old.length - index - 1); // old 정보를 index + 1부터 읽어옴, children에
																					// 복사, index 부터 쓰고, old.length -
																					// index -1 까지 읽어서 씀
		getValue().inputs.remove(index); // properties에도 정보 삭제

		old[index].setParent(null);
		viewer.remove(this, index);
		return true;
	}
}
