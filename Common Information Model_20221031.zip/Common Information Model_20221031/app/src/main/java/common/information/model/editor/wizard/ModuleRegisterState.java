package common.information.model.editor.wizard;

public class ModuleRegisterState {
    public boolean isSafety, isSecurity;
    public boolean isHw, isSw, isTool;
}
