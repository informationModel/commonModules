package common.information.model.editor.wizard;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;

public class OSList {

    private String name;
    private List<String> versions;

    public OSList() {
        this.versions = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getVersion() {
        return versions;
    }

    public void setVersion(List<String> versions) {
        this.versions = versions;
    }
    

}
