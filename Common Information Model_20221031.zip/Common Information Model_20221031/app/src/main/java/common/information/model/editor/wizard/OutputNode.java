package common.information.model.editor.wizard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeViewer;

import common.information.model.editor.cim.Output;

public class OutputNode extends TreeNode {
	public OutputNode() {
		this(new Output());
	}

	public OutputNode(Output value) {
		super(value);
	}

	@Override
	public Output getValue() {
		return (Output) value;
	}

	public void setValue(Output output) {
		super.value = output;
	}

	public void setNode(Output output, TreeViewer viewer) {
		OutputNode[] children = null;
		setValue(output);

		if (output.outputs != null) {
			children = new OutputNode[output.outputs.size()];
			for (int i = 0; i < output.outputs.size(); i++) {
				children[i] = new OutputNode(output.outputs.get(i));
				children[i].setNode(output.outputs.get(i), viewer);
				children[i].setParent(this);
			}
			setChildren(children);
			viewer.add(this, children);
		} else {
			return;
		}
	}

	public OutputNode addChild(TreeViewer viewer, Output output, Boolean isOld) {
		var node = new OutputNode(output);
		var old = getChildren();
		TreeNode[] children;
		if (old != null) {
			children = Arrays.copyOf(old, old.length + 1);
			children[old.length] = node;
		} else {
			children = new TreeNode[] { node };
		}

		if (isOld == false) {
			if (getValue().outputs == null) {
				List<Output> outputList = new ArrayList<>();
				getValue().outputs = outputList;
			} else {
			}
			getValue().outputs.add(output);
		} else {
		}

		node.setParent(this);
		setChildren(children);
		viewer.add(this, node);

		return node;
	}

	public boolean removeChild(TreeViewer viewer, String name) {
		var old = getChildren();
		if (old == null)
			return false;

		var index = IntStream.range(0, old.length)
				.filter(i -> name.equals(((Output) old[i].getValue()).name))
				.findFirst().orElse(-1);
		if (index < 0)
			return false;

		var children = new TreeNode[old.length - 1];
		System.arraycopy(old, 0, children, 0, index);
		System.arraycopy(old, index + 1, children, index, old.length - index - 1);
		getValue().outputs.remove(index);

		old[index].setParent(null);
		viewer.remove(this, index);
		return true;
	}
}
