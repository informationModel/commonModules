package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeNode;

import common.information.model.editor.cim.Property;

public class PropertyLabelProvider extends LabelProvider {
    @Override
    public String getText(Object element) {
        if (!(element instanceof TreeNode))
            return super.getText(element);

        var node = (TreeNode) element;
        if (node.getValue() instanceof Property) {
            Property property = ((Property) node.getValue());
            if (property.getmComplex() == null) {
                property.setNone(true);
                return "(" + property.getType() + ") " + property.getName()
                        + ", " + property.getDescription() + ", " + property.getUnit() + ", "
                        + ((Property) node.getValue()).getValue();
            }
            // class
            else if (property.getmComplex().equals("class")) {
                property.setClass(true);
                return "(" + property.getmComplex() + ") " + property.getName() + ", " + ((Property) node
                        .getValue()).getComplexName();
            }
            // array
            else if (property.getmComplex().equals("array")) {
                property.setArray(true);
                String values = "";
                for (int i = 0; i < property.getValues().item.size(); i++) {
                    if (i == 0)
                        values += "[";
                    values += property.getValues().item.get(i);
                    if (i == property.getValues().item.size() - 1)
                        values += "]";
                    else
                        values += ", ";
                }
                return "(" + property.getmComplex() + ") " + property.getName() + ", "
                        + property.getType() + ", " + property.getUnit() + ", " + property.getDescription() + ", "
                        + values;
            }
            // vector
            else if (property.getmComplex().equals("vector")) {
                property.setVector(true);
                String values = "";
                for (int i = 0; i < property.getValues().item.size(); i++) {
                    if (i == 0)
                        values += "[";
                    values += property.getValues().item.get(i);
                    if (i == property.getValues().item.size() - 1)
                        values += "]";
                    else
                        values += ", ";
                }
                return "(" + property.getmComplex() + ") " + property.getName() + ", "
                        + property.getType() + ", " + property.getUnit() + ", " + property.getDescription() + ", "
                        + values;
            }

            // pointer
            else if (property.getmComplex().equals("pointer")) {
                property.setPointer(true);
                return "(" + property.getmComplex() + ") " + property.getName() + ", " + property.getInDataType();
            }

            else {
                return "(" + property.getType() + ") " + property.getName()
                        + ", " + property.getDescription() + ", " + property.getUnit() + ", "
                        + ((Property) node.getValue()).getValue();
            }
        }

        return super.getText(element);
    }
}