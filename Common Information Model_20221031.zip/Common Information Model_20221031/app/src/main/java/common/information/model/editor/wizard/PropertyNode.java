package common.information.model.editor.wizard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.eclipse.jface.viewers.TreeNode;
import org.eclipse.jface.viewers.TreeViewer;

import common.information.model.editor.cim.Property;

public class PropertyNode extends TreeNode {
	public PropertyNode() {
		this(new Property()); // this == PropertyNode(Property value)
	}

	public PropertyNode(Property value) { // Property 정보를 포함한 PropertyNode
		super(value); // super == TreeNode
	}

	@Override
	public Property getValue() { // getValue()를 통해 Property 정보 반환
		return (Property) value;
	}

	public void setValue(Property property) {
		super.value = property;
	}

	/**
	 * Edit을 통한 Update시 Property와 하위의 트리를 생성 및 설정
	 * 
	 * @param property Root 아래의 최상위 노드
	 * @param viewer   트리뷰어
	 */
	public void setNode(Property property, TreeViewer viewer) {
		PropertyNode[] children = null;
		setValue(property);

		if (property.mProperties != null) {
			children = new PropertyNode[property.mProperties.size()];
			for (int i = 0; i < property.mProperties.size(); i++) {
				children[i] = new PropertyNode(property.mProperties.get(i));
				children[i].setNode(property.mProperties.get(i), viewer);
				children[i].setParent(this);
			}
			setChildren(children);
			viewer.add(this, children);
		} else {
			return;
		}
	}

	public PropertyNode addChild(TreeViewer viewer, Property property, Boolean isOld) { // childNode를 추가
		var node = new PropertyNode(property);
		var old = getChildren(); // 모든 children 배열 불러오기
		TreeNode[] children;
		if (old != null) { // children 의 유무 판별
			children = Arrays.copyOf(old, old.length + 1); // 모든 children 배열 복사, 1개가 더 추가되어야 하기 때문에 old.lngth+1 만큼 복사
			children[old.length] = node; // 마지막 배열에 새로운 PropertyNode 추가
		} else {
			children = new TreeNode[] { node }; // children이 없을 경우 새로 추가
		}

		if (isOld == false) {
			if (getValue().mProperties == null) {
				List<Property> propertyList = new ArrayList<>();
				getValue().mProperties = propertyList;
			} else {
			}
			getValue().mProperties.add(property);
		} else {
		}

		node.setParent(this);
		setChildren(children);
		viewer.add(this, node);

		return node;
	}

	public boolean removeChild(TreeViewer viewer, String name) { // childNode를 삭제
		var old = getChildren();
		if (old == null) // 없을 경우 삭제하지 않음
			return false;

		var index = IntStream.range(0, old.length) // 0부터 시작해서 old.length 길이 만큼의 int 스트림 생성
				.filter(i -> name.equals(((Property) old[i].getValue()).getName())) // filter를 통해 삭제하고자하는 name을 old 배열의
																					// name에 있는지 확인
				.findFirst().orElse(-1); // 일치하는 첫 번째 것을 반환(즉, 삭제하고자하는 위치 반환), 없으면 -1을 반환
		if (index < 0) // -1이 되었을 경우 삭제하지 않음
			return false;

		var children = new TreeNode[old.length - 1]; // 삭제해야하므로 children의 크기를 1 줄임
		System.arraycopy(old, 0, children, 0, index); // old 정보를 children에 복사, 이때 index 만큼 읽어옴
		System.arraycopy(old, index + 1, children, index, old.length - index - 1); // old 정보를 index + 1부터 읽어옴, children에
																					// 복사, index 부터 쓰고, old.length -
																					// index -1 까지 읽어서 씀
		getValue().mProperties.remove(index); // properties에도 정보 삭제

		old[index].setParent(null);
		viewer.remove(this, index);
		return true;
	}
}
