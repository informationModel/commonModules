package common.information.model.editor.wizard;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import common.information.model.editor.XmlStream;
import common.information.model.editor.cim.Module;
import common.information.model.editor.view.dialog.NonblockDialog;;

public class SwListDialog extends NonblockDialog {

    private ListViewer swlist;
    private Text text_moduleID;
    private Module module;
    private List<String> moduleList = new LinkedList<>();

    public SwListDialog(Shell parent, ListViewer list, Module module) {
        super(parent);
        this.swlist = list;
        this.module = module;
        // TODO Auto-generated constructor stub
    }

    @Override
    protected Control createDialogArea(Composite parent) {
        Composite area = (Composite) super.createDialogArea(parent);

        Group grpModulelist = new Group(area, SWT.NONE);
        grpModulelist.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        grpModulelist.setText("SW Module List");
        grpModulelist.setLayout(new GridLayout(2, false));

        GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1);
        gd_table.widthHint = 570;
        gd_table.heightHint = 150;

        TableViewer swModuleViewer = new TableViewer(grpModulelist, SWT.BORDER | SWT.FULL_SELECTION);
        swModuleViewer.getTable().setLayoutData(gd_table);
        swModuleViewer.getTable().setHeaderVisible(true);
        swModuleViewer.getTable().setLinesVisible(true);
        swModuleViewer.setLabelProvider(new TableLabelProvider());
        swModuleViewer.addSelectionChangedListener(e -> {
            var selected = swModuleViewer.getTable().getSelection()[0];
            text_moduleID.setText(selected.getText());
        });

        TableViewerColumn[] tableViewerColumnList = new TableViewerColumn[1];
        tableViewerColumnList[0] = new TableViewerColumn(swModuleViewer, SWT.NONE);
        TableColumn swTblclmn = tableViewerColumnList[0].getColumn();
        swTblclmn.setText("SW ModuleID List");

        readSWModule();
        for (int i = 0; i < moduleList.size(); i++){
            TableItem tableItem = new TableItem(swModuleViewer.getTable(), SWT.NONE);
            tableItem.setText(moduleList.get(i).toString());
        }

        text_moduleID = new Text(grpModulelist, SWT.BORDER);
        text_moduleID.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

        Button btn_add = new Button(grpModulelist, SWT.NONE);
        btn_add.setText("Add");
        btn_add.addSelectionListener(new SelectionAdapter() {
            @Override
            public void widgetSelected(SelectionEvent e) {
                if (text_moduleID.getText().equals("")) {
                } else {
                    swlist.getList().add(text_moduleID.getText());
                    module.IDnType.mSWList.mSWList.add(text_moduleID.getText());
                    text_moduleID.setText("");
                }
            }
        });

        swModuleViewer.getControl().addControlListener(new ControlListener() {
            @Override
            public void controlResized(ControlEvent e) {
                Rectangle rect = swModuleViewer.getTable().getClientArea();
                if (rect.width > 0) {
                    int extraSpace = rect.width / swModuleViewer.getTable().getColumnCount();
                    for (int i = 0; i < tableViewerColumnList.length; i++) {
                        tableViewerColumnList[i].getColumn().setWidth(extraSpace);
                    }
                }
            }

            @Override
            public void controlMoved(ControlEvent e) {
            }
        });

        return area;
    }

    @Override
    protected boolean isResizable() {
        return true;
    }

    public void readSWModule() { 
        var path = Path.of(".").toAbsolutePath().normalize().resolve("workspace/module");
        File folder = new File(path.toString());
        File[] listOfFiles = folder.listFiles();

        for (File file : listOfFiles) {
            if (file.isFile()) {
                try (var mFile = new FileReader(path.toString() + "/" + file.getName())){
                    var xStream = new XmlStream();
                    Module fModule = (Module) xStream.fromXML(mFile);
                    String moduleID = fModule.IDnType.moduleID;
                    String[] IDs = moduleID.split("-");
                    String mCID = IDs[4];
                    int dCID = Integer.parseInt(mCID, 16);
                    String bCID = Integer.toBinaryString(dCID);
                    String swModuleInfo;

                    if (bCID.length() == 24) {
                        swModuleInfo = fModule.GenInfo.mModuleName + ":" + fModule.IDnType.moduleID;
                        moduleList.add(swModuleInfo);
                    } else if (bCID.length() <= 22){
                        swModuleInfo = fModule.GenInfo.mModuleName + ":" + fModule.IDnType.moduleID;
                        moduleList.add(swModuleInfo);
                    } else {}
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}