package common.information.model.editor.wizard;

import org.eclipse.jface.viewers.ColumnLabelProvider;

import common.information.model.editor.cim.Module;

public class TableLabelProvider extends ColumnLabelProvider {

    @Override
    public String getText(Object element) {
        String text = (String) element;
        return text;
    }

}
